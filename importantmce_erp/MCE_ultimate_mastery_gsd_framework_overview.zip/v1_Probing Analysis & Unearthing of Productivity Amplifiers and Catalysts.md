# Claude Code Prompt Optimization 

Claude Code Mastery: Advanced Patterns for 10x Productivity

## Response:
Thought for 1m 51s

Goal
----

Convert the content in your screenshots into (1) clean transcriptions and (2) a **production-grade prompt pack** specifically tuned for **Claude Code Mastery: Advanced Patterns for 10x Productivity**.

Success metrics
---------------

*   You can copy/paste any template into Claude Code and reliably get: **better questions**, **clearer plans**, **higher-quality code changes**, and **repeatable workflows**.
*   Each prompt forces: _non-obvious requirements_, _tradeoffs_, _testability_, _operational readiness_, and _clean artifacts_ (SPEC.md, tasks, checklists).

Constraints
-----------

*   I will **not repeat any real person’s name** visible in the screenshots (I’ll transcribe the content, but redact identities).
*   Prompts are written to be **tool-agnostic**: if Claude Code has a “question tool” you can plug it in; otherwise it will just ask you in chat.

* * *

Checklist
=========

*    Transcribe each screenshot (verbatim where possible)
*    Convert into **robust Claude Code prompts** (battle-tested structure: inputs → process → outputs → quality gates)
*    Tailor to “Advanced Patterns for 10x Productivity” (spec interviewing, architecture, refactors, tests, CI, observability, packaging)

* * *

Step 1 — Transcriptions (clean + faithful)
==========================================

### A) SPEC interview instruction (screenshot 1)

> “read this @SPEC.md and interview me in detail using the AskUserQuestionTool about literally anything: technical implementation, UI & UX, concerns, tradeoffs, etc. but make sure the questions are not obvious
> 
> be very in-depth and continue interviewing me continually until it’s complete, then write the spec to the file”

### B) “Prompt 6” (screenshot 2, identity redacted)

> **6\. Compress Decades into Days**  
> Prompt:  
> “You are a time-leverage strategist. I want to achieve in 1 year what most take 10 years to do. Based on my goal: \[insert goal\], create a high-leverage blueprint using shortcuts, tools, delegation, automation, and AI to leapfrog everyone else.”

### C) “Prompt 7” (screenshot 2, identity redacted)

> **7\. Be Your Dream Version**  
> Prompt:  
> “You are a psychological reprogrammer. Based on my goal to become \[insert ideal self\], help me destroy my current limiting identity and install a new operating self-image, thought pattern, and behavior map that aligns with my highest version.”

### D) “Prompt 1–2” (screenshot 3, identity redacted)

> “It can think like a GOD.  
> Here are 7 prompts that feels ILLEGAL to know:”
> 
> **1\. Think Like a Billionaire**  
> Prompt:  
> “You are a thinking coach trained on the minds of Elon Musk, Naval Ravikant, Jeff Bezos, and top polymaths. Reprogram my thought process to think in systems, long-term vision, leverage, and asymmetric outcomes. Give me daily mental models to shift from average thinker to billionaire thinker.”
> 
> **2\. Unlock Superhuman Learning**  
> Prompt:  
> “You are a neuro-optimized tutor. I want to learn any complex skill 10x faster than others. Create a weekly learning blueprint based on spaced repetition, interleaving, Feynman technique, and active recall. Apply it to \[insert topic\]. I want to be in top 1% in 90 days.”

### E) “Prompt 3–5” (screenshot 4, identity redacted)

> **3\. Download Expert-Level Knowledge**  
> Prompt:  
> “You are a world-class expert in Business . Train me as if I’m your apprentice, from beginner to mastery. Break it into stages, tasks, uncommon resources, and shortcuts. Include simulations or real-life practice assignments to truly internalize each level.”
> 
> **4\. Upgrade Mental Software**  
> Prompt:  
> “You are my cognitive OS upgrader. Audit my current thought patterns, habits, and beliefs based on this description: \[describe how you think now\]. Then rewrite my operating system to improve clarity, decision speed, memory, creativity, and emotional control.”
> 
> **5\. Design a God-Tier Life**  
> Prompt:  
> “You are my high-performance architect. Help me design a god-tier life based on time freedom, health, wealth, relationships, and purpose. Create a daily system, environment, people I must avoid, habits to master, and beliefs to rewrite to become unstoppable.”

### F) Whiteboard: “STOP ASKING AI TO ‘SUMMARISE’” (screenshot 5)

1.  **Extract Strategic Insights**  
    Prompt: “Act like a strategy consultant. Identify the 5 most valuable insights and explain what decisions each one informs.”
2.  **Turn Information Into Action**  
    Prompt: “Translate this into a 5-step plan with clear owners, quick wins, and measurable results.”
3.  **Surface Hidden Assumptions**  
    Prompt: “Reveal the unstated assumptions or blind spots shaping this argument — and what changes if they’re wrong.”
4.  **Compare Opposing Views**  
    Prompt: “Map this idea against two competing perspectives. Show where they align, where they differ, and which context fits each.”
5.  **Distil for a Specific Role**  
    Prompt: “Filter this through the lens of a [15+ Year Experienced Full-Stack Software System & Security Engineering Solutions Architect for an ERP/CRM/PSA & RAG (BM25+Vector Embedding) + Employee Buddy Agent & Multi-Agent Orchestration System & Tender Proposals & Checklist Generator & Project Management & tracking systm, with correspondence and tender completion & submission] → Walking-Through & using Pseudo-Spec Simulations to articulate and design frameworks and all Business Logic Frames and step by step representation of each Department's workflows, designing Department Charters, Reference Guides, Logs and Correspondence Systems (Legal & Tender for contract management)(HR for Resource Planning & Recruitment)(Finance Cash In/Out & 30/60/90 Forecasts as well as project and office based expense reports)(Management neededing ideal management information & Business Intelligence Analytics, Charts, Tables & Project & Client Data & Liabilities and Obligations Trackers & Timelines)(Technical Team receiving Tender Briefs and RFI & needing to respond to Tender team with their specific discipline and expertise, and to act on site and coordinate via timesheets logged. Use SPEC.md and investigate and role-play with adversarial and multi-disciplinary & multi-perspective multi-round agent approach to optimize and optimize database benefit, value added and purpose and improve business models amplifying productivity, reducing employee time wasted on tedious tasks and upgrading systems with Agentic Follow Up, Alarm/Notification Engine and Workflow Processing Engines incorporated into the core UI/UX of the ERP/CRM System and with the RAG and ideal Memory System, saving and centralizing logging & using semantic tagging and BM25 for Evolution of Workforce and Tracking individual Success Factors that lead to sharp increase in Employee Comfort and Task Orchestration & Finalization & allowing more capacity to take more jobs and accept more project awards.”
6.  **Build a Reusable Model**  
    Prompt: “Extract the repeatable framework hidden in this text. Label each stage, its input, process, and output.”
7.  **Extract Contrarian Takeaways**  
    Prompt: “Find insights that would challenge smart peers — still credible, but unexpected. Write each as a sharp one-liner.”
8.  **Identify Leverage Points**  
    Prompt: “Highlight the 3 leverage points where small actions could create outsized results. Explain why each one matters.”

* * *

Step 2 — Claude Code Mastery Prompt Pack (optimized + production-grade)
=======================================================================

Below are **copy/paste-ready prompts**. Each is tuned for: repo work, specs, architecture, packaging, CI, test strategy, migrations, and operational readiness.

* * *

Prompt 0 — “SPEC.md Interrogator → Writes SPEC.md”
--------------------------------------------------

Use this when you want Claude Code to **interview you deeply** (non-obvious questions) and then output a finished **SPEC.md**.

```md
You are a senior staff engineer + product architect running a SPEC completion interview.

Context:
- Read ./SPEC.md first (if missing, create a SPEC draft skeleton).
- Your job is to ask me ONLY non-obvious, high-leverage questions that prevent rework.

Rules for the interview:
1) Ask questions in batches of 8–12.
2) Every question must be non-obvious: it should reveal hidden constraints, sharp tradeoffs, failure modes, or downstream implications.
3) After each batch, summarize what you learned as “Spec Deltas” (new facts + decisions).
4) Continue until SPEC is complete and internally consistent.
5) Then write the final SPEC back to ./SPEC.md.

Non-obvious question generator (use these lenses):
- Invariants: what must always be true? what cannot be true at the same time?
- Failure modes: how does this break at 3am? what’s the recovery path?
- Data lifecycle: source of truth, ownership, retention, deletion, auditability.
- UX edge cases: empty states, partial permissions, slow networks, offline, retries, undo.
- Ops: logs/metrics/traces, alert thresholds, runbooks, on-call ergonomics.
- Security: authN/authZ boundaries, secrets, PII, abuse cases, rate limits.
- Cost/perf: hot paths, scaling limits, caching, queue backpressure.
- Migration: rollout strategy, backwards compatibility, data migrations, toggles.
- Developer experience: local dev, test data, CI runtime, linting, pre-commit hooks.

Output format:
A) Interview (Q batch)
B) Spec Deltas
C) Updated SPEC.md (when done): Goals, Non-goals, Personas, User Stories, UX flows, Architecture, Data model, APIs, Security, Observability, Testing, Rollout/Migration, Risks, Open Questions, Acceptance Criteria.

Begin by reading ./SPEC.md and asking your first batch of questions.
```

* * *

Prompt 1 — “Think Like a Staff Engineer”
----------------------------------------

(Adapted from “Think like a billionaire” → now **systems thinking for engineering**.)

```md
You are my Staff+ Engineering Thinking Coach.

Input:
- Repo/project: [link or path]
- Goal: [what we’re building]
- Constraints: [time, team, stack, compliance, budget]
- Current state: [what exists now]

Task:
Reprogram my approach to build and ship like a Staff Engineer:
1) Provide 10 high-signal mental models for building software systems (reliability, scale, simplicity, risk).
2) For each model: define it, give a concrete example in THIS project, and a “checklist I can run” before coding.
3) Identify 3 asymmetric leverage moves (architecture, tooling, automation, reuse) that reduce total work by 30–70%.
4) Provide a weekly cadence: what I should do Mon–Sun to stay high-leverage.

Quality gates:
- No generic advice. Tie every model to my project’s constraints.
- Include tradeoffs and failure modes.
- End with 3 decisions I must make now.
```

* * *

Prompt 2 — “Superhuman Learning for Claude Code”
------------------------------------------------

(90-day plan to master Claude Code patterns: subagents, workflows, repo hygiene.)

```md
You are my Claude Code Mastery Tutor designing a 90-day plan to reach top 1% proficiency.

Inputs:
- My current level: [non-technical / beginner / intermediate]
- Target skill: Claude Code mastery for building production apps
- Time budget: [minutes/day]
- Target stack: [Next.js, Node, Python, Docker, etc.]

Deliver:
1) 12-week plan (weekly themes) using spaced repetition + interleaving + Feynman + active recall.
2) Daily drills (15–30 min): one “micro-skill” + one “applied rep” in a real repo.
3) Weekly capstone: ship a small feature end-to-end (spec → code → tests → CI → deploy).
4) A rubric to score my outputs each week (code quality, correctness, DX, ops-readiness).

Make it Claude-Code-specific:
- prompt patterns (spec-first, refactor loops, tool use, diffs)
- sub-agent delegation (planner/reviewer/tester)
- automation (linters, typecheckers, generators)
```

* * *

Prompt 3 — “Apprenticeship Mode: Download Expert Knowledge (Repo Edition)”
--------------------------------------------------------------------------

(You learn by shipping work inside a real codebase.)

```md
You are my world-class engineering mentor. Treat me as your apprentice inside THIS repository.

Inputs:
- Repo path/link: [...]
- Outcome I want in 2 weeks: [...]
- My constraints: [...]

Process:
1) Define 5 mastery stages from beginner → shipper → maintainer → architect → owner.
2) For each stage: specific tasks in this repo (not generic), with expected PR diffs.
3) Give me “uncommon resources”: internal docs to create, scripts to write, checklists to adopt.
4) Simulations: incidents to practice (failed deploy, broken migration, prod bug, perf regression).
5) Assignments must produce artifacts: SPEC.md, ADRs, tests, CI workflow improvements, runbooks.

Output as:
- Stage roadmap
- Task list with acceptance criteria
- Weekly review questions that detect shallow understanding
```

* * *

Prompt 4 — “Cognitive OS Upgrade for Engineering Execution”
-----------------------------------------------------------

(Upgrade how you decide, not just what you do.)

```md
You are my Engineering OS Upgrader.

Input:
Describe how I currently build software (planning style, how I debug, how I manage tasks, how I decide tradeoffs):
[PASTE]

Task:
1) Diagnose failure patterns (e.g., thrash, unclear acceptance criteria, overbuilding, no observability).
2) Rewrite my operating system as rules + rituals + templates:
   - Pre-work checklist
   - Spec template
   - PR template
   - Debug playbook
   - Release checklist
3) Install “decision speed” mechanisms: default policies, timeboxes, kill-switch criteria.
4) Create a personal dashboard (what I track weekly) to measure improvement.

Constraints:
- Make it usable for Claude Code workflows and repo-based execution.
```

* * *

Prompt 5 — “God-Tier Dev Productivity System (Claude Code Operator)”
--------------------------------------------------------------------

(Your day becomes a production pipeline.)

```md
You are my high-performance engineering architect. Design a daily operating system for 10x Claude Code productivity.

Inputs:
- My role: [builder / PM+builder / solo dev]
- Work hours/day: [...]
- Project type: [SaaS / internal ERP / API]
- Stack: [...]

Deliver:
1) Daily system: focus blocks, prompt blocks, review blocks, ship blocks.
2) Environment: folder structure, repo hygiene, naming conventions, scripts, dotfiles, CLI toolchain.
3) People/process: who to avoid, who to consult, how to request reviews, how to log decisions (ADRs).
4) Habit stack: the 7 habits that compound (tests-first, spec-first, small PRs, observability, etc.).
5) “Unstoppable constraints”: rules that prevent regressions (CI gates, lint gates, PR size limits).
```

* * *

Prompt 6 — “Compress Decades into Days (Engineering Edition)”
-------------------------------------------------------------

(High-leverage roadmap for shipping a system fast—without quality collapse.)

```md
You are a time-leverage engineering strategist.

Goal:
In [timeframe], ship [product/system] to production quality.

Inputs:
- Current baseline (what exists): [...]
- Constraints: team size, budget, compliance, stack, deployment target
- Non-negotiables: security, logging, tests, performance, UX

Task:
Create a high-leverage blueprint that leapfrogs typical timelines:
1) The 20% work that delivers 80% value (identify, justify).
2) Shortcuts that are safe (templates, generators, libraries, scaffolds) vs unsafe shortcuts (call out).
3) Delegation plan: subagents/roles (Planner, Implementer, Reviewer, QA, DevOps) + responsibilities.
4) Automation plan: CI, codegen, migrations, linting, release.
5) Milestones with acceptance criteria and “kill-switch” conditions if scope explodes.

Output:
- Week-by-week plan
- Dependency graph
- Risk register with mitigations
```

* * *

Prompt 7 — “Be Your Dream Engineer (Identity → Behaviors → System)”
-------------------------------------------------------------------

(Identity prompt translated to engineering behaviors and operating constraints.)

```md
You are an identity + behavior reprogrammer for engineering execution.

Goal:
Help me become [ideal engineer identity: e.g., “calm, high-output, quality-first shipper”].

Inputs:
- My current limiting patterns: [...]
- My environment constraints: [...]
- My project demands: [...]

Task:
1) Identify the 5 identity conflicts driving my current behavior.
2) Define the new identity as operating principles (rules I follow even under pressure).
3) Map it to concrete behaviors: how I plan, how I code, how I review, how I ship.
4) Install enforcement mechanisms: templates, checklists, CI gates, timeboxes, “definition of done”.
5) Provide a 14-day reboot plan with daily actions and measurable outcomes.
```

* * *

Step 3 — Whiteboard Prompts, upgraded for Claude Code workflows
===============================================================

WB-1) Extract Strategic Insights (from code/docs/logs)
------------------------------------------------------

```md
Act as a Staff Engineer. From this input (spec, PRD, incident report, logs, or PR discussion):
[PASTE]

Deliver:
- 5 “strategic gems” that change decisions
- For each gem: what decision it informs, what tradeoff it implies, and the fastest validating experiment
- End with: the one gem most teams miss (and why)
```

WB-2) Turn Information into an Execution Plan (repo-ready)
----------------------------------------------------------

```md
Convert this input into an execution plan that can be implemented in a repo:
[PASTE]

Output:
1) 5-step plan with owners (roles), concrete deliverables, and measurable acceptance criteria
2) “Quick wins” within 24–48 hours
3) Definition-of-done checklist (tests, docs, observability, rollout)
4) A minimal PR sequence (PR1, PR2, PR3...) with scope boundaries
```

WB-3) Surface Hidden Assumptions (engineering-grade)
----------------------------------------------------

```md
Find hidden assumptions and blind spots in this plan/spec/design:
[PASTE]

Deliver:
- Assumptions grouped: Product, Data, Security, Ops, Performance, UX, Team/Process
- For each: risk if wrong, how to test quickly, and a safe fallback design
- Include at least 3 “unknown unknowns” you suspect based on similar systems
```

WB-4) Compare Opposing Views (architecture decision)
----------------------------------------------------

```md
Compare two competing approaches for this system:
A) [approach A]
B) [approach B]
Context: [constraints + goals]

Output:
- Where they align (shared invariants)
- Key differences (cost, complexity, failure modes, DX, security)
- Which context fits each
- A hybrid option if viable
- Final recommendation + what would change your mind
```

WB-5) Distill for a Role (Claude Code subagents)
------------------------------------------------

```md
Distill this information for each role:
Input: [PASTE]

Roles:
- Product/UX
- Backend/API
- Frontend
- DevOps
- QA/Testing
- Security

Output for each role:
- What matters
- What to ignore
- Top 3 risks
- Next 3 actions
```

WB-6) Build a Reusable Model (turn it into a “house style”)
-----------------------------------------------------------

```md
Extract the reusable framework hidden in this text/workflow:
[PASTE]

Output:
- Framework name
- Stages (Input → Process → Output)
- Entry/exit criteria per stage
- Common failure modes + mitigations
- A reusable template (markdown) that I can apply to new projects
```

WB-7) Contrarian Takeaways (credible but unexpected)
----------------------------------------------------

```md
From this spec/design/code review:
[PASTE]

Give me 7 contrarian takeaways that:
- Would challenge strong engineers,
- Are still credible,
- Reduce rework or improve reliability.

Each as:
- One-liner claim
- Why it’s true here
- What action it implies this week
```

WB-8) Identify Leverage Points (small actions, outsized results)
----------------------------------------------------------------

```md
Identify 3 leverage points in this project where small actions create outsized results.

Inputs:
- Current repo state: [...]
- Biggest pain: [...]
- Deadline: [...]

Output:
For each leverage point:
- The smallest action
- The compounding effect
- What it replaces/avoids (time saved)
- Risks + rollback plan
```

* * *

Callout — “Non-obvious question” triggers you should force Claude Code to ask
-----------------------------------------------------------------------------

Use these when you want questions that prevent rework:

*   “What breaks if this assumption flips?”
*   “What’s the rollback if migration fails halfway?”
*   “Which data becomes irreversible once written?”
*   “What are the 3 metrics we must see to trust prod?”
*   “What user action creates the worst-case load?”
*   “What can’t be true at the same time?”
*   “What do we intentionally NOT support?”

* * *

Validation
----------

Pick **any one** prompt above and test it against a real artifact (a repo, a SPEC draft, a PRD, or even a bug report). A good result will include:

*   explicit tradeoffs + constraints,
*   acceptance criteria,
*   test/observability/rollout,
*   and fewer “obvious” questions.

* * *

ONE next action + success signal
--------------------------------

**Next action:** Paste **Prompt 0 (SPEC.md Interrogator → Writes SPEC.md)** into Claude Code and point it at your repo (or a draft SPEC.md), then answer the first batch of 8–12 questions.  
**Success signal:** You get a materially improved **SPEC.md** with clear acceptance criteria + rollout/testing/observability sections.

Type next.



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)