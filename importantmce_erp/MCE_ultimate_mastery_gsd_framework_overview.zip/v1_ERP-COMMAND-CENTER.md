### Original Intent Synthesis
You require a **self-orchestrating, containerized ERP/PSA Command Center** built on **vue-element-admin** (not vue-vben-admin), where Claude Code acts as the primary orchestration layer with specialized agents executing in parallel lanes. The system must be:
- **Docker-first** with WSL2 optimization
- **Production-ready** for immediate employee deployment
- **Fully documented** with training manuals
- **Evaluation-gated** at every phase with quantifiable metrics
- **Context-persistent** across sessions with rehydration
- **Self-enhancing** via meta-prompting and heuristic learning
- **Adversarially tested** through multi-persona validation

### !MAXENFORCE Optimized Prompt Structure

```markdown
**MISSION**: Deploy enterprise-grade ERP/PSA Command Center in 30 days
**TRIGGER**: !MAXENFORCE activates production-ready final output + atomic task generation
**TECH STACK**: Vue 3 + Element Plus (vue-element-admin) + Node 20 + Express + MongoDB + Docker + Claude Code Agentic Mesh
**DELIVERABLE**: Functional local portal at office with employee training materials
**GATES**: Zero-tolerance halt-on-error for: typecheck, lint, test-coverage(90%), security-scan, performance-budget(2.5s TTI)
**ORCHESTRATION**: Sonnet 4.5 master coordinator + 15 specialized Haiku 4.5 workers in 7-lane parallel execution
```

---

## 2. AGENT ARCHITECTURE: COMPLETE SPECIFICATIONS (15-Agent Mesh)

### TIER 1: STRATEGIC ORCHESTRATION (Sonnet 4.5 Models)

#### **AGENT-00: ORCHESTRATOR-MASTER**
**Model**: `claude-sonnet-4.5-20241022`
**Persona**: Executive Project Director + Systems Architect
**Scope**: End-to-end mission ownership, cross-agent coordination, resource allocation, stakeholder communication
**Input**: User requirements, system state, agent outputs
**Output**: Synchronized task graphs, validation reports, go/no-go decisions
**Heuristics**:
- **Priority Weighting**: Business-critical > Technical-debt > Nice-to-have
- **Token Budget**: 200K context; 150K allocated to synthesis, 50K to coordination
- **Rehydration Cycle**: Every 4 execution segments, injects full state snapshot
- **Escalation Trigger**: If 3+ agents fail gates concurrently → halt + root cause analysis

**Operational Configuration**:
```yaml
agent_00:
  max_parallel_lanes: 7
  halt_on_error: true
  retry_strategy: exponential_backoff(max_attempts=3, base_delay=2s)
  metrics_track: [agent_latency, gate_pass_rate, token_efficiency, context_drift]
  self_optimization: 
    prompt_version: 1.0
    performance_threshold: 95% gate_pass_rate
    auto_tune: enabled  # Adjusts lane allocation based on historical task completion rates
```

---

#### **AGENT-01: SYSTEM-ARCHITECT**
**Model**: `claude-sonnet-4.5-20241022`
**Persona**: Principal Software Architect + Tech Lead
**Scope**: High-level system design, dependency mapping, technology selection, blueprint validation
**Input**: Business requirements, existing codebase, industry standards
**Output**: System architecture diagrams, tech decision records, integration contracts
**Heuristics**:
- **Conceptual Chunking**: Breaks domain into bounded contexts (Projects, Finance, HR, CRM)
- **Dependency Prediction**: Uses `mermaid-cartographer` outputs to forecast coupling
- **Compliance Check**: Validates against OWASP, 12-Factor, GDPR (audit logs)

**Operational Configuration**:
```yaml
agent_01:
  design_principles: [domain_driven_design, hexagonal_architecture, event_driven]
  blueprint_format: C4_model + Mermaid diagrams
  gate_criteria:
    - Architecture Decision Record (ADR) for each major component
    - Dependency inversion score < 0.3 (low coupling)
    - Technology risk matrix (low/medium/high) with mitigation plans
```

---

### TIER 2: CORE ENGINEERING (Haiku 4.5 Models - 7 Lanes)

#### **AGENT-02: DB-DESIGNER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Database Engineer + Data Architect
**Scope**: MongoDB schema design, indexes, validators, seeders, migration scripts
**Input**: Domain models, query patterns, performance requirements
**Output**: Mongoose schemas, aggregation pipelines, index definitions, seed data
**Heuristics**:
- **Index Strategy**: Automatic compound index creation for N+1 query prevention
- **Schema Versioning**: Each schema includes `__v: { type: Number, default: 1 }`
- **Audit Injection**: Automatic `createdBy`, `updatedBy`, `createdAt`, `updatedAt` fields
- **TTL Automation**: `notifications`, `audit_logs`, `temp_files` auto-expire after 90 days

**Deliverables**:
```typescript
// backend/models/project.model.ts
import mongoose, { Schema } from "mongoose";

const ProjectSchema = new Schema({
  code: { type: String, unique: true, index: true, required: true },
  name: { type: String, required: true },
  clientId: { type: Schema.Types.ObjectId, ref: "Organization", index: true },
  tenderId: { type: Schema.Types.ObjectId, ref: "Tender" },
  // ... full schema with 25+ fields
}, { timestamps: true });

// Compound indexes for dashboard queries
ProjectSchema.index({ managerId: 1, status: 1, endAt: -1 });
ProjectSchema.index({ clientId: "text", name: "text" });

export default mongoose.model("Project", ProjectSchema);
```

**Gate Metrics**:
- Index coverage: 100% of query patterns
- Schema validation: 0 errors in Zod validation tests
- Seeder idempotency: Can run 10x without duplicate data

---

#### **AGENT-03: BACKEND-ENGINEER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Senior Backend Engineer + API Designer
**Scope**: RESTful API, GraphQL (if needed), controllers, services, middleware, auth
**Input**: DB schemas, workflow definitions, frontend requirements
**Output**: Express routes, controller logic, service layer, Zod validators, JWT auth
**Heuristics**:
- **Handler Pattern**: Every route uses `asyncHandler` wrapper for consistent error handling
- **Validator Middleware**: Zod schemas for request/response validation
- **RBAC Enforcement**: Permission matrix checked at every endpoint
- **Rate Limiting**: 100 req/min default, adjustable per endpoint
- **Audit Logging**: Every POST/PUT/DELETE auto-logs to `audit_logs` collection

**Sample Output**:
```typescript
// backend/routes/project.routes.ts
import { Router } from "express";
import { z } from "zod";
import asyncHandler from "../middleware/asyncHandler";
import { requirePermission } from "../middleware/rbac";
import ProjectController from "../controllers/project.controller";

const router = Router();

const createProjectSchema = z.object({
  code: z.string().min(3).max(20),
  name: z.string().min(5),
  clientId: z.string().regex(/^[0-9a-fA-F]{24}$/),
  budget: z.number().positive(),
});

router.post(
  "/",
  requirePermission("projects:create"),
  validateSchema(createProjectSchema),
  asyncHandler(ProjectController.create)
);

router.get(
  "/",
  requirePermission("projects:read"),
  asyncHandler(ProjectController.list)
);

export default router;
```

**Gate Metrics**:
- Test coverage: 95% lines, 90% branches
- API latency: P95 < 200ms for key reads
- Error rate: < 0.1% in production logs

---

#### **AGENT-04: FRONTEND-ENGINEER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Senior Frontend Engineer + Vue.js Specialist
**Scope**: Vue 3 components, Element Plus integration, Pinia stores, Vue Router, composables
**Input**: Backend API specs, UI mockups, user stories
**Output**: `.vue` files, store modules, route definitions, composables, tests
**Heuristics**:
- **Component Granularity**: Max 200 lines per SFC, enforced by lint rule
- **Store Modularity**: One Pinia store per domain entity (projectStore, invoiceStore)
- **Composable Reuse**: API calls, pagination, filters, permissions as composables
- **Type Safety**: Full TypeScript with `defineComponent` and PropType validation
- **Accessibility**: WCAG AA compliance, keyboard navigation, ARIA labels

**Component Structure**:
```
frontend/src/
├── components/
│   ├── projects/          # Domain-specific components
│   │   ├── ProjectCard.vue
│   │   ├── ProjectForm.vue
│   │   └── ProjectStatusBadge.vue
│   ├── common/            # Reusable primitives
│   │   ├── DataTable.vue
│   │   ├── SearchInput.vue
│   │   └── PermissionGuard.vue
├── stores/
│   ├── project.store.ts
│   ├── invoice.store.ts
│   └── user.store.ts
├── composables/
│   ├── useApi.ts
│   ├── usePagination.ts
│   └── usePermissions.ts
├── views/
│   ├── dashboard/
│   ├── projects/
│   └── invoices/
```

**Gate Metrics**:
- Component test coverage: 85%
- Lighthouse score: > 95 (Performance, Accessibility)
- Bundle size: < 500KB per route (code-split)
- Type errors: 0

---

#### **AGENT-05: WORKFLOW-ENGINEER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Business Process Engineer + Rules Engine Developer
**Scope**: Workflow DSL design, guard conditions, action execution, state machine logic
**Input**: Business process maps, entity lifecycle requirements
**Output**: YAML/JSON workflow definitions, Zod validators, executor engine, audit logs
**Heuristics**:
- **DSL Versioning**: All workflows include `version: integer` for migration paths
- **Guard Composition**: Guards are composable pure functions with Zod validation
- **Action Idempotency**: All workflow actions are retry-safe (upsert patterns)
- **State Validation**: Illegal transitions throw `WorkflowException` with remediation hints

**Workflow Definition Example**:
```yaml
# workflows/tender-to-cash.yml
version: 1
name: TenderToCash
entities: [tenders, opportunities, projects, invoices, payments]
states:
  DRAFT: { description: "Initial tender document" }
  SUBMITTED: { description: "Sent to client" }
  OPPORTUNITY: { description: "Qualified lead" }
  PROJECT: { description: "Active delivery" }
  INVOICED: { description: "Invoice sent" }
  PAID: { description: "Payment received" }
  CLOSED: { description: "Completed or lost" }

transitions:
  - { from: DRAFT, event: submit, to: SUBMITTED, guard: "validateTender()", action: "logTransition()" }
  - { from: SUBMITTED, event: qualify, to: OPPORTUNITY, guard: "probability >= 0.6" }
  - { from: OPPORTUNITY, event: win, to: PROJECT, guard: "contractSigned == true", action: "createProject()" }
  - { from: PROJECT, event: invoice, to: INVOICED, guard: "milestonesDone >= 1", action: "generateInvoice()" }
  - { from: INVOICED, event: pay, to: PAID, action: "recordPayment()" }
  - { from: PAID, event: close, to: CLOSED }
```

**Gate Metrics**:
- Workflow execution success rate: 99.9%
- Guard evaluation time: < 10ms per transition
- State consistency: 100% (no orphaned entities)

---

#### **AGENT-06: MERMAID-CARTOGRAPHER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Technical Documenter + Visualization Specialist
**Scope**: Auto-generate Mermaid diagrams from schemas, workflows, and system state
**Input**: DB schemas, workflow YAML, API routes, dependencies
**Output**: `.md` files with Mermaid diagrams; SVG exports; interactive HTML charts
**Heuristics**:
- **Dependency Graph**: Maps all entity relationships (Projects → Invoices → Payments)
- **Workflow Visualization**: Converts every workflow to flowchart + state diagram
- **System Architecture**: Generates C4 model diagrams (Context, Containers, Components)
- **API Map**: Creates endpoint relationship graphs
- **Auto-Refresh**: Git hook triggers regeneration on schema/workflow changes

**Generation Script**:
```typescript
// backend/scripts/generate-mermaid.ts
import fs from "fs";
import mongoose from "mongoose";
import { glob } from "glob";

async function generateEntityGraph() {
  const models = await glob("backend/models/*.model.ts");
  const nodes = models.map(m => {
    const name = m.match(/(\w+)\.model\.ts/)![1];
    return `${name}[${name}]`;
  });
  
  const edges = [
    "Project --> Invoice",
    "Invoice --> Payment",
    "Project --> Task",
    "User --> Timesheet",
  ];

  const diagram = `graph LR\n  ${nodes.join("\n  ")}\n  ${edges.join("\n  ")}`;
  
  fs.mkdirSync("docs/diagrams", { recursive: true });
  fs.writeFileSync("docs/diagrams/entity-graph.md", "```mermaid\n" + diagram + "\n```");
}
```

**Gate Metrics**:
- Diagram accuracy: 100% match with actual code
- Generation time: < 5 seconds for full system
- Coverage: All entities, workflows, and API groups documented

---

#### **AGENT-07: UI-RENDERER**
**Model**: `xxxxxxxxxxxxxxxxxx`
**Persona**: UX Engineer + Data Visualization Expert
**Scope**: Dashboard KPI cards, ECharts visualizations, data tables, filters, micro-interactions
**Input**: Business metrics definitions, data schemas, design tokens
**Output**: Vue components with exact Tailwind classes, ECharts configs, Motion One animations
**Heuristics**:
- **Prompt-to-UI Fidelity**: Component classes must match design tokens exactly
- **Performance Budget**: Each KPI card renders in < 50ms
- **Responsive by Default**: Mobile-first, breakpoints: 480, 768, 1024, 1280, 1536px
- **Accessibility**: WCAG AA contrast ratios, keyboard navigation, screen reader support

**KPI Card Component**:
```vue
<template>
  <motion.div
    :initial="{ opacity: 0, y: 20 }"
    :animate="{ opacity: 1, y: 0 }"
    class="rounded-xl bg-slate-900/60 border border-slate-700 shadow-glow p-4"
  >
    <div class="flex items-center justify-between">
      <span class="text-slate-300 tracking-wide text-xs">{{ title }}</span>
      <LucideIcon :name="icon" class="w-4 h-4 text-cyan-400" />
    </div>
    <div class="mt-2 text-2xl font-semibold text-emerald-400">{{ value }}</div>
    <div class="text-xs mt-1" :class="delta >= 0 ? 'text-emerald-400' : 'text-rose-400'">
      {{ delta }}% vs last period
    </div>
  </motion.div>
</template>

<script setup lang="ts">
defineProps<{
  title: string;
  value: string | number;
  icon: string;
  delta: number;
}>();
</script>
```

**Gate Metrics**:
- First Contentful Paint: < 1.5s
- Cumulative Layout Shift: < 0.1
- Interaction to Next Paint: < 200ms

---

#### **AGENT-08: IMPORT-MAPPER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Data Integration Specialist + ETL Engineer
**Scope**: CSV/Excel/JSON import, streaming validation, upsert logic, mapping profiles
**Input**: Legacy data files, target schemas, validation rules
**Output**: Import scripts, mapping profiles, error reports, reconciliation logs
**Heuristics**:
- **Streaming Processing**: Processes files in 1000-row chunks to prevent memory exhaustion
- **Idempotent Upsert**: Uses `code` fields as natural keys; updates existing, inserts new
- **Validation Pipeline**: Zod schemas validate each row; failed rows written to `import_errors.csv`
- **Mapping Persistence**: Saved in `settings.import_profiles` for repeatable imports
- **Rollback Safety**: Imports wrapped in transactions; >1% critical errors → full rollback

**Import Script**:
```typescript
// backend/scripts/import-projects.ts
import fs from "fs";
import csv from "csv-parser";
import { Project } from "../models/project.model";
import { z } from "zod";

const ProjectRowSchema = z.object({
  code: z.string(),
  name: z.string(),
  clientCode: z.string(),
  budget: z.coerce.number(),
});

async function importProjects(filePath: string) {
  const errors: any[] = [];
  let success = 0;
  let total = 0;

  await new Promise((resolve, reject) => {
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", async (row) => {
        total++;
        try {
          const validated = ProjectRowSchema.parse(row);
          await Project.findOneAndUpdate(
            { code: validated.code },
            { $set: validated },
            { upsert: true, new: true }
          );
          success++;
        } catch (e) {
          errors.push({ row, error: e.message });
        }
      })
      .on("end", resolve)
      .on("error", reject);
  });

  if (errors.length / total > 0.01) {
    throw new Error(`Import failed: ${errors.length} critical errors`);
  }

  fs.writeFileSync("import_report.json", JSON.stringify({ success, errors }, null, 2));
}
```

**Gate Metrics**:
- Import success rate: > 99%
- Processing speed: > 10,000 rows/minute
- Data accuracy: 100% post-validation match

---

### TIER 3: QUALITY & SECURITY (Haiku 4.5 Models)

#### **AGENT-09: QA-GATE**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: QA Director + DevOps Engineer + Performance Analyst
**Scope**: Automated testing (unit, integration, e2e), linting, type checking, security scanning, performance auditing
**Input**: Codebase, test files, CI configuration
**Output**: Test reports, coverage maps, performance budgets, security audit, gate pass/fail
**Heuristics**:
- **Parallel Execution**: Runs 7 test suites simultaneously (unit, integration, lint, type, security, perf, e2e)
- **Zero Tolerance**: Any critical failure → instant halt + rollback + notification
- **Coverage Enforcement**: 90% line coverage, 85% branch coverage, 100% critical paths
- **Security Scan**: OWASP Dependency Check, Snyk integration, secrets detection
- **Performance Budget**: Bundle size, TTI, API latency enforced via `performance-budget.json`

**QA Configuration**:
```json
{
  "scripts": {
    "test:unit": "vitest run --coverage",
    "test:integration": "vitest run --config vitest.integration.config.ts",
    "test:e2e": "playwright test",
    "lint": "eslint --max-warnings 5",
    "typecheck": "tsc --noEmit",
    "security": "snyk test --severity-threshold=high",
    "perf": "lighthouse-ci --budget=./performance-budget.json"
  },
  "qaGate": {
    "haltOn": ["test:failure", "lint:error", "type:error", "security:critical"],
    "retryAttempts": 2,
    "notifyOnFailure": ["orchestrator@claude.local", "dev-team@company.com"]
  }
}
```

**Gate Metrics**:
- Test execution time: < 5 minutes full suite
- False positive rate: < 2%
- Flaky test detection: Auto-quarantine if fails 3x in a row

---

#### **AGENT-10: SECURITY-AGENT**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Security Engineer + Compliance Officer
**Scope**: JWT authentication, RBAC permissions, audit logging, data encryption, GDPR compliance
**Input**: User roles, permission matrices, data classification
**Output**: Auth middleware, role definitions, audit log schema, security policies
**Heuristics**:
- **JWT Rotation**: Access tokens: 15min; Refresh tokens: 7 days; Rotation on each request
- **Permission Granularity**: CRUD per entity + field-level read/write restrictions
- **Audit Immutability**: `audit_logs` collection is append-only, no updates/deletes
- **Data Masking**: PII fields (email, phone) masked in logs; encrypted at rest
- **Compliance Hooks**: Auto-tracks consent, right-to-be-forgotten, data portability

**RBAC Matrix**:
```typescript
// backend/config/permissions.ts
export const permissions = {
  admin: ["*"],
  manager: [
    "projects:*",
    "tasks:*",
    "timesheets:read",
    "invoices:read",
    "reports:*",
  ],
  employee: [
    "projects:read",
    "tasks:assignee",
    "timesheets:own",
    "expenses:own",
  ],
  client: [
    "projects:read",
    "invoices:read",
    "documents:read",
  ],
} as const;
```

**Gate Metrics**:
- Auth failure rate: < 0.1%
- Audit log completeness: 100% of state-changing operations
- Penetration test score: 0 critical, 0 high vulnerabilities

---

### TIER 4: OPERATIONS & OPTIMIZATION (Haiku 4.5 Models)

#### **AGENT-11: DEVOPS-ENGINEER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: DevOps Architect + SRE
**Scope**: Docker compose, healthchecks, volume management, CI/CD, deployment scripts
**Input**: Application code, dependencies, environment variables
**Output**: `docker-compose.yml`, Dockerfiles, `.dockerignore`, deployment scripts, healthcheck endpoints
**Heuristics**:
- **Multi-Stage Builds**: Separate build/runtime stages; final image < 200MB
- **Healthcheck Parity**: Each service has `/health` endpoint; Docker depends_on conditions
- **Volume Optimization**: Named volumes for persistent data; bind mounts for dev hot-reload
- **WSL2 Pathing**: Linux-style paths in containers; Windows interop documented
- **Immutable Tags**: Docker images tagged with `{{service}}:{{version}}-{{git_sha}}`

**Docker Configuration**:
```yaml
# docker-compose.yml (production-optimized)
services:
  mongo:
    image: mongo:7-jammy
    container_name: erp-mongo
    volumes:
      - mongo_data:/data/db
      - ./scripts/mongo-init.js:/docker-entrypoint-initdb.d/init.js:ro
    healthcheck:
      test: ["CMD", "mongosh", "--eval", "db.runCommand({ ping: 1 })"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 30s

  backend:
    build:
      context: ./backend
      target: production
      cache_from:
        - ghcr.io/company/erp-backend:latest
    image: ghcr.io/company/erp-backend:${VERSION:-latest}
    container_name: erp-backend
    depends_on:
      mongo:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 10s
      timeout: 5s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 512M

volumes:
  mongo_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/erp/mongo-data
```

**Gate Metrics**:
- Container startup time: < 30 seconds
- Health check pass rate: 100% after initial stabilization
- Image size: backend < 200MB, frontend < 50MB
- Resource usage: CPU < 70%, Memory < 80% of allocation

---

#### **AGENT-12: PERFORMANCE-OPTIMIZER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Performance Engineer + Monitoring Specialist
**Scope**: Query optimization, caching strategy, bundle analysis, monitoring setup, alert tuning
**Input**: Slow queries, bundle stats, runtime metrics
**Output**: Optimized queries, Redis cache layer, lazy-loaded routes, Grafana dashboards
**Heuristics**:
- **Query Indexing**: Automatically suggests indexes for slow queries (>100ms)
- **Cache Strategy**: Dashboard KPIs cached 5min; user sessions cached 1min; static assets cached 1hr
- **Bundle Splitting**: Routes, vendors, polyfills split; dynamic imports for heavy components
- **Monitoring**: Prometheus metrics exported; P95 latency tracked per endpoint
- **Alerting**: PagerDuty integration for >5% error rate or >2s P95 latency

**Optimization Example**:
```typescript
// Add to slow controller
import Redis from "ioredis";
const redis = new Redis(process.env.REDIS_URL);

async function getDashboardMetrics() {
  const cacheKey = "dashboard:kpis";
  const cached = await redis.get(cacheKey);
  
  if (cached) return JSON.parse(cached);
  
  const metrics = await calculateMetrics(); // Expensive aggregation
  await redis.setex(cacheKey, 300, JSON.stringify(metrics)); // 5min TTL
  
  return metrics;
}
```

**Gate Metrics**:
- Query performance: P95 < 100ms, P99 < 500ms
- Cache hit rate: > 80% for dashboard data
- Bundle size: Initial load < 500KB, per route < 200KB
- Time to Interactive: < 2.5s on 3G connection

---

### TIER 5: DOCUMENTATION & TRAINING (Haiku 4.5 Models)

#### **AGENT-13: DOCUMENTATION-WRITER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Technical Writer + Training Coordinator + Knowledge Manager
**Scope**: User manuals, training videos scripts, API docs, runbooks, context-engineering safety docs
**Input**: System functionality, agent configurations, deployment procedures
**Output**: `docs/employee-manual.md`, `docs/admin-runbook.md`, `docs/api-reference.md`, `docs/training-videos/`
**Heuristics**:
- **Progressive Disclosure**: Quick-start (1 page) → User guide (20 pages) → Admin runbook (50 pages)
- **Screenshot Automation**: Puppeteer scripts capture UI states for docs
- **Version Sync**: Documentation version always matches code version (`git tag` linked)
- **Translation Ready**: Content structured for i18n (English first, Arabic placeholder)
- **Context Safety**: Documents context isolation, poisoning prevention, cache busting

**Documentation Structure**:
```
docs/
├── 00-quick-start.md              # 1-page "Get Started in 5 Minutes"
├── 01-employee-manual.md          # Role-based usage guide (Project Manager, Employee, Client)
├── 02-admin-runbook.md            # Deployment, backup, recovery, troubleshooting
├── 03-api-reference/              # Auto-generated from JSDoc
├── 04-context-engineering.md      # Claude Code safety & context management
├── 05-training/                   # Video scripts + quizzes
│   ├── 01-creating-a-project.md
│   ├── 02-tracking-timesheets.md
│   └── 03-generating-invoices.md
└── diagrams/                      # Mermaid outputs
```

**Training Manual Excerpt**:
```markdown
# Module 1: Creating Your First Project (Project Manager)

**Objective**: By the end of this 10-minute module, you will create a project, assign team members, and set milestones.

**Steps**:
1. Login to ERP Command Center: http://localhost:5173
2. Navigate to Projects → "New Project"
3. Complete the form:
   - **Code**: Unique identifier (e.g., PROJ-2025-001)
   - **Name**: Descriptive project name
   - **Client**: Select from dropdown or create new
   - **Budget**: Estimated total budget in USD
4. Click "Create" → System auto-assigns project ID
5. Add team members in the "Resources" tab
6. Define milestones with due dates

**Exercise**: Create a sample project for "Office Renovation" with $50,000 budget.

**Quiz** (3 questions):
1. What makes a project code unique?
2. Can you change the budget after creation?
3. How do you mark a milestone as complete?

**Next Module**: Tracking timesheets against projects
```

**Gate Metrics**:
- Documentation coverage: 100% of public APIs, 100% of user-facing features
- Screenshot currency: < 7 days old (auto-regenerate on UI changes)
- User comprehension test: > 90% pass rate on training quizzes

---

#### **AGENT-14: ADVERSARIAL-TESTER**
**Model**: `xxxxxxxxxxxxxx`
**Persona**: Penetration Tester + Chaos Engineer + Edge Case Expert
**Scope**: SQL injection attempts, XSS payloads, RBAC bypass, state corruption, network partition simulation
**Input**: Application endpoints, auth system, workflow definitions
**Output**: Attack vectors, vulnerability reports, chaos test scenarios, remediations
**Heuristics**:
- **Attack Patterns**: OWASP Top 10 automated scanning (ZAP integration)
- **RBAC Matrix**: Tests every role × every endpoint × CRUD operation (Cartesian product)
- **Workflow Corruption**: Submits illegal state transitions; attempts to skip guards
- **Load Chaos**: Simulates 10x traffic spikes to test circuit breakers
- **Data Poisoning**: Feeds malformed CSV imports to test validation rigor

**Test Scenario**:
```yaml
# test/chaos/invoice-rbac-attack.yml
scenario: "Attempt to view invoice as unauthorized employee"
steps:
  - Login as employee (role: employee, id: emp-001)
  - GET /api/invoices/INV-2025-001 (owned by different employee)
expect: 403 Forbidden
actual: 200 OK  # VULNERABILITY DETECTED: Missing ownership check
remediation: "Add ownership filter in InvoiceController: { assigneeId: req.user.id }"
```

**Gate Metrics**:
- Critical vulnerabilities: 0
- High vulnerabilities: 0
- Medium vulnerabilities: < 3 (tracked in security backlog)
- False negative rate: < 1% (missed vulnerabilities)

---

### TIER 6: META-PROMPTING & SELF-ENHANCEMENT (Sonnet 4.5)

#### **AGENT-15: META-ENHANCER**
**Model**: `claude-sonnet-4.5-20241022`
**Persona**: AI Systems Researcher + Prompt Engineer + Heuristic Analyst
**Scope**: Agent prompt optimization, context compression, performance analytics, self-tuning, knowledge distillation
**Input**: Agent execution logs, token usage, gate failure patterns, context drift indicators
**Output**: Optimized prompt templates, context pruning rules, heuristic updates, agent reconfiguration
**Heuristics**:
- **Prompt Versioning**: Each agent prompt has semantic version; tracked in `agents/prompts/`
- **Context Compression**: Embeddings similarity removes redundant context; retains unique info
- **Token Efficiency**: Tracks token-per-output-value ratio; prunes low-yield context
- **Dynamic Lane Allocation**: Adjusts parallel lanes based on task complexity (simple: 3 lanes, complex: 7 lanes)
- **Self-Learning**: Failed gates trigger root cause analysis; prompts updated to prevent recurrence

**Meta-Prompt Configuration**:
```yaml
# .claude/agents/meta-config.yml
prompt_optimization:
  strategy: "gradient_descent_on_failures"
  learning_rate: 0.1
  evaluation_window: 10 runs

context_management:
  max_tokens: 180000
  retention_policy:
    - system_rules: persistent
    - recent_state: last_4_segments
    - historical_success: top_10_patterns
    - ephemeral_scratch: discard_after_use

performance_analytics:
  track: [token_usage, latency, gate_pass_rate, context_drift_score]
  alert_thresholds:
    token_usage: "> 150000"
    gate_pass_rate: "< 95%"
    context_drift: "> 0.3"
```

**Gate Metrics**:
- Prompt improvement rate: > 5% efficiency gain per week
- Context drift: < 0.2 (measured by semantic similarity decay)
- Agent reconfiguration time: < 1 minute (hot-swap capable)

---

## 3. MACRO/MICRO TASK BREAKDOWN (Hierarchical Execution Plan)

### **MACRO PHASE 0: SYSTEM BOOTSTRAP (Day 0)**

#### **M0.1: Environment Validation** *(5 minutes)*
**Agent**: ORCHESTRATOR-MASTER
**Parallel Lanes**: 1
**Tasks**:
- [ ] Verify Docker 28.5.1+ installed and running
- [ ] Verify Node.js 20+ and pnpm available
- [ ] Verify Git configured (user.name, user.email)
- [ ] Verify 50GB free disk space
- [ ] Create `C:\Dev\ERP-CommandCenter\` root directory

**Evaluation Gate**:
```bash
# Command to validate
docker --version && node --version && pnpm --version && git config --list
# Expected: All versions returned, no errors
# Halt if: Any command fails
```

**Context Injector**: 
> "Environment validated successfully. System ready for containerized development. Proceeding to clone vue-element-admin repository..."

---

#### **M0.2: Repository Acquisition** *(10 minutes)*
**Agent**: DEVOPS-ENGINEER
**Parallel Lanes**: 2 (clone + verify)
**Tasks**:
- [ ] Clone `vue-element-admin` from GitHub to `C:\Dev\ERP-CommandCenter\frontend`
- [ ] Clone backend starter template to `C:\Dev\ERP-CommandCenter\backend`
- [ ] Initialize monorepo root with `pnpm-workspace.yaml`
- [ ] Create `.gitignore` for monorepo pattern

**Evaluation Gate**:
```bash
# Verify clone success
test -d frontend/src && test -d backend/src
du -sh frontend backend | grep -E '^[0-9]+M'
# Halt if: Either directory missing or size < 10MB (incomplete clone)
```

**Context Injector**:
> "Repositories cloned. Frontend (vue-element-admin) and backend (Express) templates acquired. Monorepo structure initialized. Moving to containerization setup..."

---

### **MACRO PHASE 1: CONTAINERIZATION INFRASTRUCTURE (Day 1)**

#### **M1.1: Docker Compose Architecture** *(30 minutes)*
**Agents**: DEVOPS-ENGINEER, DB-DESIGNER, BACKEND-ENGINEER
**Parallel Lanes**: 3
**Tasks**:
- [ ] Create `docker-compose.yml` with 5 services (mongo, backend, frontend, mongo-express, worker)
- [ ] Create `Dockerfile` for backend (multi-stage: builder + production)
- [ ] Create `Dockerfile` for frontend (Vite dev server + Nginx production)
- [ ] Create `.dockerignore` optimized (excludes: node_modules, .git, *.log, .env)
- [ ] Create `.env.example` with 15 environment variables

**Evaluation Gate**:
```bash
# Validate Docker configuration
docker compose config --quiet
docker compose build --no-cache
docker images | grep erp-backend
docker images | grep erp-frontend
# Halt if: Build fails, image size > 500MB, or healthchecks missing
```

**Metrics**:
- Image size: backend < 200MB, frontend < 50MB
- Build time: < 5 minutes
- Security scan: 0 high vulnerabilities (Trivy scan)

**Context Injector**:
> "Containerization infrastructure validated. All services building successfully. Healthchecks configured. Proceeding to database schema design..."

---

#### **M1.2: MongoDB Initialization** *(20 minutes)*
**Agent**: DB-DESIGNER
**Parallel Lanes**: 2
**Tasks**:
- [ ] Create `backend/scripts/mongo-init.js` for initial user/role seeding
- [ ] Create `backend/models/` directory with 15 Mongoose schemas
- [ ] Define compound indexes for dashboard queries (8 indexes)
- [ ] Create TTL indexes for `notifications` (90 days) and `audit_logs` (365 days)
- [ ] Create `backend/seeders/` with idempotent data scripts

**Evaluation Gate**:
```bash
# Start only MongoDB container
docker compose up -d mongo
# Wait for healthy state
docker compose exec mongo mongosh --eval "db.runCommand({ ping: 1 })"
# Halt if: MongoDB fails healthcheck > 5 attempts
```

**Metrics**:
- Index creation time: < 10 seconds
- Seeder execution: < 30 seconds for 10,000 sample records
- Query performance: All indexed queries < 50ms

**Context Injector**:
> "Database schema deployed and seeded. Indexes optimized for dashboard queries. TTL policies active. Transitioning to backend API development..."

---

### **MACRO PHASE 2: BACKEND API CONSTRUCTION (Days 2-5)**

#### **M2.1: Core API Layer** *(4 days)*
**Agents**: BACKEND-ENGINEER, SECURITY-AGENT, WORKFLOW-ENGINEER
**Parallel Lanes**: 7 (one per domain: projects, invoices, timesheets, etc.)
**Micro Tasks per Domain**:
- [ ] Create `routes/{{domain}}.routes.ts` with CRUD endpoints
- [ ] Create `controllers/{{domain}}.controller.ts` with async handlers
- [ ] Create `services/{{domain}}.service.ts` with business logic
- [ ] Create `validators/{{domain}}.validator.ts` with Zod schemas
- [ ] Create `tests/{{domain}}.spec.ts` with 90% coverage
- [ ] Integrate workflow triggers (e.g., `project.complete → invoice.generate`)
- [ ] Add RBAC middleware for each endpoint

**Daily Evaluation Gate**:
```bash
# Run QA suite for completed domains
pnpm test:unit --domain=projects
pnpm test:coverage --threshold=90
# Halt if: Coverage < 90% or any test fails
```

**Context Injector** (after each domain):
> "Domain {{domain}} completed. API coverage: {{coverage}}%. RBAC enforced: {{endpoint_count}} endpoints. Workflow triggers: {{trigger_count}}. Proceeding to next domain..."

---

#### **M2.2: Workflow Engine Integration** *(2 days)*
**Agent**: WORKFLOW-ENGINEER
**Parallel Lanes**: 3
**Tasks**:
- [ ] Create `backend/workflow/engine.ts` (state machine executor)
- [ ] Create `workflows/` directory with 5 YAML definitions (TenderToCash, ProjectLifecycle, InvoiceApproval, ExpenseReimbursement, ContractRenewal)
- [ ] Create `backend/workflow/guards.ts` with 20+ guard functions
- [ ] Create `backend/workflow/actions.ts` with 15+ action functions
- [ ] Create `backend/middleware/workflow-trigger.ts` (auto-trigger on entity changes)
- [ ] Create `tests/workflow.spec.ts` with scenario testing

**Evaluation Gate**:
```python
# Workflow validation script
# Must pass: All transitions valid, no dead states, guards are pure functions
python scripts/validate-workflows.py workflows/
# Halt if: Any workflow validation fails
```

**Metrics**:
- Guard execution time: < 10ms
- Workflow execution success: 100% for happy path, 100% guard rejection for invalid paths
- State consistency: 0 orphaned entities after 1000 workflow runs

**Context Injector**:
> "Workflow engine validated. 5 business processes modeled. Guards and actions tested. Integration middleware active. Proceeding to frontend integration..."

---

### **MACRO PHASE 3: FRONTEND PORTAL INTEGRATION**

#### **M3.1: SELECTED TECH-STACK Customization** **
**Agents**: FRONTEND-ENGINEER, UI-RENDERER
**Parallel Lanes**: 5 (Dashboard, Projects, Invoices, Reports)
**Tasks per Module**:
- [ ] Create `frontend/src/views/erp/{{module}}/` directory structure
- [ ] Create `frontend/src/api/erp/{{module}}.ts` (Axios wrappers with auto-auth)
- [ ] Create `frontend/src/store/erp/{{module}}.ts` (Pinia with persistence)
- [ ] Create `frontend/src/components/erp/{{module}}/*.vue` (Element Plus components)
- [ ] Create `frontend/src/router/modules/erp.ts` (route definitions)
- [ ] Create `frontend/src/locales/en/erp.ts` (i18n keys)
- [ ] Integrate ECharts for analytics, Mermaid for dependency maps
- [ ] Add Motion One micro-interactions (page transitions, hover states)

**Evaluation Gate**:
```bash
# Build and test frontend
pnpm --filter frontend build
pnpm --filter frontend test:unit
# Lighthouse CI
lighthouse-ci http://localhost:5173 --budget=.lighthouseci/budget.json
# Halt if: Build fails, Lighthouse score < 95, test coverage < 85%
```

**Metrics**:
- Bundle size: < 500KB initial, < 200KB per route
- Lighthouse: Performance > 95, Accessibility > 95, Best Practices > 95
- Type errors: 0
- Interactive elements: 100% keyboard accessible

**Context Injector**:
> "Frontend module {{module}} integrated. Components: {{component_count}}. API coverage: {{api_endpoint_count}}. Lighthouse score: {{lighthouse_score}}. Moving to data import capabilities..."

---

#### **M3.2: Management Dashboard Construction** *(2 days)*
**Agent**: UI-RENDERER
**Parallel Lanes**: 3
**Tasks**:
- [ ] Create `frontend/src/views/dashboard/index.vue` (KPI cards grid)
- [ ] Implement 8 KPI cards: Receivables, Cash In, Overdue Invoices, Tenders Due, Expiring Contracts, Project Burn, Profit Margin, Resource Utilization
- [ ] Create 5 ECharts visualizations: Cash Flow (line), Tender Win Rate (bar), Expense Categories (pie), Project Timeline (Gantt), Resource Heatmap (calendar)
- [ ] Create 4 data tables: Tenders Due Soon, Projects at Risk, Upcoming Payments, Expiring Tasks
- [ ] Create Mermaid drawer: Project → Tasks → Milestones → Invoices dependency map
- [ ] Add real-time WebSocket updates for KPIs (optional, if time permits)

**Evaluation Gate**:
```bash
# Visual regression testing
percy snapshot frontend/src/views/dashboard/
# E2E testing critical dashboard path
playwright test tests/e2e/dashboard.spec.ts
# Halt if: Visual changes > 5% without approval, or E2E fails
```

**Metrics**:
- KPI data freshness: (@ every refresh)
- Chart render time: < 100ms
- Dashboard load time: < 1.5s

**Business Logic & Visibility Desirables Context Injector**:
> "Management dashboard fully rendered. x # of KPIs active. y # of charts visualized. z # of tables populated. Dependency maps generated. Proceeding to data import system..."

---

### **MACRO PHASE 4: DATA IMPORT & MIGRATION (Day 11)**

#### **M4.1: Multi-Format Import Engine** *(6 hours)*
**Agent**: IMPORT-MAPPER, QA-GATE
**Parallel Lanes**: 4 (CSV, Excel, JSON, API sync)
**Tasks**:
- [ ] Create `backend/scripts/import-cli.ts` (CLI tool)
- [ ] Create `backend/src/services/import.service.ts` (core logic)
- [ ] Implement streaming parsers: `csv-parser`, `xlsx`, `ndjson`
- [ ] Create mapping profile system (saved in `settings` collection)
- [ ] Create validation pipeline (Zod per entity)
- [ ] Create error reporting (HTML + JSON reports)
- [ ] Create `frontend/src/views/import/` UI (drag-and-drop + progress)

**Evaluation Gate**:
```bash
# Test import with sample data
pnpm import:csv --file tests/fixtures/projects.csv --profile test
# Verify: 1000 records imported in < 2 minutes, < 1% error rate
# Halt if: > 1% errors or import time > 5 minutes
```

**Metrics**:
- Throughput: > 10,000 rows/minute
- Validation accuracy: 100% (no invalid data inserted)
- Report generation: < 10 seconds

**Context Injector**:
> "Import engine validated. 4 formats supported. Mapping profiles functional. Error reporting active. Proceeding to adversarial testing..."

---

### **MACRO PHASE 5: ADVERSARIAL TESTING & HARDENING (Day 12)**

#### **M5.1: Multi-Persona Attack Simulation** *(8 hours)*
**Agent**: ADVERSARIAL-TESTER, SECURITY-AGENT
**Parallel Lanes**: 5 (Attacker personas: Malicious Employee, External Hacker, Malformed Data, Insufficient Permissions, Race Condition)
**Tasks**:
- [ ] Run OWASP ZAP scan on all endpoints (report in `security/zap-report.html`)
- [ ] Test RBAC matrix: 3 roles × 50 endpoints × 4 operations = 600 permutations
- [ ] Test workflow guard bypass attempts (50 invalid transitions)
- [ ] Test import data poisoning (SQL injection via CSV, XSS in JSON)
- [ ] Test JWT token manipulation (none alg, expired tokens, wrong signature)
- [ ] Test rate limiting effectiveness (100+ req/sec burst)
- [ ] Create `security/hardening-report.md` with fixes applied

**Evaluation Gate**:
```bash
# Security scan must pass
snyk test --severity-threshold=medium
# OWASP ZAP must show 0 high, 0 critical
# Halt if: Any critical or high vulnerabilities found
```

**Metrics**:
- Critical vulnerabilities: 0
- High vulnerabilities: 0
- Medium vulnerabilities: < 5 (documented with mitigation timeline)
- RBAC bypass attempts blocked: 100%
- Rate limit effectiveness: 100% (no successful overflow)

**Context Injector**:
> "Adversarial testing complete. Security posture validated. RBAC enforced. Rate limits active. All critical vulnerabilities remediated. Proceeding to documentation generation..."

---

### **MACRO PHASE 6: DOCUMENTATION & TRAINING PRODUCTION (Days 13-14)**

#### **M6.1: Employee Training Package** *(2 days)*
**Agent**: DOCUMENTATION-WRITER, UI-RENDERER
**Parallel Lanes**: 4
**Tasks**:
- [ ] Create `docs/employee-manual.md` (30 pages): Role-based guides for PM, Employee, Client, Admin
- [ ] Create `docs/admin-runbook.md` (50 pages): Deployment, backup, recovery, monitoring, scaling
- [ ] Create `docs/api-reference.md` (auto-generated from JSDoc)
- [ ] Create `docs/training-videos/scripts/` (10 video scripts, 5-10 min each)
- [ ] Create `docs/context-engineering.md` (context safety, poisoning prevention)
- [ ] Create `docs/wsl2-vs-windows.md` (environment-specific guidance)
- [ ] Generate screenshots for all major features (Puppeteer automation)