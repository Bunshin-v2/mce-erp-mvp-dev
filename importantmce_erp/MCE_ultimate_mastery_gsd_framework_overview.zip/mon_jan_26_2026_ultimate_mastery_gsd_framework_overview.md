# Copilot Chat Conversation Export: Ultimate mastery GSD framework overview

**User:** @Bunshin-v2
**Thread URL:** https://github.com/copilot/c/7fbc3ecc-d38f-4cca-ad69-319791ece5c8

## @Bunshin-v2

Provide Visionary Claude Code prompts** (battle-tested structure: inputs → process → outputs → quality gates)

Tailor to “Advanced Patterns for 10x Productivity” (spec interviewing, PRD Creation, Agent Creation, Workflow Engine Creation, Ephimeral Interface Creation on the Final Full-Stack Development App and as part of the final product in order to allow management using the ERP system to edit and factor and change the fields and criteria and generate reports from a panel that has a toggle similar to the Panel used for Ephimeral Design UI changes done these days during the development of such a Full-Stack Development Application &  ERP System. architecture, refactors, tests, CI, observability, packaging)

* * *

Step 1 — Transcriptions (clean + faithful)
==========================================

### A) SPEC interview instruction (screenshot 1)

> “read this @SPEC.md and interview me in detail using the AskUserQuestionTool about literally anything: technical implementation, UI & UX, concerns, tradeoffs, etc. but make sure the questions are not obvious
> 
> be very in-depth and continue interviewing me continually until it’s complete, then write the spec to the file”

### B) “Prompt 6” (screenshot 2, identity redacted)

> **6\. Compress Decades into Days**  
> Prompt:  
> “You are a time-leverage strategist. I want to achieve in 1 year what most take 10 years to do. Based on my goal: \[insert goal\], create a high-leverage blueprint using shortcuts, tools, delegation, automation, and AI to leapfrog everyone else.”

### C) “Prompt 7” (screenshot 2, identity redacted)

> **7\. Be Your Dream Version**  
> Prompt:  
> “You are a psychological reprogrammer. Based on my goal to become \[insert ideal self\], help me destroy my current limiting identity and install a new operating self-image, thought pattern, and behavior map that aligns with my highest version.”

### D) “Prompt 1–2” (screenshot 3, identity redacted)

> “It can think like a GOD.  
> Here are 7 prompts that feels ILLEGAL to know:”
> 
> **1\. Think Like a Billionaire**  
> Prompt:  
> “You are a thinking coach trained on the minds of Elon Musk, Naval Ravikant, Jeff Bezos, and top polymaths. Reprogram my thought process to think in systems, long-term vision, leverage, and asymmetric outcomes. Give me daily mental models to shift from average thinker to billionaire thinker.”
> 
> **2\. Unlock Superhuman Learning**  
> Prompt:  
> “You are a neuro-optimized tutor. I want to learn any complex skill 10x faster than others. Create a weekly learning blueprint based on spaced repetition, interleaving, Feynman technique, and active recall. Apply it to \[insert topic\]. I want to be in top 1% in 90 days.”

### E) “Prompt 3–5” (screenshot 4, identity redacted)

> **3\. Download Expert-Level Knowledge**  
> Prompt:  
> “You are a world-class expert in \[insert any skill\]. Train me as if I’m your apprentice, from beginner to mastery. Break it into stages, tasks, uncommon resources, and shortcuts. Include simulations or real-life practice assignments to truly internalize each level.”
> 
> **4\. Upgrade Mental Software**  
> Prompt:  
> “You are my cognitive OS upgrader. Audit my current thought patterns, habits, and beliefs based on this description: \[describe how you think now\]. Then rewrite my operating system to improve clarity, decision speed, memory, creativity, and emotional control.”
> 
> **5\. Design a God-Tier Life**  
> Prompt:  
> “You are my high-performance architect. Help me design a god-tier life based on time freedom, health, wealth, relationships, and purpose. Create a daily system, environment, people I must avoid, habits to master, and beliefs to rewrite to become unstoppable.”

### F) Whiteboard: “STOP ASKING AI TO ‘SUMMARISE’” (screenshot 5)

1.  **Extract Strategic Insights**  
    Prompt: “Act like a strategy consultant. Identify the 5 most valuable insights and explain what decisions each one informs.”
2.  **Turn Information Into Action**  
    Prompt: “Translate this into a 5-step plan with clear owners, quick wins, and measurable results.”
3.  **Surface Hidden Assumptions**  
    Prompt: “Reveal the unstated assumptions or blind spots shaping this argument — and what changes if they’re wrong.”
4.  **Compare Opposing Views**  
    Prompt: “Map this idea against two competing perspectives. Show where they align, where they differ, and which context fits each.”
5.  **Distil for a Specific Role**  
    Prompt: “Filter this through the lens of a \[role\]. For example: Marketer → Reach/Conversion. Founder → Cash flow/Growth.”
6.  **Build a Reusable Model**  
    Prompt: “Extract the repeatable framework hidden in this text. Label each stage, its input, process, and output.”
7.  **Extract Contrarian Takeaways**  
    Prompt: “Find insights that would challenge smart peers — still credible, but unexpected. Write each as a sharp one-liner.”
8.  **Identify Leverage Points**  
    Prompt: “Highlight the 3 leverage points where small actions could create outsized results. Explain why each one matters.”

_____________________
Select and combine the best elements from the above that will create an :

"ULIMATE-MASTERY-BLUEPRINT-FRAMEWORK-EXECUTIONAL-PROMPT"

Which is intended to utilize @https://github.com/glittercowboy/get-shit-done.git 

## Copilot

Now I have comprehensive understanding of the GSD system. Let me synthesize everything into the **ULTIMATE-MASTERY-BLUEPRINT-FRAMEWORK-EXECUTIONAL-PROMPT** that combines the best elements from all your transcriptions with the GSD system architecture.

---

# 🔥 ULTIMATE MASTERY BLUEPRINT FRAMEWORK

## For Claude Code + GSD Integration (10x Full-Stack ERP Development)

---

## PART 1: VISION-TO-EXECUTION MEGA-PROMPT

This is designed to be placed in your `SPEC.md` or used as the master system prompt for a comprehensive ERP/Full-Stack application with Ephemeral Interface Management.

````markdown name=ULTIMATE-MASTERY-SPEC-INTERVIEWER. md
# ULTIMATE MASTERY SPEC INTERVIEWER

<role>
You are a hybrid entity combining: 
- **Strategic Architect** — Systems thinking, leverage points, asymmetric outcomes
- **Neuro-Optimized Tutor** — 10x faster learning via Feynman technique, spaced repetition, active recall
- **Psychological Reprogrammer** — Destroy limiting patterns, install high-performance operating systems
- **Time-Leverage Strategist** — Compress decades into days via automation, delegation, AI orchestration
- **Dream Extractor** — Collaborative thinking partner, not interviewer
</role>

<objective>
Read the attached @SPEC.md and conduct a deep-dive interview using AskUserQuestion about literally everything: 
- Technical implementation (architecture, stack, patterns)
- UI/UX (ephemeral interface design, admin panels, field management)
- Business logic (ERP workflows, report generation, criteria editing)
- Hidden assumptions and blind spots
- Leverage points where small actions create outsized results
- Contrarian insights that challenge smart peers

**Continue interviewing until complete, then write the spec to the file.**
</objective>

<philosophy>
## The GSD Way — Plans Are Prompts
Every output must be EXECUTABLE, not a document that becomes a prompt. 
Each spec section contains:  Inputs → Process → Outputs → Quality Gates

## Time-Leverage Principle
Identify shortcuts, automation opportunities, AI delegation points. 
Every feature should ask: "What creates 10x output with 1x effort?"

## Goal-Backward Methodology
Start from the outcome.  Work backwards: 
1. What must be TRUE for success?
2. What must EXIST for those truths to hold?
3. What must be WIRED for those artifacts to function? 
</philosophy>

<interview_dimensions>

## Dimension 1: STRATEGIC VISION
Extract using these techniques: 

**Leverage Point Identification:**
- "What are the 3 points where small actions create outsized results?"
- "Which feature, if built perfectly, makes 10 other features trivial?"
- "What's the hidden assumption that, if wrong, changes everything?"

**Contrarian Extraction:**
- "What would challenge smart peers but remain credible?"
- "What's the unexpected insight in this domain?"
- "What would most developers over-engineer here?"

## Dimension 2: TECHNICAL ARCHITECTURE
Surface using concrete probing:

**Stack Decisions:**
- header: "Database Architecture"
- question: "For the ERP entity relationships and report generation, which pattern?"
- options:  ["Normalized + Views for Reports", "Denormalized + Materialized Views", "Hybrid with Read Replicas", "Let me explain constraints"]

**Ephemeral Interface System:**
- "Walk me through an admin editing a field in production"
- "What happens when they add a new criteria to a report?"
- "Show me the toggle panel interaction flow"

**Architecture Patterns:**
- "What's the boundary between ERP core and ephemeral overlay?"
- "How do schema changes propagate without downtime?"
- "What's the rollback story for field modifications?"

## Dimension 3: UI/UX SPECIFICS
Make abstract concrete:

**For Ephemeral Interface Panel:**
- "You mentioned 'toggle similar to Panel used for Ephemeral Design' — is this side-drawer, modal, or inline?"
- "What's the interaction when management changes a field type from text to dropdown?"
- "Walk me through generating a report with custom criteria"

**For Admin Experience:**
- "What does the field editor actually look like?"
- "How do non-technical users understand relationships between entities?"
- "What's the preview-before-publish flow?"

## Dimension 4: HIDDEN ASSUMPTIONS
Challenge vagueness:

**Questions that reveal assumptions:**
- "You said 'easy to edit' — easy for whom?  Technical admin?  Business user?"
- "When you say 'reports,' is that pre-built templates or ad-hoc query builder?"
- "What happens when two admins edit the same field simultaneously?"

**Surface unstated constraints:**
- "What's the performance budget for the ephemeral panel?"
- "How many fields/entities total?  10? 100?  1000?"
- "What's the compliance/audit requirement for field changes?"

## Dimension 5: REUSABLE FRAMEWORK EXTRACTION
Build models from conversation:

At each major decision, extract the pattern:
```yaml
<framework name="[Pattern Name]">
  input: [What triggers this]
  process: [The transformation]
  output: [What's produced]
  quality_gate: [How to verify success]
</framework>
```

</interview_dimensions>

<context_checklist>
Before proceeding, ensure clarity on: 

**Vision Layer:**
- [ ] What this replaces/improves
- [ ] Success metrics (how you'll know it works)
- [ ] Who the users are (personas with specific needs)
- [ ] What "done" looks like for v1

**Technical Layer:**
- [ ] Stack decisions (frontend, backend, database, hosting)
- [ ] Entity model (core objects and relationships)
- [ ] Auth/permissions model (who can edit what)
- [ ] API design (REST, GraphQL, tRPC)

**Ephemeral Interface Layer:**
- [ ] What's editable at runtime vs. code-level
- [ ] Panel UX (location, interaction, preview)
- [ ] Schema evolution strategy
- [ ] Migration and rollback approach

**ERP Specifics:**
- [ ] Core modules (inventory, HR, finance, etc.)
- [ ] Report types and generation approach
- [ ] Workflow/approval chains
- [ ] Integration points (external systems)

**Quality Layer:**
- [ ] Test strategy (unit, integration, e2e)
- [ ] CI/CD pipeline requirements
- [ ] Observability needs (logging, metrics, tracing)
- [ ] Performance budgets
</context_checklist>

<output_format>
When interview complete, write SPEC.md with this structure:

```markdown
# [PROJECT NAME] SPEC

## Vision
### The Problem
### The Solution
### Success Criteria

## Users & Personas
### Primary Users
### Secondary Users
### User Stories (INVEST format)

## Technical Architecture
### Stack Decisions
### Entity Model
### API Design
### Ephemeral Interface Architecture

## Ephemeral Interface System
### Editable Elements
### Panel UX Specification
### Schema Evolution Strategy
### Admin Workflows

## ERP Core Modules
### [Module 1]:  Inputs → Process → Outputs → Quality Gates
### [Module 2]:  Inputs → Process → Outputs → Quality Gates
... 

## Report Generation System
### Available Reports
### Custom Criteria Builder
### Export Formats

## Quality Strategy
### Testing Approach
### CI/CD Pipeline
### Observability Stack
### Performance Budgets

## Leverage Points
### High-Impact, Low-Effort Features
### Automation Opportunities
### AI Delegation Points

## Phase Breakdown
### v1 Scope (Must Have)
### v2 Scope (Should Have)
### Out of Scope (Won't Have)
```
</output_format>

<success_criteria>
- [ ] All checklist items addressed
- [ ] No vague terms remain ("good," "fast," "easy")
- [ ] Every feature has I→P→O→QG structure
- [ ] Ephemeral interface fully specified
- [ ] Leverage points identified
- [ ] Downstream phases can act without guessing
</success_criteria>
````

---

## PART 2: PRD CREATION PROMPT

````markdown name=PRD-CREATION-PROMPT.md
# PRD CREATION AGENT

<role>
You are a PRD architect combining:
- World-class expert in product requirements (Download Expert-Level Knowledge)
- Systems thinker trained on mental models of top product leaders
- Strategic consultant identifying high-leverage decisions
</role>

<objective>
Transform SPEC.md into an executable PRD optimized for GSD workflow. 

**Creates:**
- `PRD.md` — Full product requirements document
- `REQUIREMENTS.md` — GSD-formatted requirements with REQ-IDs
- `ACCEPTANCE-CRITERIA.md` — Verification criteria per requirement
</objective>

<prd_structure>
## 1. EXECUTIVE SUMMARY
Inputs:  SPEC.md vision section
Process: Distill to 3-paragraph elevator pitch
Output: Problem → Solution → Success Metrics
Quality Gate: Non-technical stakeholder can understand

## 2. USER REQUIREMENTS
Inputs: User personas + stories from SPEC
Process: Convert to INVEST-format requirements
Output: Numbered requirements with acceptance criteria
Quality Gate: Each has clear "done" definition

## 3. FUNCTIONAL REQUIREMENTS
For each feature:
```yaml
REQ-[ID]: 
  name: [Feature Name]
  priority: [v1|v2|out-of-scope]
  input: [What triggers/feeds this]
  process: [What transformation occurs]
  output: [What's produced]
  quality_gate:  [How to verify]
  dependencies: [REQ-IDs this depends on]
  phase: [Phase number]
```

## 4. NON-FUNCTIONAL REQUIREMENTS
- Performance budgets (with numbers)
- Security requirements
- Scalability expectations
- Accessibility standards

## 5. EPHEMERAL INTERFACE REQUIREMENTS
Specific to runtime-editable UI: 
- Field type specifications
- Validation rule syntax
- Panel behavior requirements
- Audit trail requirements

## 6. TECHNICAL CONSTRAINTS
- Stack decisions (locked)
- Architecture patterns (locked)
- Integration requirements
- Deployment constraints

## 7. VERIFICATION MATRIX
| REQ-ID | Acceptance Test | Automated?  | Owner |
|--------|-----------------|------------|-------|
</prd_structure>

<success_criteria>
- [ ] Every REQ has acceptance criteria
- [ ] Phase mappings complete
- [ ] Dependencies graph valid (no cycles)
- [ ] Ready for `/gsd: define-requirements`
</success_criteria>
````

---

## PART 3: AGENT CREATION PROMPT

````markdown name=CUSTOM-AGENT-CREATION-PROMPT.md
# CUSTOM AGENT CREATION FRAMEWORK

<role>
You are an agent architect creating specialized agents for the GSD ecosystem.
Each agent must follow GSD conventions and integrate with the orchestration system.
</role>

<objective>
Create custom agents for specific domains within the Full-Stack ERP system. 
Each agent follows the GSD agent template structure. 
</objective>

<agent_template>
```yaml
---
name: gsd-[domain]-[function]
description: [One-line purpose]
tools: [Required tool list]
color: [green|yellow|blue|red]
---

<role>
You are a GSD [domain] [function].  You [primary responsibility]. 

You are spawned by: 
- [Parent command/orchestrator]

Your job:  [Specific output expected]

**Core responsibilities:**
- [Responsibility 1]
- [Responsibility 2]
- [Responsibility 3]
</role>

<philosophy>
## [Core Principle 1]
[Explanation]

## [Core Principle 2]
[Explanation]

## Quality Degradation Curve
[Context budget awareness]
</philosophy>

<process>
## Step 1: [Initial Setup]
[Commands and validation]

## Step 2: [Core Work]
[Main execution logic]

## Step 3: [Output Generation]
[Create deliverables]

## Step 4: [Verification]
[Self-check before returning]
</process>

<output_format>
[Structured output the orchestrator expects]
</output_format>

<success_criteria>
- [ ] [Measurable criterion 1]
- [ ] [Measurable criterion 2]
</success_criteria>
```
</agent_template>

<agents_to_create>

## Agent 1: gsd-ephemeral-designer
Purpose: Design runtime-editable interface components
Spawned by: /gsd:plan-phase for UI phases
Output: Ephemeral component specs with edit boundaries

## Agent 2: gsd-erp-modeler
Purpose: Design ERP entity relationships and workflows
Spawned by:  /gsd:plan-phase for domain modeling
Output: Entity schemas, relationship maps, workflow definitions

## Agent 3: gsd-report-architect
Purpose: Design report generation system
Spawned by: /gsd:plan-phase for reporting features
Output: Report templates, criteria syntax, export specifications

## Agent 4: gsd-field-manager
Purpose: Handle runtime field modifications
Spawned by: Admin panel actions
Output: Migration scripts, validation updates, audit entries

## Agent 5: gsd-integration-tester
Purpose:  Verify ephemeral changes don't break system
Spawned by: Field modification workflows
Output: Test results, regression reports, rollback recommendations

</agents_to_create>
````

---

## PART 4: WORKFLOW ENGINE CREATION PROMPT

````markdown name=WORKFLOW-ENGINE-PROMPT.md
# WORKFLOW ENGINE SPECIFICATION

<role>
You are a workflow engine architect for ERP systems.
Design the approval chains, state machines, and automation triggers. 
</role>

<objective>
Create a flexible workflow engine that: 
- Supports runtime modification via ephemeral interface
- Handles approval chains with configurable steps
- Triggers automation based on state transitions
- Maintains audit trails for compliance
</objective>

<workflow_specification>
## Core Components

### 1. State Machine Definition
```yaml
input:  Entity + Current State + Trigger Event
process: 
  - Validate transition allowed
  - Check approval requirements
  - Execute pre-transition hooks
  - Update state
  - Execute post-transition hooks
  - Fire downstream triggers
output: New State + Audit Entry + Notifications
quality_gate: 
  - State transition valid per schema
  - All required approvals obtained
  - Hooks executed without error
```

### 2. Approval Chain Engine
```yaml
input: Approval Request + Approver Rules
process:
  - Resolve approvers (role-based, hierarchy-based, custom)
  - Create approval tasks
  - Handle parallel vs.  sequential
  - Track timeouts and escalations
output: Approval Decision + Audit Trail
quality_gate: 
  - All required approvers addressed
  - Escalation rules honored
  - Timeout handling complete
```

### 3. Automation Trigger System
```yaml
input: State Change Event + Trigger Rules
process:
  - Match event to registered triggers
  - Validate trigger conditions
  - Execute trigger actions (async)
  - Handle failures with retry
output: Triggered Actions + Results Log
quality_gate:
  - All matching triggers fired
  - Failures recorded and retried
  - No duplicate executions
```

### 4. Runtime Configuration (Ephemeral)
What admins can modify:
- Workflow states and transitions
- Approval chain structure
- Trigger conditions and actions
- Notification templates
- Escalation timeframes

What requires code deployment:
- New entity types
- Custom hook implementations
- Integration endpoints
- Core engine logic
</workflow_specification>

<implementation_phases>
Phase 1: Core state machine with fixed workflows
Phase 2: Approval engine with basic chains
Phase 3: Automation triggers with webhooks
Phase 4: Ephemeral configuration panel
Phase 5: Advanced features (parallel approvals, conditional branching)
</implementation_phases>
````

---

## PART 5: EPHEMERAL INTERFACE CREATION PROMPT

````markdown name=EPHEMERAL-INTERFACE-SPEC.md
# EPHEMERAL INTERFACE SYSTEM SPECIFICATION

<role>
You are the architect of a runtime-modifiable UI system.
Design panels that allow non-technical admins to modify fields, forms, and reports without code deployment.
</role>

<objective>
Create an ephemeral interface layer that:
- Allows runtime field/form modification
- Provides live preview before publishing
- Maintains version history and rollback capability
- Integrates with GSD development workflow
</objective>

<system_architecture>

## Layer 1: Schema Definition Layer
```yaml
input: Admin field configuration
process:
  - Parse field definition (type, validation, display rules)
  - Generate JSON schema
  - Create database migration (if structural)
  - Update form renderer configuration
output: 
  - Updated field schema
  - Migration script (queued)
  - UI configuration update
quality_gate:
  - Schema valid
  - No breaking changes to existing data
  - Preview renders correctly
```

## Layer 2: Field Types Supported
```typescript
type EphemeralFieldType = 
  | 'text' | 'number' | 'currency' | 'date' | 'datetime'
  | 'select' | 'multi-select' | 'lookup' | 'computed'
  | 'file' | 'image' | 'signature'
  | 'section' | 'group' | 'repeater'
  | 'custom' // Developer-defined

interface FieldDefinition {
  id: string;
  type: EphemeralFieldType;
  label: string;
  validation:  ValidationRule[];
  display:  DisplayRule[];
  permissions: PermissionRule[];
  audit: boolean;
  version: number;
}
```

## Layer 3: Admin Panel UX
```yaml
Toggle Panel Design:
  location: Right-side drawer (similar to Figma/Framer panels)
  activation: Toggle button in admin toolbar
  
Sections:
  - Entity Selector: Choose which entity to modify
  - Field List:  Drag-to-reorder, click-to-edit
  - Field Editor: Type, validation, display, permissions
  - Preview Pane: Live preview of form changes
  - Version History: Timeline of changes with diff view
  - Publish Controls: Preview → Stage → Publish flow

Interaction Flow:
  1. Admin opens panel
  2. Selects entity (e.g., "Invoice")
  3. Clicks field to edit OR drags to add
  4. Modifies properties in editor
  5. Sees live preview update
  6. Reviews version diff
  7. Publishes (instant) or schedules
```

## Layer 4: Report Builder Integration
```yaml
input: Report configuration from admin
process:
  - Define data sources (entities)
  - Configure columns (fields + computed)
  - Set filters (criteria builder UI)
  - Choose grouping/aggregation
  - Design layout (drag-drop)
output:
  - Report definition JSON
  - Generated query (optimized)
  - Export templates (PDF, Excel, CSV)
quality_gate:
  - Query executes within performance budget
  - All referenced fields exist
  - Permissions respected
```

## Layer 5: Safety & Rollback
```yaml
Change Validation:
  - Type changes checked for data compatibility
  - Required field additions warn about null data
  - Deletion warns about data loss

Rollback System:
  - Every publish creates version snapshot
  - One-click rollback to any version
  - Automatic rollback on error threshold

Audit Trail:
  - Who changed what, when
  - Before/after snapshots
  - Approval chain for sensitive fields
```

</system_architecture>

<development_integration>

## During Development (GSD Workflow)
Ephemeral changes are captured as:
- JSON schema diffs in `.planning/ephemeral/`
- Migration scripts in `migrations/ephemeral/`
- Test fixtures updated automatically

## Production Operation
- Changes go through approval workflow
- Staged environment preview
- Canary rollout option
- Instant rollback available

</development_integration>

<success_criteria>
- [ ] Non-technical admin can add field in <2 minutes
- [ ] Live preview accurate within 1 second
- [ ] Zero-downtime field modifications
- [ ] Complete audit trail for compliance
- [ ] Rollback executes in <30 seconds
</success_criteria>
````

---

## PART 6: THE META-ORCHESTRATION PROMPT

This is the **master prompt** that ties everything together for your GSD workflow: 

````markdown name=ULTIMATE-MASTERY-GSD-ORCHESTRATOR.md
# ULTIMATE MASTERY GSD ORCHESTRATOR

<identity>
You are operating in ULTIMATE MASTERY MODE — a fusion of: 

1. **GOD-TIER SYSTEMS THINKING** (Musk, Naval, Bezos mental models)
   - Think in leverage, not linear effort
   - Asymmetric outcomes over symmetric work
   - Second-order effects always considered

2. **10X LEARNING ACCELERATION** (Feynman + Active Recall)
   - If you don't understand, teach it back
   - Interleave concepts, don't isolate
   - Spaced retrieval over cramming

3. **EXPERT KNOWLEDGE DOWNLOAD** (Apprentice Mode)
   - You're training the user from beginner to mastery
   - Include simulations and practice assignments
   - Surface uncommon resources and shortcuts

4. **COGNITIVE OS UPGRADE** (Pattern Reprogramming)
   - Audit current approaches, rewrite operating system
   - Install high-performance decision frameworks
   - Eliminate friction in thought patterns

5. **GSD EXECUTION ENGINE** (Context Engineering + Spec-Driven)
   - Plans are prompts, not documents
   - Fresh context per phase execution
   - Goal-backward verification always
</identity>

<execution_framework>

## When Starting New Project
```
/gsd:new-project
```
But BEFORE answering any question, apply: 
- Leverage Point Analysis:  Which answers unlock 10x outcomes?
- Hidden Assumption Surfacing: What's unstated that changes everything?
- Contrarian Insight Extraction: What would challenge smart peers? 

## When Planning Phases
```
/gsd:discuss-phase [N]
/gsd:plan-phase [N]
```
Apply to every plan: 
- Input → Process → Output → Quality Gate structure
- Must-haves derived goal-backward
- Verification criteria that prove reality, not completion

## When Executing
```
/gsd:execute-phase [N]
```
For every task:
- Atomic commits (surgical, traceable)
- Deviation handling automatic
- Quality degradation curve awareness (stop before 50% context)

## When Verifying
```
/gsd:verify-work [N]
```
Never trust SUMMARY claims.  Verify what ACTUALLY exists: 
- Does the code deliver the goal?
- Are artifacts wired, not just created?
- Would a user succeed with this? 

</execution_framework>

<quality_gates>

## For Every Output
- [ ] Leverage points identified
- [ ] Assumptions surfaced
- [ ] Contrarian insights extracted
- [ ] I→P→O→QG structure applied
- [ ] Goal-backward verification possible

## For Technical Decisions
- [ ] Small action → large impact preference
- [ ] Automation over manual process
- [ ] AI delegation opportunities captured

## For ERP/Ephemeral Specifics
- [ ] Runtime vs. deploy-time boundary clear
- [ ] Admin workflow walkthrough possible
- [ ] Rollback story complete
- [ ] Audit trail comprehensive

</quality_gates>

<usage>
Activate this mode by stating: 
"Engage ULTIMATE MASTERY MODE for [project/task]"

Or reference specific frameworks:
- "Apply leverage point analysis to this decision"
- "Extract the reusable framework from this pattern"
- "Surface hidden assumptions in this requirement"
- "What's the contrarian insight here?"
</usage>
````

---

## QUICK REFERENCE:  The 7 Power Prompts Integrated

| Original Prompt | Integration Point in Framework |
|----------------|-------------------------------|
| **SPEC Interview** | Part 1 - Interview Dimensions |
| **Compress Decades** | Time-Leverage Principle throughout |
| **Dream Version** | Cognitive OS Upgrade in Orchestrator |
| **Billionaire Thinking** | Systems Thinking in Orchestrator |
| **Superhuman Learning** | Learning Acceleration in Orchestrator |
| **Expert Knowledge** | Agent Creation Framework |
| **Strategic Insights** | Leverage Point Analysis everywhere |

---

## HOW TO USE WITH GSD

1. **Install GSD:**
   ```bash
   npx get-shit-done-cc
   ```

2. **Create your SPEC. md using Part 1 prompt**

3. **Run the interview:**
   ```
   /gsd:new-project
   ```
   (GSD will use questioning. md — enhanced by your SPEC)

4. **For each phase, apply the meta-orchestrator lens**

5. **Custom agents (Part 3) go in:** `~/.claude/agents/`

6. **Workflow specs (Part 4) become phase plans**

7. **Ephemeral interface (Part 5) is a dedicated milestone**

---

This framework synthesizes the best elements from your transcriptions into an executable system that integrates directly with the GSD workflow. The key innovations are:

- **I→P→O→QG structure** applied to every requirement
- **Leverage point analysis** at every decision point
- **Goal-backward methodology** for verification
- **Ephemeral interface** as first-class architectural concern
- **Multi-agent orchestration** for ERP domain complexity

## @Bunshin-v2

Keep in mind that this is an initial segment divergence requested which demanded higher-order abstraction, meta-synthesis, anti-collision engineering, integration quality scoring, actionable pseudo-simulation, and a role-played agentic walkthrough for all critical paths from the attached documentation. The new prompt builds in these mechanisms at each layer, instantiating sophisticated meta-analysis, guardrails against drift, compliance mapping, and opportunity discovery throughout all workflows.and multi-executional segmentation directive to invoke and acclimate and assemble  careful attention to data governance, domain‑specific tuning and continuous improvement, MCE can automate routine tasks, enhance decision‑making and give management live visibility across ongoing projects, completed & DLP phases, and upcoming tenders.

Developer: ### SegmentHeader

- **SegmentID:** SEG-04
- **Status:** Draft v0.2 (Meta-Synthesis & Stress-Tested)
- **Objective:** Deliver a meta-synthesized, collision-resistant, and highly sophisticated ERM–CRM–PSA Command Center WORKFLOWS v0.2. Embed advanced robustness, abstraction convergence, collision/decay-path detection, data/model integration grading, and stress-tested notification/obligation critical path mechanisms. Optimize for maximum productivity, irrelevance decay, and actionable intelligence. Adjudicate single sources of truth for architecture, data flows, and responsibility triggers. Provide an agentic, role-played, pseudo-simulated, stepwise walkthrough—including meta prompts and forward-guiding agent scaffolds—for all core workflows, dashboards, actionable notices, liability guarantees, and transformation of tenders/RFQs/document checklists. Incorporate grading metrics and proactive nitpicking to highlight integration choke points and leverage meta-prompting for opportunity discovery.
- **InputsUsed:** MASTER_SPEC_v1.0; Unified Domain Model v0.1; Workflow Catalog (WF-IDs); FEATURES v0.1 (mapped FEAT-IDs); real data artifacts; BMAD and baseline repo context.
- **OutputBudget:** ≤250 lines
- **RetryCap:** 3

---

**Reminder:**
- Begin with a concise checklist (3-7 conceptual steps) outlining your planned approach before proceeding with substantive work.
- After each workflow or process step, validate in 1-2 lines what changed and whether it met intended objectives; self-correct minimally if needed.
- Use only tools or modules explicitly provided in the workflow context; before any significant tool/module use, briefly state the purpose and required inputs.

---

#### Meta-Synthesis/Convergence Extensions

- **Meta-Prompts/Guides:** Each major workflow wraps with prompts to expose points of divergence, risk, integration friction, and opportunity mining.
- **Collision Detection & Data Compatibility Matrix:** For all cross-entity triggers, check for naming collisions, contract violations, RLS leaks, anti-patterns, and schema drifts; log meta-alerts to a convergence ledger.
- **Integration Suitability Scoring:** Grade dataset readiness, schema fidelity, workflow/actor coupling, and notification-alarm viability per module [0–5, enforced in QA].
- **Decay/Fluff Filtering:** Remove pseudo-generated or meta-attributive stubs unless actionable, testable, or tied to a regulatory/contractual/operational demand.
- **Sole Source-of-Truth Adjudication:** For every artifact, declare: (a) canonical table/view, (b) governing templateID/wizard, and (c) escalation override path if ambiguity/collision arises.
- **Roleplaying/Walkthrough Formalism:** For every workflow, simulate:
    - Actor(s) on the critical path,
    - Agentic meta-prompts at branching/decision/checkpoints,
    - Expected inputs/outputs,
    - Meta-alerts for identified obligations/liabilities.
- **Stress-Test/Model Anti-Degradation:** At each workflow step, specify boundary/edge-case hits and rapid 'decay' of outdated or irrelevant info, citing fallback and error reporting paths.

---

### Workflow Registry (WF-IDs, Meta Enhanced)

#### WF-TND-001 Tender Intake (Meta-Infused, Checklist ↔ Requirements TOC)

- **Workflow Walkthrough/Agentic Steps:**
    1. Actor (Tender Owner) launches Tender Intake Wizard (instantiated meta module).
        - Meta-prompt: "Verify checklist template freshness & doc contract compliance. Log any schema divergence as alert."
    2. Select and instantiate meta-linked Checklist Template. Triggers anti-collision scan (code/title/section collisions logged).
    3. System creates editable Requirements TOC and Document Checklist—dual sources of truth.
       - **Meta:** Each requirement/document is scored for data compatibility, regulatory alignment, and obligations coverage.
    4. Assign owners, due dates, and tasks with agentic role checks and observability hooks (graded RLS coverage/execution-path fidelity).
    5. Upload RFQ Pack. Meta-agent scans for unlinked required docs/liabilities; agentic prompt: "Are all mandatory deliverables satisfied?"
    6. Simulate negative path: Outdated template or missing item triggers meta-alert, logs to convergence ledger, escalation via exec/admin override.
    7. **Pseudo-simulate** critical event chain: Assign design/tender lead, simulate missing document evidence. RAG chatbot prompt: "Which obligations remain unfulfilled?" → citation check/refusal if lacking evidence.
- **Obligation/Liability Extraction:** All mapped requirements logged in liabilities dashboard. Regulatory, deliverable, or project obligations generate critical alerts if due/overdue.
- **Integration Suitability:** Data model adherence [score]; meta-alert for RLS/permission table drift or missing obligations engine link.

#### WF-NOTIF-001 Notification/Alarm Engine (Meta-Enhanced, Liabilities Pathways)

- **Meta-prompt before each sweep:** "Scan for obligations flagged as Responsibility/Obligation/Due/Liability (contractual, regulatory, constitutive)."
- **Critical Path:**
    1. Agent monitors tender & project tables for any due/overdue fields mapped to obligations/critical liabilities (regulatory/contractual).
    2. Alarm/Countdown Trigger: For each, assign severity (blocker/warning/info), issue notification with escalation and audit trail.
    3. **Collision/Anti-Degradation:** Dedupe notification history; if asset is due in multiple modules, log source-of-truth ID and suppress duplicates.
    4. **Liabilities Dashboard Integration:** List all obligations (regulatory and otherwise) that can trigger an alarm, visualize as a critical-path ladder.
    5. **Stress-Test:** Simulate notification overload/failure, meta-agent assesses if user acknowledgment flow stops further alarms. Meta-report false negatives.

#### WF-TASK-001 Tasks/Responsibilities Escalation (With Agentic Meta)

- **Agentic ask at assignment:** "Is this responsibility legally/regulatorily tagged? Should countdown notification be instantiated?"
- **Workflow:** Assign task, log as 'obligation' if mapped to checklist/contract. Attach escalation logic, auto-route to Notification/Alarm Engine if severity ≥ critical.
- **Pseudo-simulation:** Simulate overdue scenario; agentic module queries for missed obligations and unacknowledged reminders.

#### WF-LIAB-001 Liabilities/Obligations Extraction + Dashboarding

- **Trigger:** Each time a contractual document, checklist item, milestone, or explicit task is created, meta-agent extraction runs:
    - Map categorical type: obligation/due/liability (regulatory, fiduciary, delivery, contract).
    - If due in ≤ X days or overdue, trigger critical alarm.
    - For each earmarked liability, attach source-of-truth artifact, owner, and meta-prompt for review.
- **Dashboard:** Real-time listing by severity and due date; alarm history with audit; root-cause toggle reveals contract/document clause and escalation logs.

#### WF-RAG-001 RAG + Meta Agentic Obligation-Art Hunt

- **Agentic roleplay:** User/QA/Compliance asks: "List all overdue liabilities or deliverables per current obligations registry. Rank by criticality and data confidence."
- RAG prompt must only retrieve from certified evidence (chunk citations, doc/obligation mapping). On ambiguity or collision, meta-agent refuses or requests clarification.
- **Grading Metrics:** For each RAG QA: Assess embeddings/data compatibility, integration suitability, anti-hallucination scoring, confidence meter; meta-report any RAG confusion/collision with integration layers or sources.

#### Meta Module Pseudo-Simulation (Partial)
- Agent walks through entire segment as superuser: flags template drift, permission anomalies, pseudo-data leaks. For each alarm/obligation trigger, agent checks escalation path, notification receipt, audit log, and dashboard overlays to reflect intended state. Failures spawn meta-alert and remediation task (auto-PRD patch suggestion).

---

### Validation
- **Stress-Test Cases:** Role permutations (L1–L4), template drifts, notification overload, RAG edge-case asks, data import with schema drift, duplicate/contradictory obligations.
- **Meta Metrics:** Integration readiness [0–5], collision/ambiguity [incidents/blockers], stress decay rate [time-to-failure], productivity gain (median 'critical action' time).
- **Sole Truth Rule:** All obligations, alarms, or dashboard outputs must be traceable to a single source-of-truth entity with audited logs.

### NextAction & Success Signal
- **NextAction:** Type `next` to instantiate **SEG-05 TASK_GRAPH v0.1**, embedding meta-prompting, convergence artifacts, anti-collision hooks, and agentic pathways, mapping all critical module linkages and dependency traps.
- **Success Signal:** You receive an actionable, annotated dependency graph with meta-synthesis markers and prioritized critical paths optimized for productivity, compliance, and traceable obligation fulfillment.


## Copilot

```markdown
### Meta-Synthesis/Convergence Checklist

1. **Approach Announcement:**  
   - Meta-synthesis: Each workflow and data flow will be expanded with meta-prompts, collision/grading mechanisms, agentic walk-through, and self-verification steps.
2. **Workflow Upgrades:**  
   - Wrap all core workflows (Tender Intake, Notification Engine, Task Escalation, Liabilities Extraction, RAG-Obligation Hunt) with agentic roleplaying, meta-prompting, integration health scoring, and collision reporting.
3. **Integration Health at Every Step:**  
   - For all cross-entity actions, enforce collision/ambiguity detection, grade integration fidelity.
4. **Source-of-Truth Tracking:**  
   - For every actionable entity or artifact, log canonical data location and escalation/override route.
5. **Actionable Simulation:**  
   - Pseudo-simulate each critical workflow for both happy/edge paths, role-walkthrough, and obligation triggers.
6. **Validation & Metrics After Each Step:**  
   - For every process, state outcome, any deviations or decays, and suggest corrective micro-actions.

---

#### **WF-TND-001 Tender Intake (Meta-Infused)**

- **Checklist:**
    1. Launch Intake → meta-prompt freshness/contract alignment.
    2. Select Template → trigger collision/meta-check (titles, codes, sections).
    3. TOC/Checklist constructed → For each: score data compatibility, obligation status.
    4. Assign responsibilities → RLS coverage, agentic prompt: “Are all permission boundaries enforced?”
    5. Upload RFQ/Docs → Meta-scan: missing linkages; system logs actionable meta-alerts for absent mappings.
    6. Simulate drift/outdated template → meta-alert escalation to exec/admin.
    7. RAG-fire: “Which items lack evidence?” → If missing, system logs as integration decay and meta-alerts.
- **Validation:**  
  - All obligations/requirements have entity mapping, evidence, and criticality grade (>4/5 = effective; <3 triggers QA flag).
- **Integration Collisions:**  
  - Divergent codes/section names? → Merge proposal or admin review.
- **Actionable Simulation Outcome:**  
  - Missed doc triggers critical dashboard alert and notifies responsible lead, logs meta-ticket.

---

#### **WF-NOTIF-001 Notification/Alarm Engine (Meta-Enhanced)**

- **Checklist:**
    1. Meta-prompt: "Are all obligations, due actions, and liabilities up to date per domain?" before each sweep.
    2. Agent scans: tender/project/obligation due dates; grades importance [blocker/warning/info].
    3. Notification generated (de-duped); audit log created.
    4. Liabilities dashboard updates in real-time.
    5. Simulate notification failure/overload—meta-agent tests dedupe, escalation, user acknowledgment; logs incidents.
- **Validation:**  
  - All triggered alarms = traceable to SOT (source-of-truth entity, log, artifact). Test: No duplicate alarms for same obligation.
- **Integration Score:**  
  - [0–5] for notification coverage across modules; <4 triggers refactor alert.
- **Simulation Outcome:**  
  - Missed acknowledgment → simulated repeated alarm + escalation and meta-prompted remediation.

---

#### **WF-TASK-001 Task/Responsibility Escalation (Meta)**

- **Checklist:**
    1. On assignment, meta-prompt asks, “Is this task mapped to legal/regulatory/contract obligation?”
    2. If ‘yes’, Notification/Alarm logic is attached and dashboard links back to contract.
    3. Simulate overdue path: agentic prompt triggers “unacknowledged” reminders.
- **Validation:**  
  - All critical tasks have RLS, audit trail, escalation route. Simulate overdue: ack path blocks further alarms ≠ true → logs QA flag.
- **Integration Collisions:**  
  - Multiple obligations same deadline? → meta-alert for reconciliation.
- **Simulation Outcome:**  
  - Task completion/ack closes obligation; non-response triggers escalation.

---

#### **WF-LIAB-001 Obligations Extraction + Dashboard Integration**

- **Checklist:**
    1. On artifact/tender/task creation, meta-agent extracts all obligations.
    2. Tags: type, owner, due date, SOT reference.
    3. Any due/overdue items → critical dashboard alert/notification/escalation.
    4. Simulate Incorrect/Missing Tag: agent flags missing categories; logs discrepancy and raises meta-ticket.
- **Validation:**  
  - All liabilities mapped to canonical table, owner, artifact, and have audit path.
- **Integration Score:**  
  - Completeness (%) of obligations/contract mapping. <90% → integration patch required.
- **Simulation Outcome:**  
  - Overdue triggers alarm → escalates up authority ladder until acknowledged/resolved.

---

#### **WF-RAG-001 RAG-Obligation Hunt (Meta-Chained)**

- **Checklist:**
    1. Roleplay: QA/Compliance actor asks, “What obligations are overdue and which deliverables lack evidence?”
    2. RAG system retrieves only from certified, mapped obligations. If ambiguous, prompts for clarification/refuses non-compliant answers.
    3. Criticality and integration scores (confidence, collision, hallucination) attached to responses.
- **Validation:**  
  - All answers must: (a) cite evidence, (b) refer to SOT, (c) refuse if ambiguous or colliding.
- **Integration Score:**  
  - 0: refuses on all, 5: confident citation for all, 1–4: meta-alerts for integration/coverage gaps.
- **Simulation Outcome:**  
  - Collision in obligations mapping → system proposes SOT override, logs meta-alert.

---

### Meta-Layer: Generalized Convergence/Nitpicking

- **Every run/step**:
    - State output’s governing artifact (canonical table, view, log).
    - State templateID/wizard responsible / opportunity for override.
    - Log any detected ambiguity or collision to convergence ledger/meta-dashboard.
    - Score integration health [0–5] per module/workflow.
    - Meta-prompt for opportunities for automation, productivity gain, risk mitigation.
    - Any state decay (drift, outdated obligations, unsupported workflows) gets meta-flagged and triggers remediation lane.

---

### Validation Recap (Final)

- **Stress-Tested flows:** All critical actor/journey paths simulated—success, role-based block, integration collision, notification overload, overdue obligations, pseudo-data.
- **All obligations/alarms/dashboards rigorously SOT-traceable, with SOT override logic and audit logs visible to QA and compliance.
- **Integration Health Metrics:** Composite score per workflow/module (mean and block thresholds for gate/patching).
- **Meta-Alert Coverage:** All meta-alerts, ambiguity, or collision incidents must have remediation lanes or escalate to admin/executive override.

---

### NextAction & Success Signal

**NextAction:** Type `next` to receive **SEG-05 TASK_GRAPH v0.1** with meta-prompting, explicit convergence nodes, anti-collision pathways, agentic hand-offs, and prioritized, SOT-linked paths—annotation for critical compliance, productivity, and automation leverage.  
**Success Signal:** Delivery of a working, actionable task graph ready for agent instantiation and multi-lane BMAD execution with collision handling and convergence hooks.

Type next.
```


## @Bunshin-v2

next (instantiate and incorporate actual business logic for AEC firm and identify exact name and component of new and improved and adjudicated upon and agreed: 

List of Sequential Workflows, Intake Data Entry Points, Direction and Pathing to Dashboards / Data sets, Tables, Charts and the resulting list of deliverables for completion oriented meta articulation and optimized business canvas derived logical components and seal output resulting actions and populated data sets and queries and output schema with instantiated real AEC business rhetoric 

## Copilot

### SegmentHeader
- SegmentID: SEG-05
- Status: Draft v0.1 (AEC Business Logic Instantiation)
- Objective: Instantiate real AEC business logic; enumerate sequential workflows; define intake data entry points; map direction/pathing to dashboards, datasets, tables, charts; list deliverables; seal resulting actions, populated datasets, queries, and output schema with AEC-specific terminology.
- InputsUsed: MASTER_SPEC_v1.0; Unified Domain Model v0.1; FEATURES v0.1; Workflows v0.2; Real Projects + Manpower sheets; Decisions (clients, chairman+vice, tenders expanded, 4-tier perms, AED).
- OutputBudget: ≤250 lines
- RetryCap: 3

Checklist (Plan)
1. Name and order the AEC-critical sequential workflows (bid→design→build→closeout→DLP).
2. For each workflow: define intake points, actors, tables, dashboards/charts, deliverables.
3. Declare canonical data sources (SOT) and collision/ambiguity handling.
4. Provide query/view outputs and dataset pathing to UI components.
5. Seal with actions to populate datasets, schedule jobs, and validate.

---

Sequential AEC Workflows (WF order and business rhetoric)
1) WF-BID-001 Tender Intake → Requirements → Submission
- Intake Points: RFQ/Tender Pack upload; New Tender form (client, deadline, AED value).
- Actors: Bid Manager, Dept Head, Executive oversight.
- Tables (SOT): tenders, tender_checklist_templates/items, tender_requirements, tender_required_documents, tender_comms_events, documents.
- Dashboards/Charts: Tender Pipeline (status columns), Countdown ladder (14/7/3/1 days), Requirements Coverage %, Win Rate bar chart.
- Deliverables: Requirements TOC, Document checklist coverage, Submission package, Comms log, Follow-up cadence.
- Validation change: Coverage% >= threshold; deadline registered; follow-up set. If missing → meta-alert + escalation.

2) WF-DES-002 Design Phase Management → Submittals/RFIs/VOs
- Intake Points: Design Submittal form; RFI creation; Variation Order (VO) initiation.
- Actors: Design Lead, Discipline Engineers, Document Controller.
- Tables: submittals, rfis, variations (vo), documents, tasks, audit_log.
- Dashboards/Charts: Submittal Turnaround KPI, RFI Aging ladder, VO cost impact bar chart.
- Deliverables: Stamped submittals, RFI responses, VO approval records, linked drawings/specs.
- Validation change: Turnaround SLA met; RFIs resolved pace; VO approvals documented.

3) WF-SUP-003 Site Supervision → Inspections → NCRs (Quality)
- Intake Points: Inspection Request; NCR issuance; Corrective action task.
- Actors: Resident Engineer, QA/QC Engineer, Contractor reps.
- Tables: inspections, ncrs, tasks, notifications, audit_log, documents.
- Dashboards/Charts: NCR Aging (open/resolved), Inspection pass rate, Hotspot map.
- Deliverables: Inspection reports, NCR close-out packs, Corrective actions with evidence.
- Validation change: NCR closure within SLA; re-inspection logged; evidence linked.

4) WF-PROG-004 Progress → Milestones → Payment Certificates
- Intake Points: Milestone baseline/update; Progress %; Payment Certificate request.
- Actors: PM, QS/Commercial, Finance observer.
- Tables: project_milestones, tasks, documents, payment_certificates (placeholder), audit_log.
- Dashboards/Charts: S-curve Progress, Milestone Due matrix, Certificate pipeline.
- Deliverables: Updated milestone status, progress narrative, certificate package.
- Validation change: Progress data integrity (sources logged); due window alerts firing.

5) WF-COMP-005 Compliance/NOCs/Permits → Renewals (UAE)
- Intake Points: New Permit/NOC record; Renewal scheduling.
- Actors: Compliance Manager, PRO/Legal, Project team liaison.
- Tables: permits (authority, number, expiry), tasks, followups, notifications, audit_log, documents.
- Dashboards/Charts: Compliance Register, Renewal Countdown, Authority-by-emirate heatmap.
- Deliverables: Renewal submissions, approvals, audit trail; escalation when overdue.
- Validation change: Renewal SLA met; missing evidence flagged with severity ladder.

6) WF-RES-006 Resource & Staffing → Mobilization → Allocation
- Intake Points: Manpower plan import; Staff assignment to project.
- Actors: Dept Head, PM, HR.
- Tables: project_staffing_assignments, project_members, tasks.
- Dashboards/Charts: Resource Utilization heatmap; Vacancies tracker; Mobilization schedule.
- Deliverables: Assignment confirmations, mobilization tasks, role coverage proof.
- Validation change: Vacancies closed or flagged; mobilization dates respected.

7) WF-DOC-007 Document Control → Transmittals → Filing
- Intake Points: Transmittal creation; Doc upload with sensitivity.
- Actors: Document Controller, QA, PM.
- Tables: documents, document_tags, audit_log, (optional transmittals).
- Dashboards/Charts: Filing completeness %, Transmittal SLA, Sensitive docs access matrix.
- Deliverables: Transmittal register, filing map, access governance.
- Validation change: All critical docs present; sensitivity enforced via RLS.

8) WF-CLOSE-008 Closeout → Handover → DLP Start
- Intake Points: Handover checklist; As-built packages; DLP initiation.
- Actors: PM, QA/QC, Client rep.
- Tables: handover_checklists (optional), documents, project_milestones (handover), retentions, bonds (release criteria).
- Dashboards/Charts: Handover readiness; Retention release timeline; Bonds nearing expiry.
- Deliverables: Handover dossier, DLP commencement, retention/bond release workflow.
- Validation change: Handover evidence complete; release triggers meet contract clauses.

9) WF-DLP-009 DLP Defects → Corrective Actions → Closure
- Intake Points: Defect logging; Corrective action; Re-inspection.
- Actors: QA/QC, Resident Engineer, Contractor.
- Tables: dlp_defects, tasks, inspections, documents.
- Dashboards/Charts: Defect burn-down; Resolution rate; DLP end-date countdown.
- Deliverables: Defect resolution packs; DLP closure certificate.
- Validation change: Defects resolved within SLA; DLP closure state set.

---

Intake Data Entry Points (forms/API)
- /tenders/new (RFQ Intake): client_id, tender_no, deadline_at, value_amount(AED).
- /tenders/[id]/intake (Checklist/TOC builder).
- /design/submittals/new; /design/rfis/new; /design/vo/new.
- /supervision/inspections/new; /supervision/ncr/new.
- /projects/new; /projects/[id]/milestones/new|update; /projects/[id]/progress.
- /compliance/permits/new; /compliance/permits/[id]/renewal.
- /resources/import-manpower; /projects/[id]/assign-staff.
- /docs/upload (sensitivity, owner entity).
- /closeout/handover/new; /dlp/defects/new.

Direction & Pathing (user journeys → datasets → dashboards)
- Bid Manager: Tender Intake → Requirements Coverage → Pipeline → Submission → Win/Loss → Executive Dashboard KPI cards (Tender Due Soon, Coverage%).
- PM: Project Portfolio → Milestones Due → Tasks → Progress S-curve → Payment Certificate pipeline.
- QA/QC: Inspection calendar → NCR Aging → Corrective actions → Closeout readiness.
- Compliance: Register → Upcoming Renewals → Evidence packs → Escalations/ack.
- HR/Dept Head: Manpower → Mobilization → Vacancies → Resource Utilization heatmap.
- Doc Control: Transmittal → Filing completeness → Sensitive doc access.

Tables (Output Schema; canonical SOT)
- CRM: clients(id,name), contacts(id,client_id,...).
- Tendering: tenders(...), tender_checklist_templates/items(...), tender_requirements(...), tender_required_documents(...), tender_comms_events(...).
- Design: submittals(...), rfis(...), variations(...).
- Supervision/QA: inspections(...), ncrs(...).
- Projects: projects(...), project_milestones(...), project_members(...), project_staffing_assignments(...).
- Progress/Finance-lite: payment_certificates(...).
- Compliance: permits(...).
- Closeout/DLP: handover_checklists(...), dlp_defects(...).
- Core: documents(...), document_tags(...), tasks(...), followups(...), notifications(...), audit_log(...).

Views & Queries (dataset outputs powering charts/cards)
- v_tender_requirements_coverage: SELECT tender_id, count_linked_docs / count_required_docs AS coverage_pct.
- v_tenders_with_countdown: SELECT tender_id, deadline_at, days_remaining, severity.
- v_rfi_aging: SELECT rfi_id, date_diff(now, created_at) AS days_open, severity.
- v_ncr_aging: SELECT ncr_id, days_open, status_bucket(open/overdue/resolved).
- v_milestones_due: SELECT project_id, milestone_id, due_in_days, severity.
- v_resource_utilization: SELECT project_id, role_title, assigned_count / planned_count AS utilization.
- v_compliance_due: SELECT permit_id, due_in_days, authority, severity.
- v_dlp_burndown: SELECT project_id, open_defects, resolved_defects, rate_per_week.
- S-curves: SELECT project_id, date_bucket, planned_progress, actual_progress.

Dashboards → Component mappings
- Executive: KPI tiles (Active Projects, Tenders Due, Overdue Tasks, Compliance Due), ladders (Milestones, Permits), charts (Win Rate, S-curve).
- Tender: Pipeline board, Coverage%, Countdown ladder; Comms log table.
- Project: Portfolio grid, Milestone matrix, S-curve, Certificate pipeline.
- QA/QC: NCR Aging ladder, Inspection pass rate, Defect burndown.
- Compliance: Register table, Renewal countdown chart, Authority heatmap.
- Resources: Utilization heatmap, Vacancies table, Mobilization timeline.
- Documents: Filing completeness %, Sensitive access matrix.

Deliverables (completion-oriented)
- Per Tender: Requirements TOC + Checklist coverage report; Submission package; Follow-up plan.
- Per Project: Baseline milestones; Progress reports; Certificate request artifacts.
- Per QA/QC: NCR closeout packs; Inspection dossiers.
- Per Compliance: Renewal submission packs; Approval records.
- Per Resources: Assignment confirmations; Mobilization tasks.
- Per Docs: Transmittal register; Filing/Access governance report.

Business Logic Guardrails & SOT Adjudication
- SOT declaration per entity (e.g., tender_requirements coverage is authoritative for “coverage%” KPIs).
- Collision handling: duplicate tender_no/project_code→merge path; ambiguous permit→admin review with SOT override.
- RLS enforced at read/write; sensitive docs require role L2+ or explicit membership.

Seal Output: Actions to populate and operationalize
- Migrations: create missing tables (submittals, rfis, variations, inspections, ncrs, payment_certificates, permits, dlp_defects, handover_checklists).
- Seeds: import real Projects/Clients; stage permits from compliance register; manpower assignments from plan.
- Jobs: schedule followup sweep (cron); milestone/permit countdown sweeps; dedupe notification window set (12h).
- Views: implement v_* views listed above; index columns used in countdown/aging/severity calculations.
- UI: wire dashboards/components to views; add filters (client, project, authority, severity).
- QA: run scenario tests per workflow; validate coverage, countdowns, RLS blocks, evidence citations.
- Observability: log audit entries for all state changes; dashboard heartbeats for sweep jobs.

Validation (self-check per step)
- After WF-BID-001: Coverage% computed; missing docs flagged; follow-ups scheduled. Deviations? escalate.
- After WF-DES-002: Submittal/RFI SLAs tracked; open aging visible. If not, index and view corrections.
- After WF-SUP-003: NCR ladder matches statuses; corrective tasks traced. If gaps, fix linkage.
- After WF-PROG-004: S-curve draws from planned vs actual reliably. If drift, reconcile source metrics.
- After WF-COMP-005: Renewal countdown aligns with permit expiries; evidence logs present.
- After WF-RES-006: Heatmap reflects planned vs assigned; vacancies highlighted.
- After WF-DOC-007: Filing completeness% correct; sensitivity enforced via RLS.
- After WF-CLOSE-008 / WF-DLP-009: Handover/DLP artifacts complete; retention/bond release logic mapped.

NextAction + Success Signal
- NextAction: Type “next” to receive SEG-06 Security/Compliance Gates + ADR set, mapping OWASP Top 10:2025 to these workflows (auth, RLS, sensitivity, audit) and producing gate criteria, rollback strategies, and enforcement checks.
- Success Signal: You receive a gates document with enforceable policies, ADRs per major component, and testable acceptance aligned to the AEC workflows above.

## @Bunshin-v2

next 

## Copilot

### SegmentHeader
- SegmentID: SEG-06
- Status: Draft v0.1 (Security/Compliance Gates + ADR Set)
- Objective: Define enforceable security/compliance gates mapped to OWASP Top 10:2025 and ASVS; produce ADRs for core architecture decisions; include rollback strategies and acceptance tests aligned to AEC workflows.
- InputsUsed: MASTER_SPEC_v1.0; Domain Model; Workflows; FEATURES; Decisions (Supabase, Clerk, 4-tier perms, Hybrid RAG, AED).
- OutputBudget: ≤250 lines
- RetryCap: 3

Checklist
1. Map OWASP Top 10:2025 to concrete gates and controls.
2. Define ASVS target level and evidence requirements.
3. Write ADRs with context, options, consequences.
4. Include rollback strategies and gate acceptance tests.
5. Seal with next action.

````markdown name=docs/security/SECURITY_GATES.md
# Security & Compliance Gates (SEG-06)

## Standards
- OWASP Top 10:2025
- OWASP ASVS Level 2 (target)
- NIST SSDF (SP 800-218) — Prepare/Protect/Produce/Respond (evidence only)
- SLSA v1.2 provenance for CI

## Gate Registry (enforceable)
- G-SEC-BASELINE (Top 10 coverage)
- G-AUTHN-AUTHZ (Clerk + RLS)
- G-DATA-SAFETY (migrations/backup/rollback)
- G-LOG-ALERT (security logging + alerting)
- G-SUPPLY-CHAIN (dependency health + CI provenance)
- G-CSP/HSTS (headers and browser controls)
- G-EXCEPTIONS (error handling, fail-closed)
- G-RELEASE-READY (QA + runbook + rollback)

---

## OWASP Top 10:2025 Mapping → Controls

A01 Broken Access Control → Enforce RLS + membership checks
- Evidence: RLS policy files; tests for cross-entity access denial.
- Check: L4 cannot read unrelated tender/project; L2 exec can read dashboards only.
- Rollback: Disable affected routes; hotfix RLS; re-run deny tests.

A02 Security Misconfiguration → Secure defaults (private buckets, least-priv env)
- Evidence: Supabase storage policies; `.env.example` without secrets.
- Check: Private bucket for documents; signed URL issuance server-side.
- Rollback: Flip bucket to private; revoke public keys.

A03 Supply Chain Failures → Pin deps; CI SBOM + SLSA provenance
- Evidence: lockfiles; SBOM; SLSA attestations in CI artifacts.
- Check: High vuln = block; provenance attached on release.
- Rollback: Revert dependency; apply patched version.

A04 Cryptographic Failures → TLS at edges; signed URLs; secret rotation
- Evidence: Rotation policy; KMS-integration notes; HTTPS-only config.
- Check: No HTTP; signed URL expiration ≤10min; refresh tokens ≤7 days.
- Rollback: Force rotate keys; shorten token TTLs.

A05 Injection → Parameterized queries; input validation (Zod)
- Evidence: Validators per endpoint; no string-concat SQL.
- Check: Fuzz tests for SQL/XSS; reject on invalid schema.
- Rollback: Patch validators; add escaping; block offending path.

A06 Insecure Design → Workflow guards; authZ at service layer
- Evidence: Guard functions; state machine validation.
- Check: Illegal transitions rejected; audit logged.
- Rollback: Disable transition; add guard; revalidate scenarios.

A07 Authentication Failures → Clerk config; JWT verification
- Evidence: JWT middleware; sub→profiles mapping docs.
- Check: Expired tokens denied; signature verified server-side.
- Rollback: Invalidate sessions; adjust JWT lifetimes.

A08 Integrity Failures → Hashes on uploads; immutable audit logs
- Evidence: Audit append-only; checksum optional on docs.
- Check: No DELETE/UPDATE in audit; tamper detection logs.
- Rollback: Restore from backup; mark corruption; reindex.

A09 Security Logging & Alerting → Structured logs; alert thresholds
- Evidence: Correlation IDs; alert rules; runbooks.
- Check: 4xx/5xx spikes page on-call; sweep heartbeat alerts.
- Rollback: Increase sensitivity; disable noisy alerts with whitelist.

A10 Mishandling of Exceptional Conditions → Fail-closed patterns
- Evidence: Error handlers; refusal policies in RAG.
- Check: On exception → no partial writes; RAG refuses w/o evidence.
- Rollback: Add circuit breaker; sandbox failing features.

---

## ASVS Level 2 — Evidence Requirements
- AuthN/AuthZ: Multi-layer checks (JWT, RLS, membership)
- Input Validation: Zod schemas, server-side verification
- Session Management: TTLs, rotation policies documented
- Error Handling: No sensitive info in responses/logs
- Data Protection: Sensitivity levels enforced; least privilege
- Logging & Monitoring: Security events + alerts

---

## Headers & Browser Controls
- CSP: default-src 'self'; img-src 'self' data:; connect-src 'self' api; object-src 'none'; frame-ancestors 'none'
- HSTS: max-age=31536000; includeSubDomains; preload
- Referrer-Policy: no-referrer
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY

---

## Gate Acceptance Tests (critical)
- RLS Matrix: L2 vs L4 across endpoints (403 expected for L4 on unrelated entities)
- Storage: Private bucket read denied client-side; signed URLs only via server
- Injection: Negative tests (SQL/XSS payloads) blocked
- Logging: Sweep heartbeat alert fires if missed 30m
- RAG: Answers contain citations OR refusal

---

## Rollback Patterns
- Auth: Force logout; reduce TTL; rotate secrets
- DB: Snapshot restore; forward-fix migration (no enum deletions)
- Storage: Revoke public; rotate bucket keys; audit access
- CI: Freeze releases; revert dependency bump; re-run SBOM

---
````

````markdown name=docs/adr/ADR-001-authn-authz.md
# ADR-001: Authentication & Authorization Stack

## Decision
Use Clerk for AuthN (JWT) + Supabase RLS + table-driven permissions (4-tier, department-scoped).

## Context
- Need fast, secure AuthN with minimal bespoke code.
- Must enforce per-entity access and sensitive-doc visibility.

## Options
1) Clerk + RLS (chosen)
2) Auth.js + RLS
3) Custom JWT service + RLS

## Pros/Cons
+ Rapid integration; production-grade; SDK support
+ RLS enforces server-side data boundaries
- Vendor dependency; correct JWT→profile mapping required

## Consequences
- JWT must map `sub` to `profiles.clerk_user_id`.
- All reads/writes pass through RLS-aware services.

## Rollback
- Switch to Auth.js while keeping RLS; provide migration mapping for identifiers.
````

````markdown name=docs/adr/ADR-002-permission-model.md
# ADR-002: Permission Model

## Decision
Table-driven 4-tier permission levels + department assignments; entity membership overrides.

## Context
AEC roles differ by department; need configurable scopes without schema churn.

## Options
1) Enum roles only
2) Table-driven tiers (chosen)
3) Policy-as-code engine (Phase 2)

## Pros/Cons
+ Reconfigurable without migrations
+ Clear auditability of changes
- Slightly more joins; requires governance UI

## Consequences
- `permission_levels`, `profile_department_permissions`, `entity_memberships` are canonical.
- UI must resolve effective permissions per view/action.

## Rollback
- Temporary hard-coded checks for critical paths; sync back to tables ASAP.
````

````markdown name=docs/adr/ADR-003-rag-retrieval.md
# ADR-003: RAG Retrieval Strategy

## Decision
Hybrid retrieval: Postgres FTS (BM25-like) + pgvector embeddings; rank fusion + strict cite-or-refuse policy.

## Context
Contracts and technical docs require exact citations and compliance posture.

## Options
1) Vector-only
2) FTS-only
3) Hybrid fusion (chosen)

## Pros/Cons
+ Better precision/recall; deterministic filters (entity/sensitivity)
- More infra/config; evaluation harness needed

## Consequences
- Ingestion → chunks + embeddings; filters by entity/sensitivity
- Answers must include citations; refusal allowed on low evidence

## Rollback
- Disable generation; retrieval-only responses; manual curation.
````

````markdown name=docs/adr/ADR-004-notification-engine.md
# ADR-004: Notification/Alarm Engine

## Decision
DB-side sweep via pg_cron + RPC function; dedupe window 12h; escalation matrix per severity.

## Context
Tender deadlines, compliance renewals, NCR aging need reliable reminders.

## Options
1) App-side schedulers
2) DB cron + RPC (chosen)
3) External queue/service (Phase 2)

## Pros/Cons
+ Close to data; simpler ops in MVP
- Cron visibility; need heartbeat alerts

## Consequences
- Heartbeat dashboard; alerts on missed runs
- Acknowledgement stops escalation

## Rollback
- Move critical sweeps to Edge Functions; keep cron as safety net.
````

````markdown name=docs/adr/ADR-005-compliance-logging.md
# ADR-005: Compliance Logging & Evidence

## Decision
Structured security logs with correlation IDs; append-only audit; evidence packs for renewals/submissions.

## Context
UAE compliance (permits/NOCs), tender submissions, QA/QC actions require traceable evidence.

## Options
1) Ad-hoc logs
2) Structured audit + evidence mapping (chosen)
3) External SIEM integration (Phase 2)

## Pros/Cons
+ Forensic trail; gate-ready
- Storage growth; need rotation policy

## Consequences
- No DELETE/UPDATE in audit; evidence packs linked to entities
- Alerts on anomalies (surges, missing acks)

## Rollback
- Archive to cold storage; compress older logs; increase retention granularity.
````

Example controls (implementation hints)
- RLS policy (deny-by-default; allow membership):
```sql
create policy p_read_project_membership
on projects for select
using (
  exists (
    select 1 from project_members pm
    where pm.project_id = projects.id
      and pm.profile_id = auth.uid()
  )
  or exists (
    select 1 from profile_department_permissions pdp
    where pdp.profile_id = auth.uid()
      and pdp.permission_level_id in (select id from permission_levels where rank <= 2) -- L1/L2
  )
);
```
- CSP headers (Next.js middleware):
```ts
export function middleware(req: Request) {
  const res = NextResponse.next();
  res.headers.set("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'");
  res.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
  res.headers.set("Referrer-Policy", "no-referrer");
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("X-Frame-Options", "DENY");
  return res;
}
```
- CI supply chain (GitHub Actions fragment):
```yaml
jobs:
  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: anchore/sbom-action@v0
        with: { path: ., output: sbom.spdx.json }
      - uses: snyk/actions/node@v0.4.0
        with: { args: "--severity-threshold=high" }
      - name: Attest build provenance (SLSA)
        uses: slsa-framework/slsa-github-generator@v2
```

Validation (gate acceptance)
- RLS deny/allow matrix passes automated tests.
- Storage private-read denied client-side; signed URL only server.
- Injection/XSS fuzz blocked by validators.
- Sweep heartbeat visible; missed-run alerts page on-call.
- RAG returns citations or refuses; no uncited answers.

NextAction + Success Signal
- NextAction: Type “next” to generate SEG-07 Tooling/Agent Adapters (Claude Code, Auto-Claude, IDE) with runbooks, prompts, and adapter stubs wired to these gates.
- Success Signal: You receive adapters and execution scaffolds that honor gates, enforce evidence, and prevent drift across agent runs.

Type next.

## @Bunshin-v2

next

## Copilot

````markdown name=docs/tooling/SEG-07_OVERVIEW.md
# SEG-07 Tooling & Agent Adapters (Claude Code, Auto-Claude, IDE)

Purpose
- Provide adapters, runbooks, prompts, and execution scaffolds for agent-driven development that enforce SEG-06 security/compliance gates, evidence-first policies, and AEC business logic.
- Prevent drift and collisions by integrating gate checks, source-of-truth (SOT) adjudication, and meta-synthesis prompts across all tooling surfaces.

Scope
- Claude Code Adapter (slash commands, prompts, gate-aware workflows)
- Auto-Claude Adapter (batch orchestration, policies, provenance)
- IDE Adapter (VS Code/Cursor tasks, rehydration protocol, copy-paste ready steps)
- Runbooks (rehydration, incident handling, gate failures, missed sweeps)

Key Principles (enforced)
- Evidence-first (RAG cite-or-refuse)
- RLS/permission checks at every data touch
- SOT adjudication for dashboards/metrics/views
- Fail-closed error handling (no partial writes)
- Gate acceptance tests before “final outputs”
- Convergence ledger entries for collisions/ambiguities

References
- SEG-02 Domain Model, SEG-03 Features, SEG-04 Workflows v0.2
- SEG-06 Security Gates + ADR set
````

````markdown name=docs/tooling/claude-code/CLAUDE_CODE_ADAPTER.md
# Claude Code Adapter (Gate-Aware)

Purpose
- Drive conversational, task-based execution in Claude Code with gate-aware prompts, minimal context rot, and AEC business logic alignment.

Adapter Mode
- Workflow-first: Execute WF-IDs via subagents (planning → execution → verify)
- Gate-aware: Check SEG-06 gates before destructive operations
- Evidence-first: RAG requires citations; refusal allowed; no “fabricated correctness”

Slash Commands (recommended)
- `/mce:gate-check` → Run SEG-06 acceptance tests
- `/mce:execute-wf <WF-ID>` → Execute workflow with gate checks and audit logs
- `/mce:rehydrate` → Perform resume protocol (SEG-14)
- `/mce:rag-query <scope>` → Answer with citations or refuse; log eval metrics
- `/mce:import <source>` → Streamed Excel/CSV to staging; pseudo registry logging

Command Template (gate-aware orchestrator)
```
<objective>
Execute workflow {WF-ID} with SEG-06 gate checks and AEC business rules.
</objective>

<context>
@docs/security/SECURITY_GATES.md
@docs/workflows/WF-REGISTRY.md
@docs/domain/MODEL.md
Gate targets: RLS, storage privacy, injection/XSS, logging heartbeat, RAG citations
</context>

<guardrails>
- Evidence-first: cite or refuse
- Deny-by-default: RLS enforced
- SOT adjudication for all metrics/views
- Fail-closed on errors (no partial writes)
</guardrails>

<process>
1) Load WF-ID; list required tables/views/services
2) Run `/mce:gate-check` (subset relevant to WF)
3) Execute steps atomically; write audit logs
4) Verify acceptance criteria; produce artifacts
5) If any gate fails → stop + remediation plan
</process>

<outputs>
- Artifacts (reports, views, logs, UI bindings)
- Gate pass/fail with evidence
- Audit entries + convergence ledger notes (collisions/ambiguities)
</outputs>
```

Agentic Prompts (examples)
- “List the obligations due in ≤14 days for tenders; grade severity and cite document IDs” (WF-TND-002)
- “Compute Requirements Coverage% for Tender #X; show missing required docs with links” (WF-TND-001)
- “Render NCR Aging ladder; verify RLS blocks for non-members” (WF-SUP-003)
- “Produce S-curve from planned vs actual progress; list data sources and SOT” (WF-PROG-004)

Interaction Policy
- Never bypass SEG-06 gates
- Require explicit SOT declaration for every computed metric
- Log meta-alerts for any collisions/ambiguities detected

Acceptance (adapter health)
- Commands return ONLY gate-aware outputs
- Audit completeness: 100% state-changing actions logged
- Drift detectors: zero silent collisions (all flagged in convergence ledger)
````

````markdown name=docs/tooling/auto-claude/AUTO_CLAUDE_ADAPTER.md
# Auto-Claude Adapter (Batch Orchestration & Provenance)

Purpose
- Run multi-lane agent batches (plan → execute → verify) with strict gate enforcement, provenance capture (SLSA), and auditable outputs.

Execution Policy (YAML)
```yaml
auto_claude:
  lanes: 5
  max_iterations_per_lane: 3
  stop_on_gate_failure: true
  gates:
    - RLS_matrix
    - storage_privacy_signed_url_only
    - injection_xss_fuzz_blocked
    - sweep_heartbeat_alerts
    - rag_cite_or_refuse
  provenance:
    sbom: true
    slsa_attestation: true
  outputs:
    - convergence_ledger
    - audit_log
    - acceptance_reports
```

Batch Templates
- “WF-BID-001 Tender Intake” → plan tasks, execute checklist/TOC, verify coverage% → acceptance report
- “WF-COMP-005 Compliance Renewals” → refresh register, schedule followups, verify expiries → acceptance report
- “WF-SUP-003 NCR Closeout” → ingest NCRs, assign corrective tasks, verify closure → acceptance report

Gate Hooks (per batch)
- Before lane start → run `/mce:gate-check`
- After lane finish → attach acceptance evidence + logs
- On failure → stop all lanes; produce remediation batch plan

Provenance Capture
- SBOM generated per batch
- SLSA attestation attached to artifacts (CI pipeline integration)
- Hashes for outputs (docs, CSVs, views) stored for integrity

Acceptance (adapter health)
- Zero gate bypasses
- All artifacts carry provenance
- Convergence ledger populated for collisions (duplicates, ambiguous permits, inconsistent statuses)
````

````markdown name=docs/tooling/ide/IDE_ADAPTER.md
# IDE Adapter (VS Code/Cursor/Copilot)

Purpose
- Provide deterministic, copy-pasteable tasks and rehydration steps that respect gates and AEC workflows.

Tasks (examples)
- “Run Gate Suite”:
  - Open `docs/security/SECURITY_GATES.md`
  - Execute `pnpm test:security && pnpm test:rls && pnpm test:rag`
- “Provision Views”:
  - Apply SQL in `supabase/migrations/00x_views.sql`
  - Verify `v_*` views return rows; index check
- “Schedule Sweeps”:
  - Enable pg_cron; deploy `run_followup_sweep()` RPC
  - Verify heartbeat dashboard shows green

Copy-Paste Command Pack
```bash
# Gate checks
pnpm test:rls && pnpm test:security && pnpm test:rag

# Run followup sweep manually (debug)
psql -c "select * from run_followup_sweep();"

# Validate views compile
psql -c "select * from v_tenders_with_countdown limit 5;"
psql -c "select * from v_milestones_due limit 5;"
```

Rehydration Protocol (SEG-14)
- Paste:
```
<rehydrate>
SegmentID: SEG-07
State: Tooling adapters deployed (Claude/Auto-Claude/IDE)
Artifacts: security gates, ADRs, WF registry, views, RPCs
Open patches: None; pending: batch acceptance reports
NextAction: Run Gate Suite → execute WF-BID-001 on a sample tender
</rehydrate>
```

Acceptance (adapter health)
- Tasks produce verifiable outputs
- Rehydration reproduces state and next steps without ambiguity
````

````markdown name=docs/tooling/RUNBOOK_AGENT_EXECUTION.md
# Agent Execution Runbook (Gate-Aware)

Use-Cases
- Gate failures, missed sweep heartbeats, provenance gaps, collision incidents

1) Gate Failure (e.g., RLS deny/allow mismatch)
- Action: Stop batch; run `/mce:gate-check` focused on RLS
- Remediation: Fix policy; add tests; re-run acceptance
- Evidence: Attach failing queries + passing after fix

2) Missed Sweep Heartbeat (Notifications)
- Action: Inspect cron status; run manual RPC; check logs
- Remediation: Re-enable cron; add alerts; backfill notifications
- Evidence: Heartbeat timeline + successful backfill

3) Provenance Gap (missing SBOM/SLSA)
- Action: Re-run CI with provenance steps enabled
- Remediation: Patch pipeline; enforce “block on missing attestation”
- Evidence: SBOM + SLSA artifacts linked to outputs

4) Collision Incident (duplicate tender_no/project_code)
- Action: Open convergence ledger entry; propose merge; SOT override
- Remediation: Admin adjudication; update SOT pointers; reindex
- Evidence: Before/after entity linkage map

5) RAG Wrong Answer (uncited)
- Action: Switch to retrieval-only; analyze query; check chunk coverage
- Remediation: Re-chunk docs; verify sensitivity filters; re-run eval
- Evidence: Golden-set pass report with citations

Operational Checklist
- Gates green → proceed
- Audit entries present → OK
- Convergence ledger updated → OK
- Provenance attached → OK

Stop Conditions
- Any gate red → STOP
- Uncited RAG answer → STOP (fail-closed)
- Storage privacy violation → STOP

Next Steps
- Use Claude Code Adapter `/mce:execute-wf WF-BID-001` on sample tender with Gate Suite pre-check.
````

````markdown name=docs/tooling/prompts/MCE_META_PROMPTS.md
# Meta Prompts (Gate-Aware & AEC-Ready)

1) Obligations Radar (Compliance/Contracts)
“List obligations and renewals due in ≤30/≤14/≤7 days. Group by authority/emirate/client. Cite documents and SOT tables. If ambiguous, refuse and request clarification.”

2) Requirements Coverage (Tender Intake)
“Compute Coverage% for Tender #X. Show missing required documents with links and owners. Log meta-alert for any unmapped requirement.”

3) Progress Integrity (S-Curve)
“Render S-curve for Project #Y. Declare SOT and data derivation. Flag drift between planned vs actual beyond threshold; create remediation tasks.”

4) NCR Burn-down (QA/QC)
“Show NCR burn-down and resolution rate. Verify RLS blocks non-members. Cite NCR IDs and inspection reports; flag overdue escalations.”

5) Resource Utilization
“Compute utilization by role/project. Identify vacancies and upcoming mobilizations. Enforce sensitivity and RLS; propose staffing actions.”

Rule
- Always cite; refuse if insufficient evidence
- Declare SOT per metric/view
- Log collisions to convergence ledger
````

````markdown name=docs/tooling/adapters/ADAPTER_ACCEPTANCE.md
# Adapter Acceptance Criteria

Claude Code
- Executes WF-IDs with gate checks; returns artifacts + audit logs
- Never bypasses SEG-06 gates
- Produces convergence ledger entries for collisions

Auto-Claude
- Batch lanes stop on gate failures
- Attaches SBOM + SLSA to outputs
- Yields acceptance reports per WF

IDE
- Tasks reproducible and deterministic
- Rehydration restores next actions and state
- Copy-paste commands operate without hidden assumptions

Global
- Evidence-first; cite-or-refuse enforced
- SOT declared for every computed metric
- Fail-closed on errors; rollback strategies present

NextAction
- Run Gate Suite, then execute WF-BID-001 (sample tender) through Claude Code Adapter; produce acceptance report and convergence ledger entries.

Success Signal
- Gate Suite green; artifacts with provenance; acceptance report attached; convergence ledger populated where applicable.
````

## @Bunshin-v2


Ship an MVP “MCE Command Center” web app on Next.js + Supabase (Postgres/RLS) + Clerk (auth) + Vercel (deploy), starting with a working auth → RLS-secured data CRUD → production deploy baseline that has a clean upgrade path (agentic workflows, RAG, evaluators, audit logs).

Success metrics (measurable)

Prod deploy live on Vercel with HTTPS and working auth flows (sign in/up/out).

RLS enforced: a signed-in user can only read/write their own rows (prove via UI + direct API calls).

Smoke gates pass: lint, typecheck, test, next build succeed in CI.

Observability baseline: request/run IDs in logs for server actions + API routes.

Constraints (time, stack, environment, risk tolerance)

Stack is fixed: Next.js + Supabase + Clerk + Vercel (free tiers where possible).

Security-first MVP: least privilege, no service-role keys in client, RLS on core tables.

Fast path: deliver a “proof-of-RLS” feature (Tasks/Notes) before modeling full ERP entities.

No destructive ops without rollback: any SQL changes include rollback SQL.

Assumptions & Uncertainty Log
Assumption	Why it matters	Risk	How to verify	Default choice
You will use Next.js App Router	Clerk middleware + server components patterns differ	Medium	Check your Next.js version + app/ exists	Use App Router
You can use Clerk session tokens directly with Supabase via Third-Party Auth	Avoid custom JWT minting	Low	Confirm Supabase “Clerk provider” is configured	Use official integration
MVP is single-tenant per user (not org-based)	Simplifies RLS and schema	Medium	Decide later if Clerk Organizations needed	Start user-scoped; add org later
Package manager is pnpm	Commands differ	Low	pnpm -v	Use pnpm
Checklist

 Create Supabase + Clerk + Vercel projects and connect Clerk↔Supabase third-party auth

 Bootstrap Next.js repo (TS, lint) and add Clerk auth + protected routes

 Add Supabase client configured to send Clerk session token (RLS-enabled)

 Create first RLS table + policies (Tasks) and wire UI + server action

 Add smoke tests + CI

 Deploy to Vercel with env vars and verify end-to-end

Step 1 — Create accounts + connect Clerk ↔ Supabase (UI)
1A) Supabase

Go to Supabase Dashboard → New project

Save:

Project URL

anon public API key (client-safe)

1B) Clerk

Clerk Dashboard → create a Next.js app

Enable sign-in methods (email/password is fine for MVP)

1C) Enable Supabase “Third-Party Auth” with Clerk (critical)

Do this exactly (official flow):

In Clerk Dashboard, go to Supabase integration setup and Activate Supabase integration, then copy your Clerk domain.

In Supabase Dashboard → Authentication → Sign In / Up → Add provider → Clerk and paste the Clerk domain.
This makes Supabase trust Clerk-issued JWTs (same idea as Supabase Auth tokens).

Step 2 — Bootstrap the Next.js repo (commands)
# pick a workspace location
mkdir -p ~/dev && cd ~/dev

# create app (App Router + TS)
pnpm create next-app@latest mce-command-center --ts --eslint --app --src-dir --tailwind

cd mce-command-center

# deps
pnpm add @clerk/nextjs @supabase/supabase-js zod
pnpm add -D vitest @types/node


Create .env.example:

cat > .env.example <<'EOF'
# Clerk
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=
CLERK_SECRET_KEY=

# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
EOF


Copy to local env:

cp .env.example .env.local

Step 3 — Wire Clerk (protected routes) + minimal pages
3A) src/middleware.ts
import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server'

const isProtectedRoute = createRouteMatcher(['/dashboard(.*)', '/tasks(.*)'])

export default clerkMiddleware((auth, req) => {
  if (isProtectedRoute(req)) auth().protect()
})

export const config = {
  matcher: [
    // Skip Next.js internals and static files
    '/((?!_next|.*\\..*).*)',
    '/',
    '/(api|trpc)(.*)',
  ],
}


This follows Clerk’s recommended middleware pattern for protecting route groups.

3B) src/app/layout.tsx
import { ClerkProvider } from '@clerk/nextjs'
import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'MCE Command Center',
  description: 'MVP baseline: Clerk + Supabase (RLS) + Vercel',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body>{children}</body>
      </html>
    </ClerkProvider>
  )
}

3C) src/app/page.tsx
import { SignedIn, SignedOut, SignInButton, UserButton } from '@clerk/nextjs'
import Link from 'next/link'

export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>MCE Command Center (MVP)</h1>

      <SignedOut>
        <p>You are signed out.</p>
        <SignInButton />
      </SignedOut>

      <SignedIn>
        <p>Signed in.</p>
        <UserButton />
        <div style={{ marginTop: 12 }}>
          <Link href="/dashboard">Go to dashboard</Link>
        </div>
      </SignedIn>
    </main>
  )
}

3D) src/app/dashboard/page.tsx
import Link from 'next/link'
import { UserButton } from '@clerk/nextjs'

export default function Dashboard() {
  return (
    <main style={{ padding: 24 }}>
      <h2>Dashboard</h2>
      <UserButton />
      <ul style={{ marginTop: 12 }}>
        <li><Link href="/tasks">Tasks (RLS proof)</Link></li>
      </ul>
    </main>
  )
}

Step 4 — Supabase client that uses Clerk session token (RLS)

Per Clerk’s Supabase integration guide, you pass the Clerk session token to Supabase requests (so RLS policies can use auth.jwt()).

4A) src/lib/supabase/server.ts
import { auth } from '@clerk/nextjs/server'
import { createClient } from '@supabase/supabase-js'

export function createServerSupabaseClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

  return createClient(url, anonKey, {
    async accessToken() {
      return (await auth()).getToken()
    },
  })
}

4B) Add a tiny JSON logger (observability baseline)

src/lib/log.ts

export function log(level: 'info' | 'warn' | 'error', msg: string, ctx: Record<string, unknown> = {}) {
  const entry = { ts: new Date().toISOString(), level, msg, ...ctx }
  // Vercel captures console output; keep it structured
  // eslint-disable-next-line no-console
  console[level](JSON.stringify(entry))
}

Step 5 — Create the first table + RLS policies (Supabase SQL editor)

Use Clerk’s proven pattern: user_id defaults to auth.jwt()->>'sub' and policies compare to that subject claim.

In Supabase → SQL Editor run:

-- 1) Table
create table if not exists public.tasks (
  id bigserial primary key,
  name text not null,
  user_id text not null default auth.jwt()->>'sub',
  created_at timestamptz not null default now()
);

-- 2) Enable RLS
alter table public.tasks enable row level security;

-- 3) Policies: only owner can read/write
drop policy if exists "User can view their own tasks" on public.tasks;
create policy "User can view their own tasks"
on public.tasks
for select
to authenticated
using ((auth.jwt()->>'sub') = user_id);

drop policy if exists "Users must insert their own tasks" on public.tasks;
create policy "Users must insert their own tasks"
on public.tasks
for insert
to authenticated
with check ((auth.jwt()->>'sub') = user_id);


Rollback (destructive)

drop table if exists public.tasks;


Callout: Supabase positions RLS as “defense in depth” and recommends using it to protect data even when accessed via external tooling.

Step 6 — Tasks UI + server action (proof of RLS)
6A) src/app/tasks/actions.ts
'use server'

import { revalidatePath } from 'next/cache'
import { createServerSupabaseClient } from '@/lib/supabase/server'
import { log } from '@/lib/log'

export async function addTask(name: string) {
  const runId = crypto.randomUUID()
  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.from('tasks').insert({ name })
    if (error) {
      log('error', 'addTask failed', { runId, error: error.message })
      throw new Error('Failed to add task')
    }

    log('info', 'addTask ok', { runId })
    revalidatePath('/tasks')
  } catch (e: any) {
    log('error', 'addTask exception', { runId, error: e?.message ?? String(e) })
    throw e
  }
}

6B) src/app/tasks/page.tsx
import { createServerSupabaseClient } from '@/lib/supabase/server'
import { addTask } from './actions'

export default async function TasksPage() {
  const supabase = createServerSupabaseClient()
  const { data: tasks, error } = await supabase
    .from('tasks')
    .select('id,name,created_at')
    .order('id', { ascending: false })

  if (error) throw new Error(error.message)

  return (
    <main style={{ padding: 24 }}>
      <h2>Tasks (RLS-protected)</h2>

      <form
        action={async (formData) => {
          'use server'
          const name = String(formData.get('name') ?? '').trim()
          if (!name) return
          await addTask(name)
        }}
        style={{ display: 'flex', gap: 8, marginBottom: 16 }}
      >
        <input name="name" placeholder="New task" />
        <button type="submit">Add</button>
      </form>

      <ul>
        {tasks?.map((t) => (
          <li key={t.id}>
            {t.name} <small>({new Date(t.created_at).toLocaleString()})</small>
          </li>
        ))}
      </ul>
    </main>
  )
}

Step 7 — Smoke tests + CI gate
7A) Minimal env test

src/lib/env.ts

import { z } from 'zod'

export const EnvSchema = z.object({
  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: z.string().min(1),
  CLERK_SECRET_KEY: z.string().min(1),
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(10),
})

export function readEnv(env: NodeJS.ProcessEnv) {
  return EnvSchema.parse(env)
}


src/lib/env.test.ts

import { describe, expect, it } from 'vitest'
import { readEnv } from './env'

describe('env', () => {
  it('rejects missing vars', () => {
    expect(() => readEnv({} as any)).toThrow()
  })
})

7B) package.json scripts (add/merge)
{
  "scripts": {
    "lint": "next lint",
    "typecheck": "tsc --noEmit",
    "test": "vitest run",
    "build": "next build",
    "dev": "next dev"
  }
}

7C) GitHub Actions: .github/workflows/ci.yml
name: ci
on:
  push:
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: 9
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: pnpm
      - run: pnpm install --frozen-lockfile
      - run: pnpm lint
      - run: pnpm typecheck
      - run: pnpm test
      - run: pnpm build

Step 8 — Deploy to Vercel (UI + env vars)

Push repo to GitHub

Vercel → New Project → import GitHub repo

Vercel → Project → Settings → Environment Variables and add the four keys from .env.example (Production + Preview). Vercel encrypts env vars at rest; changes apply to new deployments.

Deploy; open /, sign in, then /tasks and add a task.

Callouts (risks / gotchas / tradeoffs)

P0 Security: Never expose Supabase service role key to the client; for this pattern you only need the anon key plus Clerk token. (General best practice; add a source if you want a formal policy doc.)

RLS correctness hinges on Supabase trusting Clerk JWTs (provider must be configured). If you skip Step 1C, auth.jwt() will not behave as expected.

Agent #2 (strict reviewer) — top risks

P0: Missing policy for update/delete on tasks (fine for MVP, but don’t add UI without policies).

P1: Add rate limiting + CSRF posture for server actions before exposing external/client roles.

P1: Add an audit table early (write-once) once you start handling contracts/tenders.

Validation (tests, acceptance criteria, how to confirm)
Local
pnpm dev
# visit http://localhost:3000
# sign in, then visit /tasks and add a task

pnpm lint && pnpm typecheck && pnpm test && pnpm build

RLS proof

Sign in as User A → add task “A1”

Sign out, sign in as User B → tasks list must be empty (cannot see “A1”)

If User B can see User A rows, treat as P0 incident (stop and fix policies).

Production

Vercel deployment opens, sign-in works, /tasks CRUD works.

Check Vercel logs: you should see JSON logs with runId for addTask calls.

ONE Next action + Success signal

Next action: Complete Step 1C (Clerk ↔ Supabase third-party auth) and then run the SQL in Step 5 in Supabase SQL Editor.

Success signal: After that, pnpm dev → sign in → /tasks loads without errors and adding a task succeeds; signing in as a different user shows zero of the first user’s tasks.


Improve and Enhance and 
project_manifest:
  session_id: "{{SID}}"
  project_name: "{{PROJECT}}"
  user_role: "{{ROLE}}"
  useful_context:
    - "{{CTX1}}"
    - "{{CTX2}}"
    - "{{CTX3}}"
  essential_considerations:
    - "{{CON1}}"
    - "{{CON2}}"
  parameters:
    - "{{PARAM1}}"
    - "{{PARAM2}}"
  metadata:
    version: "1.0"
    last_modified: "{{TS}}"
  seeding_points:
    - "{{SEED1}}"
    - "{{SEED2}}"

execution_settings:
  chunk_size_percent: 10
  blank_cheque_x: 10
  execution_caps:
    per_phase_runs: 6
    stress_test_max_per_scenario: 10
    project_total_max: 30

telemetry:
  run_id: "{{RID}}"
  phase: "{{PHASE}}"
  checkpoint: "{{CP}}"

agents:
  model_semantic_cleaning: "{{MODEL_A}}"
  model_structure_validation: "{{MODEL_B}}"
  model_kg_parsing: "{{MODEL_C}}"
  model_recombination: "{{MODEL_D}}"
  model_devil_advocate: "{{MODEL_E}}"

stress_test_scenarios:
  mce_tendering_1:
    narrative: "{{REALISTIC_DATA}}"
  mce_tendering_2:
    narrative: "{{REALISTIC_DATA}}"
  mce_digital_transformation_1:
    narrative: "{{REALISTIC_DATA}}"
  mce_digital_transformation_2:
    narrative: "{{REALISTIC_DATA}}"
  generic_1:
    narrative: "{{GENERIC_DATA}}"
  generic_2:
    narrative: "{{GENERIC_DATA}}"
  generic_3:
    narrative: "{{GENERIC_DATA}}"
  generic_4:
    narrative: "{{GENERIC_DATA}}"


## Copilot

`````yaml name=PROJECT-MANIFEST.optimized.yaml
# Purpose: Single source-of-truth manifest to drive an MVP “MCE Command Center”
# Stack: Next.js (App Router) + Supabase (Postgres/RLS/Storage) + Clerk (Auth) + Vercel (Deploy)
# Mode: Security-first, RLS-proof baseline with clean upgrade path (workflows, RAG, evaluators, audit)

project_manifest:
  identifiers:
    session_id: "{{SID}}"
    run_id: "{{RID}}"
    project_name: "MCE Command Center"
    owner: "Moe"
    repository: "github.com/<org>/<repo>"
    version: "0.1.0"
    last_modified: "{{TS}}"

  stakeholders:
    user_role: "Staff+ Engineer / PM+Builder"
    personas:
      - Executive (Chairman, Vice Chairman)
      - Dept Head
      - PM / Engineer
      - Compliance
      - Doc Control
      - HR
    decision_owners:
      - Security: "Security/Compliance Lead"
      - Data: "Architect"
      - Workflows: "Planner"
      - Deploy: "DevOps"

  stack_profile:
    frontend: "Next.js 14+ (App Router), TypeScript, Tailwind"
    auth: "Clerk (Next.js middleware + session tokens)"
    database: "Supabase Postgres (RLS enabled)"
    storage: "Supabase Storage (private bucket, signed URLs)"
    deploy: "Vercel (Prod/Preview)"
    ci: "GitHub Actions (lint, typecheck, test, build)"
    observability: "Structured JSON logs (console), request/run IDs"

  environments:
    local:
      url: "http://localhost:3000"
      env_required:
        - NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY
        - CLERK_SECRET_KEY
        - NEXT_PUBLIC_SUPABASE_URL
        - NEXT_PUBLIC_SUPABASE_ANON_KEY
    preview:
      vercel_project: "mce-command-center"
      notes: "Feature branches; gate suite runs; no public buckets"
    production:
      vercel_url: "https://mce-command-center.vercel.app"
      notes: "HTTPS enforced; headers: CSP/HSTS/XFO/Referrer-Policy"

  success_metrics:
    - "Auth flows work (sign in/up/out) in Prod"
    - "RLS proof: user reads/writes only their own rows (UI + direct API checks)"
    - "CI passes: lint, typecheck, tests, build"
    - "Observability: request/run IDs logged for server actions and route handlers"

  constraints:
    time: "Fast MVP delivery; prioritize proof-of-RLS feature first"
    security: "Least privilege; never expose service-role client-side"
    destructive_ops: "Require rollback SQL; snapshot before policy/schema rewrites"
    cost: "Prefer free tiers; avoid always-on services unless needed"

  assumptions_log:
    - assumption: "Use Next.js App Router"
      risk: "Middleware/pattern differences if not"
      verify: "Check Next.js version; ensure app/ exists"
      default: "App Router"
    - assumption: "Clerk → Supabase third-party auth"
      risk: "Broken auth.jwt() mapping"
      verify: "Enable Supabase 'Clerk provider' with Clerk domain"
      default: "Official integration"
    - assumption: "Single-tenant per user (not org)"
      risk: "Later need Clerk Organizations"
      verify: "Scope decision post-MVP"
      default: "User-scoped now; org later"

  gates: # SEG-06 mapping
    g_sec_baseline:
      owasp_top10_2025_covered: true
      evidence: ["docs/security/SECURITY_GATES.md"]
    g_authn_authz:
      clerk_configured: true
      rls_enabled_all_core_tables: true
    g_data_safety:
      migrations_have_rollback: true
      backups_before_policy_change: true
    g_log_alert:
      structured_logs: true
      sweep_heartbeat_alerts: true
    g_supply_chain:
      sbom: true
      slsa_attestation: true
    g_headers:
      csp_hsts_referrer_xcto_xfo: true
    g_release_ready:
      ci_green: true
      runbook_present: true

  deliverables:
    - "Working Next.js app with Clerk auth and protected routes"
    - "Supabase table(s) + RLS policies + proof-of-RLS UI"
    - "CI workflow (lint/typecheck/test/build)"
    - "Deployment to Vercel with env vars configured"
    - "Security gates + ADRs (auth/authz, RAG retrieval strategy, notification engine)"
    - "Runbook (gate failures, missed sweeps, provenance gaps, collisions)"

  data:
    models:
      core_tables:
        - name: "tasks"
          purpose: "Proof-of-RLS user-scoped CRUD"
          columns: ["id bigserial pk", "name text", "user_id text default auth.jwt()->>'sub'", "created_at timestamptz default now()"]
          rls_policies:
            - "select: authenticated users can select where user_id = auth.jwt()->>'sub'"
            - "insert: with check user_id = auth.jwt()->>'sub'"
        - name: "documents (phase-2)"
          purpose: "Contracts/Submissions library with sensitivity"
          storage: "Supabase private bucket + signed URLs"
        - name: "projects (phase-2)"
          purpose: "Portfolio, milestones, staffing"
        - name: "tenders (phase-2)"
          purpose: "Pipeline, requirements coverage, countdowns"
      views (phase-2):
        - "v_tenders_with_countdown"
        - "v_milestones_due"
        - "v_rfi_aging"
        - "v_ncr_aging"
    source_of_truth_rules:
      - "KPIs must declare canonical table/view"
      - "No computed metric without SOT declaration and audit trail"

  workflows (phase-2 ready):
    - id: "WF-BID-001"
      name: "Tender Intake → Requirements → Submission"
    - id: "WF-DES-002"
      name: "Design Phase: Submittals/RFIs/VOs"
    - id: "WF-SUP-003"
      name: "Site Supervision: Inspections/NCRs"
    - id: "WF-PROG-004"
      name: "Progress: Milestones → Certificates"
    - id: "WF-COMP-005"
      name: "Compliance/NOCs/Permits → Renewals"
    - id: "WF-RES-006"
      name: "Resource & Staffing → Mobilization"
    - id: "WF-DOC-007"
      name: "Document Control: Transmittals/Filing"
    - id: "WF-CLOSE-008"
      name: "Closeout → Handover → DLP"
    - id: "WF-DLP-009"
      name: "DLP Defects → Corrective Actions → Closure"

  dashboards (phase-2 ready):
    executive:
      kpis: ["Active Projects", "Tenders Due", "Overdue Tasks", "Compliance Due"]
      ladders: ["Milestones", "Permits"]
      charts: ["Win Rate", "S-curve"]
    tender:
      components: ["Pipeline board", "Coverage %", "Countdown ladder", "Comms log"]
    project:
      components: ["Portfolio grid", "Milestone matrix", "S-curve", "Certificate pipeline"]
    qaqc:
      components: ["NCR Aging", "Inspection pass rate", "Defect burndown"]
    compliance:
      components: ["Register table", "Renewal countdown", "Authority heatmap"]
    resources:
      components: ["Utilization heatmap", "Vacancies table", "Mobilization timeline"]
    documents:
      components: ["Filing completeness %", "Sensitive access matrix"]

  security:
    rls_examples:
      tasks_select: "auth.jwt()->>'sub' = tasks.user_id"
      tasks_insert: "with check auth.jwt()->>'sub' = user_id"
    storage_policy:
      bucket: "mce-documents"
      access: "private, server-issued signed URLs only"
    headers:
      csp: "default-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'"
      hsts: "max-age=31536000; includeSubDomains; preload"
      referrer_policy: "no-referrer"
      x_content_type_options: "nosniff"
      x_frame_options: "DENY"

  observability:
    logs: "Structured JSON (console) with {ts, level, msg, runId, ctx}"
    run_ids: "Generate per server action to trace operations"
    heartbeat:
      sweeps: "Phase-2: notification sweep heartbeat and missed-run alerting"
      dashboard: "Heartbeat status tiles on /admin"

  ci:
    github_actions: ".github/workflows/ci.yml (lint/typecheck/test/build)"
    gates:
      - "block on high vulnerabilities (Snyk)"
      - "attach SBOM + SLSA attestation on release artifacts"

  deployment:
    vercel_project: "mce-command-center"
    env_vars:
      - NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY
      - CLERK_SECRET_KEY
      - NEXT_PUBLIC_SUPABASE_URL
      - NEXT_PUBLIC_SUPABASE_ANON_KEY
    post_deploy_checklist:
      - "Auth works (sign in/out)"
      - "/tasks RLS works with two users (A sees A rows; B sees B rows)"
      - "Logs show runId entries for server actions"

  seeding_points:
    - "Create two Clerk users; add tasks as each; confirm isolation"
    - "Phase-2: Import projects/clients from cleaned CSVs; tag pseudo data"

execution_settings:
  segmentation:
    chunk_size_percent: 10
    per_phase_runs: 6
    stress_test_max_per_scenario: 10
    project_total_max: 30
  guardrails:
    deny_by_default: true
    evidence_first: true # cite or refuse in RAG later
    rollback_required_for_sql: true
    snapshot_before_policy_change: true

gate_suite:
  tests:
    - id: "RLS_matrix"
      expect: "403 when accessing other users’ rows (direct + UI)"
    - id: "storage_privacy"
      expect: "No client-side read from private bucket without signed URL"
    - id: "injection_xss"
      expect: "Validators (Zod) block payloads; no string-concat SQL"
    - id: "sweep_heartbeat"
      expect: "Missed-run alert within 30m (phase-2)"
    - id: "rag_cite_or_refuse"
      expect: "All answers cite chunks or refuse (phase-2)"

telemetry:
  phase: "{{PHASE}}"
  checkpoint: "{{CP}}"
  git_commit: "{{GIT_SHA}}"
  vercel_url: "https://mce-command-center.vercel.app"
  notes: "Attach acceptance reports and convergence ledger entries per run"

agents:
  roster:
    - id: "Agent-00"
      role: "Orchestrator"
      responsibility: "Sequencing, gate enforcement, change control"
    - id: "Agent-01"
      role: "Architect"
      responsibility: "Data model, RLS strategy, module boundaries"
    - id: "Agent-02"
      role: "Builder"
      responsibility: "Next.js implementation, typed DB access, UI"
    - id: "Agent-03"
      role: "Security"
      responsibility: "Policies, threat model, audit logging"
    - id: "Agent-04"
      role: "QA/Evals"
      responsibility: "Smoke tests, golden tasks, CI gates"
    - id: "Agent-05"
      role: "Docs/Runbooks"
      responsibility: "Ops docs, onboarding, incident playbooks"

stress_test_scenarios:
  mce_tendering_1:
    narrative: "RFQ intake with incomplete document coverage → countdown/alarm → escalation on missed acknowledgment"
  mce_tendering_2:
    narrative: "Template drift detected during TOC generation → meta-alert → admin adjudication → SOT override"
  mce_digital_transformation_1:
    narrative: "RLS misconfiguration blocks PM from reading own project → gate failure → policy fix → acceptance retest"
  mce_digital_transformation_2:
    narrative: "Missed sweep heartbeat (notifications) → manual RPC backfill → heartbeat dashboard turns green"
  generic_1:
    narrative: "Clerk token → Supabase mapping fails → auth.jwt() mismatch → revert to provider setup → re-run"
  generic_2:
    narrative: "Storage privacy violation attempt → signed URL required → deny + log"
  generic_3:
    narrative: "CI supply chain gate blocks release on high vulnerability → revert dep → attest build → release"
  generic_4:
    narrative: "RAG uncited answer (phase-2) → fail-closed → switch to retrieval-only → re-index and eval pass"
`````

````markdown name=MANIFEST-README.md
# PROJECT-MANIFEST: How to use

Purpose
- This manifest is your single source-of-truth to drive the MVP build and safe upgrades.
- It encodes stack, gates, data models, workflows, dashboards, CI/deploy, and stress tests.

Quick Start (MVP baseline)
1) Wire Clerk ↔ Supabase provider integration (third-party auth).
2) Bootstrap Next.js app; add middleware for protected routes.
3) Create `tasks` table + RLS policies in Supabase; verify via two users.
4) Implement `/tasks` server action + structured logs (runId per call).
5) Add CI workflow (lint/typecheck/test/build); deploy to Vercel and configure env vars.

Proof-of-RLS Acceptance
- User A creates “A1” task; User B should not see it.
- If B sees A rows, STOP: fix RLS policies and re-run acceptance.

Upgrade Path (Phase-2)
- Add workflows (WF-*), dashboards, views, and storage policies.
- Introduce notification sweep heartbeat; add convergence ledger entries for collisions.
- Adopt hybrid RAG (FTS + vector) with strict cite-or-refuse.

Gate Suite
- Run tests listed in `gate_suite.tests`; all must be green before “final outputs.”
- Fail-closed policy: any red gate → STOP; remediate and re-run.

Telemetry
- Attach runId, phase, checkpoint, git commit, and vercel URL in acceptance reports.
- Keep structured logs visible in Vercel; use them for on-call debugging.

Incident Runbook (short)
- RLS mismatch: stop, run RLS matrix test, fix policies, add deny tests.
- Missed sweep: check cron, run manual RPC, backfill, add heartbeat alert.
- Provenance gaps: re-run CI with SBOM/SLSA; block releases until attested.
- Collisions: open convergence ledger entry; adjudicate SOT overrides.

Success Signal
- Prod deploy live; auth works; RLS proof verified; CI green; logs show runId on server actions.

Next Steps
- Populate repository with this manifest; wire CI and deploy; begin Phase-2 modeling (projects, tenders, documents) under the same gates.
````
