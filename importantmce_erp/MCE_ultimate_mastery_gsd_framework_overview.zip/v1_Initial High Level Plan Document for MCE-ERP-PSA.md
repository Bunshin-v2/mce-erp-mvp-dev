# Plan Document for MCE ERP/CRM/PSA 

Design a production-quality, low-cost “MCE Command Center” (ERP/PSA-lite) using the recommended stack: Next.js + Supabase (Postgres/RLS/Storage) + Clerk + Vercel, with an agentic layer (workflows, evaluators, tool contracts) that is safe-by-default and upgradeable to full enterprise rigor.

Success metrics (measurable)

MVP functional: Project CRUD + Contract/Document upload + Basic search + Role-based access working end-to-end in production.

Security: RLS enforced on all core tables; no public write access; OWASP baseline (CSP, input validation, authz checks).

Reliability: 99% of requests succeed in smoke test suite; timeouts/retries for external calls; no unhandled exceptions in logs.

Observability: request IDs + structured logs + audit log entries for all state changes; basic error alerting configured.

Maintainability: typed DB access patterns, lint/format, CI checks, migrations tracked, prompts/workflows versioned.

Constraints

Stack (fixed): Next.js (App Router) + Supabase + Clerk + Vercel.

Cost: prioritize free tiers and “pay only when needed”; avoid always-on servers where possible.

Domain: MCE is a consultancy (tenders/RFP/Qs, proposals, consultancy agreements, submissions, variations/orders). No BoQ ownership.

Risk tolerance: low tolerance for data loss / privilege mistakes; require explicit confirmation for destructive actions (migrations that drop, deletes, bulk updates).

Assumptions & Uncertainty Log
Assumption	Why it matters	Risk if wrong	How to verify	Default choice
Single organization (MCE) tenant; roles per user	Simplifies schema/RLS	Later need multi-tenant separation	Confirm if external client portals are required now	Single-tenant now, multi-tenant-ready columns
Users ~50 internal + limited external clients	Impacts Clerk plan, RLS rules	Auth costs / complexity	Confirm expected external users	Internal-first; add client role later
Documents stored in Supabase Storage	Simplifies infra and cost	Large files / retention needs	Confirm max file sizes + retention policy	Store files + metadata table + signed URLs
Search MVP = Postgres full-text	Fast to ship	Semantic search needed sooner	Confirm search expectations	FTS now; pgvector later
Background reminders can be “manual trigger” initially	Avoid job infra	Missed reminders	Confirm need for automated weekly reminders	Manual + optional Vercel Cron phase 2
Checklist (high-level)

 Lock MVP scope (4 modules) and data model

 Create accounts/projects: Supabase + Clerk + Vercel

 Bootstrap Next.js repo with TS + lint + tests + CI

 Implement DB schema + RLS + audit logs

 Implement auth (Clerk) + RBAC mapping

 Build core UI (Projects, Contracts, Tenders-lite, Search)

 Add upload pipeline (Storage + virus-scan placeholder + metadata)

 Add observability (structured logs, request IDs, error tracking)

 Add agentic workflow layer (state machine + tool contracts + eval harness)

 Deploy to Vercel with production smoke tests

Step 1 — Simplify the product into an MVP that still fits MCE reality

MVP modules (ship first):

Projects: code, name, client, PM, status, key dates, tags

Clients: name, contacts, classification, notes

Contracts & Submissions (Document Library): document type (agreement/proposal/submission/variation/order), project link, versioning, approvals-lite, storage link

Tender Tracker (lite): opportunities, deadlines, last client communication, reminder status

UI (Next.js App Router) pages

/dashboard (KPIs: tenders due, expiring contracts, projects at risk)

/projects / /projects/[id]

/documents (contracts + submissions library)

/tenders

/search

Data design principle

Keep documents as first-class entities (metadata table + file storage object).

Track client communications as append-only events (for reminders & auditing).

Step 2 — Architecture (MVP-fast, production-upgradeable)
Runtime architecture

Next.js (server components + route handlers) for core app logic

Supabase Postgres as source of truth (RLS + audit + workflow state)

Supabase Storage for documents

Clerk for authentication; map Clerk user → internal profiles row

Vercel hosting + optional Vercel Cron later for reminders

Agentic architecture (lightweight but correct)

Use a workflow graph + evaluators (not an uncontrolled “agent that does things”):

Pattern

Planner (Agent-1): proposes actions/changes, never executes destructive operations

Executor (system): performs DB/storage actions through typed tool contracts

Reviewer (Agent-2): blocks risky changes, enforces schemas/RLS/logging/tests

Deterministic state

workflows table: definitions (versioned)

workflow_instances table: current state + entity refs

workflow_events append-only log

Transitions validated by pure guards + schema validation

This gives you agentic automation without losing control of correctness, auditability, or security.

Step 3 — Tool contracts (schemas) and injection resistance
Tool contract rules (non-negotiable)

Every tool input/output has a JSON schema (use zod in code).

All tools enforce:

timeouts

retries (exponential backoff)

idempotency keys for writes

allowlist validation (especially for SQL-like operations)

Prompt-injection resistance (practical, implementable)

Treat uploaded documents as untrusted input:

Never allow docs to define permissions, tools, or policies.

Use strict extraction prompts: “extract fields only” → store structured facts.

Separate “analysis” from “actions”:

Model can recommend; execution requires explicit user confirmation for destructive actions.

Log “model suggestion → applied change” as an auditable chain.

Step 4 — The corrected and simplified “Executional Prompt” (pasteable, versioned)

Below is the re-articulated prompt aligned to the Next.js + Supabase + Clerk + Vercel stack, and simplified to a safe MVP with an upgrade path.

!MAXENFORCE

# MCE Command Center (ERP/PSA-lite) — Next.js + Supabase + Clerk + Vercel
## Prompt Version
- version: 1.0.0
- changelog:
  - 1.0.0: Rebased from Vue/Mongo/Docker-first to Next.js/Supabase/Clerk/Vercel. Simplified to MVP modules + deterministic workflows + RLS-first security.

## Mission
Ship a production-grade, low-cost internal system for MCE to manage:
- Projects
- Clients
- Contracts/Submissions document library
- Tender tracker (deadlines + reminders + last communications)
with strict RBAC/RLS, audit logging, and an agentic workflow layer that is deterministic and testable.

## Non-negotiables (Gates)
Halt if any gate fails:
1) RLS enabled + verified on all core tables
2) No public write access (anon cannot insert/update/delete)
3) Typecheck + lint pass
4) Smoke tests pass (auth, CRUD, upload, search)
5) Audit logs created for all state-changing operations
6) Any destructive operation (drop table, delete rows, overwrite storage) requires explicit human confirmation

## Stack (fixed)
- Next.js (App Router) + TypeScript
- Supabase (Postgres + RLS + Storage)
- Clerk (Auth + org/user claims)
- Vercel deployment

## MVP Scope (Phase 1)
Pages:
- /dashboard, /projects, /documents, /tenders, /search
Core actions:
- Project CRUD
- Document upload (Storage) + metadata + versioning
- Tender CRUD + due-date flags + last communication log
- Basic search (Postgres FTS on name/code/title + filters)

## Agentic Scope (Phase 1)
Implement deterministic workflows (not free-form agents):
- Workflow engine: state machine with guards/actions
- Versioned workflow definitions (JSON)
- Workflow event log (append-only)
- Evaluators:
  - Security evaluator (RLS/policy checks)
  - Data integrity evaluator (constraints, foreign keys)
  - Regression evaluator (golden tasks)

## Execution Plan (stop at pre-execution)
1) Create Supabase + Clerk + Vercel projects; capture env vars
2) Bootstrap Next.js repo (TS, eslint, prettier, vitest, playwright smoke)
3) Define DB schema + RLS policies + audit triggers (Supabase migrations)
4) Implement auth mapping (Clerk user -> profiles) + role claims
5) Implement Projects + Documents + Tenders + Search
6) Add workflow tables + minimal engine + golden-task eval harness
7) Add logging, request IDs, and deployment smoke tests
8) Deploy to Vercel; run post-deploy verification checklist

## Required Deliverables
- repo structure with README, .env.example, migrations
- RLS policy docs (who can do what)
- smoke test commands + CI config
- prompt/workflow versioning + regression tasks

Step 5 — Minimal “Agent Mesh” for MVP (expand later)

You do not need 15 agents to ship a safe MVP. Start with 6, expand when the product earns it.

MVP Mesh (6 agents)

Agent-00 Orchestrator: sequencing, gate enforcement, change control

Agent-01 Architect: data model, RLS strategy, module boundaries

Agent-02 Builder: Next.js implementation, typed DB access, UI

Agent-03 Security/RLS: policies, threat model, audit logging

Agent-04 QA/Evals: smoke tests + golden tasks + CI gates

Agent-05 Docs/Runbooks: ops docs + onboarding steps

Expansion Mesh (optional later)

Add: workflow specialist, observability/SRE, adversarial tester, import/ETL engineer, performance specialist.

Step 6 — Guidance for “the page” (Next.js App Router best practice)

Recommendation (general best practice):

Use Server Components for data fetching where possible.

Use Server Actions (or route handlers) for writes; keep them behind authz checks.

Centralize authorization in one layer:

lib/authz.ts → checks role/ownership

DB enforces final decision via RLS (defense in depth)

Page composition example (structure-level)

app/projects/page.tsx → list view (server component)

app/projects/[id]/page.tsx → detail view

app/projects/actions.ts → server actions for create/update

components/projects/* → client components only where needed

Step 7 — Agent #2 (Senior Engineer) review: top risks + prioritized fixes
Top risks (in order)

Auth/RLS mismatch (app thinks user can; DB denies—or worse, DB allows too much)

Document uploads (PII leakage, insecure URLs, missing retention/versioning)

Overbuilding agent mesh before shipping MVP

No deterministic workflows → “agent spaghetti” without audits/tests

No rollback path for schema/policy mistakes

Prioritized fixes

P0 (must do before production)

RLS-first design; verify with anon and role-based tests

Audit log append-only for all mutations

Signed URLs for documents; never public buckets for sensitive docs

Smoke tests: auth + CRUD + upload + search

P1 (next)

Golden-task eval harness for workflows (pass/fail)

Basic observability: request IDs + error tracking

Import pipeline with validation (later, but plan now)

P2 (later)

Semantic search (pgvector)

Automated reminders (Vercel Cron)

Client portal hardening and multi-tenant separation

Callouts (risks / gotchas / tradeoffs)

Supabase RLS is your “real” authorization. App-layer RBAC is not sufficient.

Clerk roles must map deterministically to DB policies (store role in profiles, or use JWT claims with Supabase integration pattern).

Uploads: “free tier storage” is not a security feature. Treat all docs as sensitive by default.

Agentic automation: start with deterministic workflows + evaluators; do not let an LLM execute writes without schema-bound tools and explicit confirmation gates.

Validation (tests + acceptance criteria)

Smoke tests (minimum)

Auth: user can sign in; session persists

RBAC: employee cannot access admin routes; client cannot access internal-only records

RLS checks: direct DB calls under anon cannot read/write restricted tables

Projects CRUD: create/read/update with audit log entries

Document upload: file stored + metadata row created + signed URL access works

Search: returns results by code/name/title; respects RLS

Acceptance criteria

A PM can: create project → upload contract/submission → log tender deadline → search by project code → see dashboard counts update.

Audit log shows each action with actor, timestamp, entity, and delta metadata.

Rollback note (for destructive changes)

DB: migrations are forward-only unless explicitly authored “down”; take a snapshot before any policy/schema rewrite.

Storage: never overwrite keys; version files (/docs/{docId}/v{n}/...) so rollback is pointer-based.