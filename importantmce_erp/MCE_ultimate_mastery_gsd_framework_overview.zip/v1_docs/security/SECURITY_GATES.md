# Security & Compliance Gates (SEG-06)

## Standards
- OWASP Top 10:2025
- OWASP ASVS Level 2 (target)
- NIST SSDF (SP 800-218) — Prepare/Protect/Produce/Respond (evidence only)
- SLSA v1.2 provenance for CI

## Gate Registry (enforceable)
- G-SEC-BASELINE (Top 10 coverage)
- G-AUTHN-AUTHZ (Clerk + RLS)
- G-DATA-SAFETY (migrations/backup/rollback)
- G-LOG-ALERT (security logging + alerting)
- G-SUPPLY-CHAIN (dependency health + CI provenance)
- G-CSP/HSTS (headers and browser controls)
- G-EXCEPTIONS (error handling, fail-closed)
- G-RELEASE-READY (QA + runbook + rollback)

---

## OWASP Top 10:2025 Mapping → Controls

A01 Broken Access Control → Enforce RLS + membership checks
- Evidence: RLS policy files; tests for cross-entity access denial.
- Check: L4 cannot read unrelated tender/project; L2 exec can read dashboards only.
- Rollback: Disable affected routes; hotfix RLS; re-run deny tests.

A02 Security Misconfiguration → Secure defaults (private buckets, least-priv env)
- Evidence: Supabase storage policies; `.env.example` without secrets.
- Check: Private bucket for documents; signed URL issuance server-side.
- Rollback: Flip bucket to private; revoke public keys.

A03 Supply Chain Failures → Pin deps; CI SBOM + SLSA provenance
- Evidence: lockfiles; SBOM; SLSA attestations in CI artifacts.
- Check: High vuln = block; provenance attached on release.
- Rollback: Revert dependency; apply patched version.

A04 Cryptographic Failures → TLS at edges; signed URLs; secret rotation
- Evidence: Rotation policy; KMS-integration notes; HTTPS-only config.
- Check: No HTTP; signed URL expiration ≤10min; refresh tokens ≤7 days.
- Rollback: Force rotate keys; shorten token TTLs.

A05 Injection → Parameterized queries; input validation (Zod)
- Evidence: Validators per endpoint; no string-concat SQL.
- Check: Fuzz tests for SQL/XSS; reject on invalid schema.
- Rollback: Patch validators; add escaping; block offending path.

A06 Insecure Design → Workflow guards; authZ at service layer
- Evidence: Guard functions; state machine validation.
- Check: Illegal transitions rejected; audit logged.
- Rollback: Disable transition; add guard; revalidate scenarios.

A07 Authentication Failures → Clerk config; JWT verification
- Evidence: JWT middleware; sub→profiles mapping docs.
- Check: Expired tokens denied; signature verified server-side.
- Rollback: Invalidate sessions; adjust JWT lifetimes.

A08 Integrity Failures → Hashes on uploads; immutable audit logs
- Evidence: Audit append-only; checksum optional on docs.
- Check: No DELETE/UPDATE in audit; tamper detection logs.
- Rollback: Restore from backup; mark corruption; reindex.

A09 Security Logging & Alerting → Structured logs; alert thresholds
- Evidence: Correlation IDs; alert rules; runbooks.
- Check: 4xx/5xx spikes page on-call; sweep heartbeat alerts.
- Rollback: Increase sensitivity; disable noisy alerts with whitelist.

A10 Mishandling of Exceptional Conditions → Fail-closed patterns
- Evidence: Error handlers; refusal policies in RAG.
- Check: On exception → no partial writes; RAG refuses w/o evidence.
- Rollback: Add circuit breaker; sandbox failing features.

---

## ASVS Level 2 — Evidence Requirements
- AuthN/AuthZ: Multi-layer checks (JWT, RLS, membership)
- Input Validation: Zod schemas, server-side verification
- Session Management: TTLs, rotation policies documented
- Error Handling: No sensitive info in responses/logs
- Data Protection: Sensitivity levels enforced; least privilege
- Logging & Monitoring: Security events + alerts

---

## Headers & Browser Controls
- CSP: default-src 'self'; img-src 'self' data:; connect-src 'self' api; object-src 'none'; frame-ancestors 'none'
- HSTS: max-age=31536000; includeSubDomains; preload
- Referrer-Policy: no-referrer
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY

---

## Gate Acceptance Tests (critical)
- RLS Matrix: L2 vs L4 across endpoints (403 expected for L4 on unrelated entities)
- Storage: Private bucket read denied client-side; signed URLs only via server
- Injection: Negative tests (SQL/XSS payloads) blocked
- Logging: Sweep heartbeat alert fires if missed 30m
- RAG: Answers contain citations OR refusal

---

## Rollback Patterns
- Auth: Force logout; reduce TTL; rotate secrets
- DB: Snapshot restore; forward-fix migration (no enum deletions)
- Storage: Revoke public; rotate bucket keys; audit access
- CI: Freeze releases; revert dependency bump; re-run SBOM

---