# ADR-002: Permission Model

## Decision
Table-driven 4-tier permission levels + department assignments; entity membership overrides.

## Context
AEC roles differ by department; need configurable scopes without schema churn.

## Options
1) Enum roles only
2) Table-driven tiers (chosen)
3) Policy-as-code engine (Phase 2)

## Pros/Cons
+ Reconfigurable without migrations
+ Clear auditability of changes
- Slightly more joins; requires governance UI

## Consequences
- `permission_levels`, `profile_department_permissions`, `entity_memberships` are canonical.
- UI must resolve effective permissions per view/action.

## Rollback
- Temporary hard-coded checks for critical paths; sync back to tables ASAP.