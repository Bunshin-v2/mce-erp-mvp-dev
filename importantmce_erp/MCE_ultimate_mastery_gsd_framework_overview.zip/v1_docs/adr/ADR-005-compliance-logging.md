# ADR-005: Compliance Logging & Evidence

## Decision
Structured security logs with correlation IDs; append-only audit; evidence packs for renewals/submissions.

## Context
UAE compliance (permits/NOCs), tender submissions, QA/QC actions require traceable evidence.

## Options
1) Ad-hoc logs
2) Structured audit + evidence mapping (chosen)
3) External SIEM integration (Phase 2)

## Pros/Cons
+ Forensic trail; gate-ready
- Storage growth; need rotation policy

## Consequences
- No DELETE/UPDATE in audit; evidence packs linked to entities
- Alerts on anomalies (surges, missing acks)

## Rollback
- Archive to cold storage; compress older logs; increase retention granularity.