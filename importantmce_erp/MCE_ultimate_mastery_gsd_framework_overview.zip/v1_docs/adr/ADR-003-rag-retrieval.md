# ADR-003: RAG Retrieval Strategy

## Decision
Hybrid retrieval: Postgres FTS (BM25-like) + pgvector embeddings; rank fusion + strict cite-or-refuse policy.

## Context
Contracts and technical docs require exact citations and compliance posture.

## Options
1) Vector-only
2) FTS-only
3) Hybrid fusion (chosen)

## Pros/Cons
+ Better precision/recall; deterministic filters (entity/sensitivity)
- More infra/config; evaluation harness needed

## Consequences
- Ingestion → chunks + embeddings; filters by entity/sensitivity
- Answers must include citations; refusal allowed on low evidence

## Rollback
- Disable generation; retrieval-only responses; manual curation.