# ADR-004: Notification/Alarm Engine

## Decision
DB-side sweep via pg_cron + RPC function; dedupe window 12h; escalation matrix per severity.

## Context
Tender deadlines, compliance renewals, NCR aging need reliable reminders.

## Options
1) App-side schedulers
2) DB cron + RPC (chosen)
3) External queue/service (Phase 2)

## Pros/Cons
+ Close to data; simpler ops in MVP
- Cron visibility; need heartbeat alerts

## Consequences
- Heartbeat dashboard; alerts on missed runs
- Acknowledgement stops escalation

## Rollback
- Move critical sweeps to Edge Functions; keep cron as safety net.