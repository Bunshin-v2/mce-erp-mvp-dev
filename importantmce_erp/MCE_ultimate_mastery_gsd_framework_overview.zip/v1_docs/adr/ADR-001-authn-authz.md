# ADR-001: Authentication & Authorization Stack

## Decision
Use Clerk for AuthN (JWT) + Supabase RLS + table-driven permissions (4-tier, department-scoped).

## Context
- Need fast, secure AuthN with minimal bespoke code.
- Must enforce per-entity access and sensitive-doc visibility.

## Options
1) Clerk + RLS (chosen)
2) Auth.js + RLS
3) Custom JWT service + RLS

## Pros/Cons
+ Rapid integration; production-grade; SDK support
+ RLS enforces server-side data boundaries
- Vendor dependency; correct JWT→profile mapping required

## Consequences
- JWT must map `sub` to `profiles.clerk_user_id`.
- All reads/writes pass through RLS-aware services.

## Rollback
- Switch to Auth.js while keeping RLS; provide migration mapping for identifiers.