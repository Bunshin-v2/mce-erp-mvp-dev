# Auto-Claude Adapter (Batch Orchestration & Provenance)

Purpose
- Run multi-lane agent batches (plan → execute → verify) with strict gate enforcement, provenance capture (SLSA), and auditable outputs.

Execution Policy (YAML)
```yaml
auto_claude:
  lanes: 5
  max_iterations_per_lane: 3
  stop_on_gate_failure: true
  gates:
    - RLS_matrix
    - storage_privacy_signed_url_only
    - injection_xss_fuzz_blocked
    - sweep_heartbeat_alerts
    - rag_cite_or_refuse
  provenance:
    sbom: true
    slsa_attestation: true
  outputs:
    - convergence_ledger
    - audit_log
    - acceptance_reports
```

Batch Templates
- “WF-BID-001 Tender Intake” → plan tasks, execute checklist/TOC, verify coverage% → acceptance report
- “WF-COMP-005 Compliance Renewals” → refresh register, schedule followups, verify expiries → acceptance report
- “WF-SUP-003 NCR Closeout” → ingest NCRs, assign corrective tasks, verify closure → acceptance report

Gate Hooks (per batch)
- Before lane start → run `/mce:gate-check`
- After lane finish → attach acceptance evidence + logs
- On failure → stop all lanes; produce remediation batch plan

Provenance Capture
- SBOM generated per batch
- SLSA attestation attached to artifacts (CI pipeline integration)
- Hashes for outputs (docs, CSVs, views) stored for integrity

Acceptance (adapter health)
- Zero gate bypasses
- All artifacts carry provenance
- Convergence ledger populated for collisions (duplicates, ambiguous permits, inconsistent statuses)