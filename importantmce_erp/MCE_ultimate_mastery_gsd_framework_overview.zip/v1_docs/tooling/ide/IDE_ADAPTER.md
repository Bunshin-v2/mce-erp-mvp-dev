# IDE Adapter (VS Code/Cursor/Copilot)

Purpose
- Provide deterministic, copy-pasteable tasks and rehydration steps that respect gates and AEC workflows.

Tasks (examples)
- “Run Gate Suite”:
  - Open `docs/security/SECURITY_GATES.md`
  - Execute `pnpm test:security && pnpm test:rls && pnpm test:rag`
- “Provision Views”:
  - Apply SQL in `supabase/migrations/00x_views.sql`
  - Verify `v_*` views return rows; index check
- “Schedule Sweeps”:
  - Enable pg_cron; deploy `run_followup_sweep()` RPC
  - Verify heartbeat dashboard shows green

Copy-Paste Command Pack
```bash
# Gate checks
pnpm test:rls && pnpm test:security && pnpm test:rag

# Run followup sweep manually (debug)
psql -c "select * from run_followup_sweep();"

# Validate views compile
psql -c "select * from v_tenders_with_countdown limit 5;"
psql -c "select * from v_milestones_due limit 5;"
```

Rehydration Protocol (SEG-14)
- Paste:
```
<rehydrate>
SegmentID: SEG-07
State: Tooling adapters deployed (Claude/Auto-Claude/IDE)
Artifacts: security gates, ADRs, WF registry, views, RPCs
Open patches: None; pending: batch acceptance reports
NextAction: Run Gate Suite → execute WF-BID-001 on a sample tender
</rehydrate>
```

Acceptance (adapter health)
- Tasks produce verifiable outputs
- Rehydration reproduces state and next steps without ambiguity