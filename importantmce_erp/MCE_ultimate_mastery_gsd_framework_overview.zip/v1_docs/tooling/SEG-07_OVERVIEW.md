# SEG-07 Tooling & Agent Adapters (Claude Code, Auto-Claude, IDE)

Purpose
- Provide adapters, runbooks, prompts, and execution scaffolds for agent-driven development that enforce SEG-06 security/compliance gates, evidence-first policies, and AEC business logic.
- Prevent drift and collisions by integrating gate checks, source-of-truth (SOT) adjudication, and meta-synthesis prompts across all tooling surfaces.

Scope
- Claude Code Adapter (slash commands, prompts, gate-aware workflows)
- Auto-Claude Adapter (batch orchestration, policies, provenance)
- IDE Adapter (VS Code/Cursor tasks, rehydration protocol, copy-paste ready steps)
- Runbooks (rehydration, incident handling, gate failures, missed sweeps)

Key Principles (enforced)
- Evidence-first (RAG cite-or-refuse)
- RLS/permission checks at every data touch
- SOT adjudication for dashboards/metrics/views
- Fail-closed error handling (no partial writes)
- Gate acceptance tests before “final outputs”
- Convergence ledger entries for collisions/ambiguities

References
- SEG-02 Domain Model, SEG-03 Features, SEG-04 Workflows v0.2
- SEG-06 Security Gates + ADR set