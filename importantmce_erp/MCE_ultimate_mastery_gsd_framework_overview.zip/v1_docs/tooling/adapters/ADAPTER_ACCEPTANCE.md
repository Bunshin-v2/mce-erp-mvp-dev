# Adapter Acceptance Criteria

Claude Code
- Executes WF-IDs with gate checks; returns artifacts + audit logs
- Never bypasses SEG-06 gates
- Produces convergence ledger entries for collisions

Auto-Claude
- Batch lanes stop on gate failures
- Attaches SBOM + SLSA to outputs
- Yields acceptance reports per WF

IDE
- Tasks reproducible and deterministic
- Rehydration restores next actions and state
- Copy-paste commands operate without hidden assumptions

Global
- Evidence-first; cite-or-refuse enforced
- SOT declared for every computed metric
- Fail-closed on errors; rollback strategies present

NextAction
- Run Gate Suite, then execute WF-BID-001 (sample tender) through Claude Code Adapter; produce acceptance report and convergence ledger entries.

Success Signal
- Gate Suite green; artifacts with provenance; acceptance report attached; convergence ledger populated where applicable.