# Meta Prompts (Gate-Aware & AEC-Ready)

1) Obligations Radar (Compliance/Contracts)
“List obligations and renewals due in ≤30/≤14/≤7 days. Group by authority/emirate/client. Cite documents and SOT tables. If ambiguous, refuse and request clarification.”

2) Requirements Coverage (Tender Intake)
“Compute Coverage% for Tender #X. Show missing required documents with links and owners. Log meta-alert for any unmapped requirement.”

3) Progress Integrity (S-Curve)
“Render S-curve for Project #Y. Declare SOT and data derivation. Flag drift between planned vs actual beyond threshold; create remediation tasks.”

4) NCR Burn-down (QA/QC)
“Show NCR burn-down and resolution rate. Verify RLS blocks non-members. Cite NCR IDs and inspection reports; flag overdue escalations.”

5) Resource Utilization
“Compute utilization by role/project. Identify vacancies and upcoming mobilizations. Enforce sensitivity and RLS; propose staffing actions.”

Rule
- Always cite; refuse if insufficient evidence
- Declare SOT per metric/view
- Log collisions to convergence ledger