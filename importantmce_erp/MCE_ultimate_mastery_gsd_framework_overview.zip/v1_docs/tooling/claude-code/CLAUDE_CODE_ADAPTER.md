# Claude Code Adapter (Gate-Aware)

Purpose
- Drive conversational, task-based execution in Claude Code with gate-aware prompts, minimal context rot, and AEC business logic alignment.

Adapter Mode
- Workflow-first: Execute WF-IDs via subagents (planning → execution → verify)
- Gate-aware: Check SEG-06 gates before destructive operations
- Evidence-first: RAG requires citations; refusal allowed; no “fabricated correctness”

Slash Commands (recommended)
- `/mce:gate-check` → Run SEG-06 acceptance tests
- `/mce:execute-wf <WF-ID>` → Execute workflow with gate checks and audit logs
- `/mce:rehydrate` → Perform resume protocol (SEG-14)
- `/mce:rag-query <scope>` → Answer with citations or refuse; log eval metrics
- `/mce:import <source>` → Streamed Excel/CSV to staging; pseudo registry logging

Command Template (gate-aware orchestrator)
```
<objective>
Execute workflow {WF-ID} with SEG-06 gate checks and AEC business rules.
</objective>

<context>
@docs/security/SECURITY_GATES.md
@docs/workflows/WF-REGISTRY.md
@docs/domain/MODEL.md
Gate targets: RLS, storage privacy, injection/XSS, logging heartbeat, RAG citations
</context>

<guardrails>
- Evidence-first: cite or refuse
- Deny-by-default: RLS enforced
- SOT adjudication for all metrics/views
- Fail-closed on errors (no partial writes)
</guardrails>

<process>
1) Load WF-ID; list required tables/views/services
2) Run `/mce:gate-check` (subset relevant to WF)
3) Execute steps atomically; write audit logs
4) Verify acceptance criteria; produce artifacts
5) If any gate fails → stop + remediation plan
</process>

<outputs>
- Artifacts (reports, views, logs, UI bindings)
- Gate pass/fail with evidence
- Audit entries + convergence ledger notes (collisions/ambiguities)
</outputs>
```

Agentic Prompts (examples)
- “List the obligations due in ≤14 days for tenders; grade severity and cite document IDs” (WF-TND-002)
- “Compute Requirements Coverage% for Tender #X; show missing required docs with links” (WF-TND-001)
- “Render NCR Aging ladder; verify RLS blocks for non-members” (WF-SUP-003)
- “Produce S-curve from planned vs actual progress; list data sources and SOT” (WF-PROG-004)

Interaction Policy
- Never bypass SEG-06 gates
- Require explicit SOT declaration for every computed metric
- Log meta-alerts for any collisions/ambiguities detected

Acceptance (adapter health)
- Commands return ONLY gate-aware outputs
- Audit completeness: 100% state-changing actions logged
- Drift detectors: zero silent collisions (all flagged in convergence ledger)