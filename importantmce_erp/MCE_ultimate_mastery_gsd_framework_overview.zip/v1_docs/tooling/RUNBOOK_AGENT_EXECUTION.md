# Agent Execution Runbook (Gate-Aware)

Use-Cases
- Gate failures, missed sweep heartbeats, provenance gaps, collision incidents

1) Gate Failure (e.g., RLS deny/allow mismatch)
- Action: Stop batch; run `/mce:gate-check` focused on RLS
- Remediation: Fix policy; add tests; re-run acceptance
- Evidence: Attach failing queries + passing after fix

2) Missed Sweep Heartbeat (Notifications)
- Action: Inspect cron status; run manual RPC; check logs
- Remediation: Re-enable cron; add alerts; backfill notifications
- Evidence: Heartbeat timeline + successful backfill

3) Provenance Gap (missing SBOM/SLSA)
- Action: Re-run CI with provenance steps enabled
- Remediation: Patch pipeline; enforce “block on missing attestation”
- Evidence: SBOM + SLSA artifacts linked to outputs

4) Collision Incident (duplicate tender_no/project_code)
- Action: Open convergence ledger entry; propose merge; SOT override
- Remediation: Admin adjudication; update SOT pointers; reindex
- Evidence: Before/after entity linkage map

5) RAG Wrong Answer (uncited)
- Action: Switch to retrieval-only; analyze query; check chunk coverage
- Remediation: Re-chunk docs; verify sensitivity filters; re-run eval
- Evidence: Golden-set pass report with citations

Operational Checklist
- Gates green → proceed
- Audit entries present → OK
- Convergence ledger updated → OK
- Provenance attached → OK

Stop Conditions
- Any gate red → STOP
- Uncited RAG answer → STOP (fail-closed)
- Storage privacy violation → STOP

Next Steps
- Use Claude Code Adapter `/mce:execute-wf WF-BID-001` on sample tender with Gate Suite pre-check.