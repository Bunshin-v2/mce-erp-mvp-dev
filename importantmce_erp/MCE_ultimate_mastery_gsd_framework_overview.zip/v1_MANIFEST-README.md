# PROJECT-MANIFEST: How to use

Purpose
- This manifest is your single source-of-truth to drive the MVP build and safe upgrades.
- It encodes stack, gates, data models, workflows, dashboards, CI/deploy, and stress tests.

Quick Start (MVP baseline)
1) Wire Clerk ↔ Supabase provider integration (third-party auth).
2) Bootstrap Next.js app; add middleware for protected routes.
3) Create `tasks` table + RLS policies in Supabase; verify via two users.
4) Implement `/tasks` server action + structured logs (runId per call).
5) Add CI workflow (lint/typecheck/test/build); deploy to Vercel and configure env vars.

Proof-of-RLS Acceptance
- User A creates “A1” task; User B should not see it.
- If B sees A rows, STOP: fix RLS policies and re-run acceptance.

Upgrade Path (Phase-2)
- Add workflows (WF-*), dashboards, views, and storage policies.
- Introduce notification sweep heartbeat; add convergence ledger entries for collisions.
- Adopt hybrid RAG (FTS + vector) with strict cite-or-refuse.

Gate Suite
- Run tests listed in `gate_suite.tests`; all must be green before “final outputs.”
- Fail-closed policy: any red gate → STOP; remediate and re-run.

Telemetry
- Attach runId, phase, checkpoint, git commit, and vercel URL in acceptance reports.
- Keep structured logs visible in Vercel; use them for on-call debugging.

Incident Runbook (short)
- RLS mismatch: stop, run RLS matrix test, fix policies, add deny tests.
- Missed sweep: check cron, run manual RPC, backfill, add heartbeat alert.
- Provenance gaps: re-run CI with SBOM/SLSA; block releases until attested.
- Collisions: open convergence ledger entry; adjudicate SOT overrides.

Success Signal
- Prod deploy live; auth works; RLS proof verified; CI green; logs show runId on server actions.

Next Steps
- Populate repository with this manifest; wire CI and deploy; begin Phase-2 modeling (projects, tenders, documents) under the same gates.