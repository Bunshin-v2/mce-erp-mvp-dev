# MCE ERP/PSA - DASHBOARD & UI/UX SPECIFICATIONS
## Management Information System - Visual Design & Interaction Patterns

**Version:** 1.0.0  
**Date:** November 10, 2025  
**Target Platform:** Web (Desktop/Tablet/Mobile PWA)  
**Classification:** Internal - Design Documentation

---

## 📑 TABLE OF CONTENTS

1. [Design System & Visual Language](#design-system)
2. [Dashboard Layouts (All Roles)](#dashboard-layouts)
3. [Component Library](#component-library)
4. [Data Visualization Standards](#data-visualization)
5. [Interaction Patterns](#interaction-patterns)
6. [Responsive Breakpoints](#responsive-design)

---

## DESIGN SYSTEM & VISUAL LANGUAGE

### Color Palette

**Primary Colors:**
```css
--primary-900: #0F172A;  /* Deep Navy - Backgrounds, Headers */
--primary-800: #1E293B;  /* Dark Slate - Cards, Panels */
--primary-700: #334155;  /* Medium Slate - Secondary Backgrounds */
--primary-600: #475569;  /* Borders, Dividers */

--accent-500: #0D9488;   /* Teal - Primary Actions, Links */
--accent-600: #0F766E;   /* Teal Dark - Hover States */
--accent-700: #115E59;   /* Teal Darker - Active States */
```

**Semantic Colors:**
```css
--success-500: #10B981;  /* Green - Completed, Approved, Healthy */
--warning-500: #F59E0B;  /* Amber - At Risk, Pending, Caution */
--danger-500: #EF4444;   /* Red - Critical, Overdue, Rejected */
--info-500: #3B82F6;     /* Blue - Information, Links */
```

**Status Indicators:**
```css
--status-on-track: #10B981;      /* Green */
--status-at-risk: #F59E0B;       /* Amber */
--status-delayed: #EF4444;       /* Red */
--status-completed: #6366F1;     /* Indigo */
--status-cancelled: #6B7280;     /* Gray */
```

**Typography:**
```css
--font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
--font-mono: 'JetBrains Mono', 'Fira Code', 'Courier New', monospace;

--text-xs: 0.75rem;    /* 12px - Captions, Metadata */
--text-sm: 0.875rem;   /* 14px - Body Small, Labels */
--text-base: 1rem;     /* 16px - Body, Content */
--text-lg: 1.125rem;   /* 18px - Subheadings */
--text-xl: 1.25rem;    /* 20px - Section Titles */
--text-2xl: 1.5rem;    /* 24px - Page Titles */
--text-3xl: 1.875rem;  /* 30px - Dashboard Headers */
--text-4xl: 2.25rem;   /* 36px - Hero Text */

--font-weight-normal: 400;
--font-weight-medium: 500;
--font-weight-semibold: 600;
--font-weight-bold: 700;
```

**Spacing Scale:**
```css
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
```

**Border Radius:**
```css
--radius-sm: 0.25rem;  /* 4px - Small elements */
--radius-md: 0.5rem;   /* 8px - Cards, Buttons */
--radius-lg: 0.75rem;  /* 12px - Large cards */
--radius-xl: 1rem;     /* 16px - Modals */
--radius-full: 9999px; /* Circular */
```

**Shadows:**
```css
--shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
--shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
--shadow-glow: 0 0 15px rgba(13, 148, 136, 0.3);
```

---

## DASHBOARD LAYOUTS (ALL ROLES)

### 1. EXECUTIVE DASHBOARD (VC/Chairman)

**Layout Structure:**
```
┌─────────────────────────────────────────────────────────────────┐
│ [MCE Logo] EXECUTIVE COMMAND CENTER    [Search] [🔔] [👤 User] │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  📊 PORTFOLIO HEALTH SNAPSHOT                          │      │
│ │                                                          │      │
│ │  [12 Active Projects] [$42.5M Total Value] [3 At Risk] │      │
│ │                                                          │      │
│ │  ████████████████████░░░░  SPI: 0.95  Cost: +2.3%      │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐    │
│ │ 💰 FINANCIALS   │ │ 📈 TENDERS      │ │ 👥 RESOURCES    │    │
│ │                 │ │                 │ │                 │    │
│ │ AR: $2.3M       │ │ Win Rate: 68%   │ │ Utilization:    │    │
│ │ AP: $850K       │ │ Pipeline: $18M  │ │ 78% (Target 75%)│    │
│ │ Overdue: $420K  │ │ Pending: 8      │ │ Vacancy: 3      │    │
│ └─────────────────┘ └─────────────────┘ └─────────────────┘    │
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  📊 PROJECT STATUS MATRIX (Interactive Grid)           │      │
│ │                                                          │      │
│ │  🟢 SSMC B2      🟢 PTC Phase 1   🟡 Al Barsha Tower   │      │
│ │  $12.5M | 65%   $8.2M | 45%      $4.8M | 70% (Delayed) │      │
│ │                                                          │      │
│ │  🟢 DSFH Annex   🟡 Marina Clinic 🔴 Downtown Hotel     │      │
│ │  $6.3M | 80%    $3.1M | 55%      $2.9M | 30% (Critical)│      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  🚨 CRITICAL ALERTS & ACTIONS REQUIRED                 │      │
│ │                                                          │      │    
│ │  ⚠️  Downtown Hotel: 45 days behind schedule            │      │
│ │  💰 SSMC B2: Payment overdue 60 days ($1.2M)           │      │
│ │  📋 3 tenders due for submission this week              │      │
│ │  👤 Structural Engineer position vacant (critical)      │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌──────────────────────┐ ┌──────────────────────────────┐       │
│ │ 📈 CASH FLOW         │ │ 📊 COMPLIANCE STATUS         │       │
│ │ FORECAST (90 Days)   │ │                               │       │
│ │                      │ │ Permits: ████████░  90%       │       │
│ │ [Line Chart]         │ │ Insurance: ██████████ 100%    │       │
│ │                      │ │ Emiratization: ███████ 70%    │       │
│ └──────────────────────┘ └──────────────────────────────┘       │
└─────────────────────────────────────────────────────────────────┘
```

**Key Features:**
1. **Real-Time Metrics:** Auto-refresh every 60 seconds
2. **Interactive Project Cards:** Click to drill down into project details
3. **Color-Coded Alerts:** Red (critical), Amber (warning), Green (healthy)
4. **Quick Actions:** "View Details", "Schedule Meeting", "Generate Report"
5. **Comparison Period:** Toggle between "This Month", "This Quarter", "This Year"

**Widget Specifications:**

**Portfolio Health KPI Card:**
```javascript
{
  title: "Portfolio Health Snapshot",
  metrics: [
    { label: "Active Projects", value: 12, trend: "+2 vs last month" },
    { label: "Total Contract Value", value: "$42.5M", format: "currency" },
    { label: "At Risk", value: 3, status: "warning", onclick: "filterAtRiskProjects" }
  ],
  progressBar: {
    label: "Average Schedule Performance",
    value: 95,
    target: 100,
    color: "success"
  },
  lastUpdated: "2 minutes ago"
}
```

**Financial Summary Card:**
```javascript
{
  title: "Financial Summary",
  sections: [
    {
      label: "Accounts Receivable",
      value: "$2.3M",
      detail: "$420K overdue (30+ days)",
      status: "warning",
      onclick: "viewARAgingReport"
    },
    {
      label: "Accounts Payable",
      value: "$850K",
      detail: "All current",
      status: "success"
    },
    {
      label: "Cash Position",
      value: "$1.5M",
      detail: "Next 30 days: +$650K",
      status: "info"
    }
  ],
  quickActions: [
    { label: "View AR Aging", action: "navigate('/finance/ar-aging')" },
    { label: "Payment Forecast", action: "navigate('/finance/cash-flow')" }
  ]
}
```

**Critical Alerts Panel:**
```javascript
{
  title: "Critical Alerts & Actions Required",
  alerts: [
    {
      id: 1,
      severity: "critical",
      icon: "⚠️",
      title: "Downtown Hotel: 45 days behind schedule",
      description: "Recovery plan required by Nov 15",
      actions: [
        { label: "View Project", onclick: "navigate('/projects/downtown-hotel')" },
        { label: "Schedule Review", onclick: "scheduleProjectReviewMeeting" }
      ]
    },
    {
      id: 2,
      severity: "high",
      icon: "💰",
      title: "SSMC B2: Payment overdue 60 days ($1.2M)",
      description: "Escalation to client required",
      actions: [
        { label: "View Invoice", onclick: "navigate('/finance/invoices/INV-12345')" },
        { label: "Email Client", onclick: "composePaymentReminderEmail" }
      ]
    }
  ],
  dismissible: false,
  autoRefresh: true
}
```

---

### 2. PROJECT MANAGER DASHBOARD

**Layout Structure:**
```
┌─────────────────────────────────────────────────────────────────┐
│ [MCE] PROJECT MANAGER CONTROL CENTER   [Search] [🔔] [👤 Ahmed] │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  MY PROJECTS (6 Active)                    [+ New]     │      │
│ │                                                          │      │
│ │  Filters: [All] [Active] [At Risk] [Completed]         │      │
│ │  Sort: [Status ▼]                                       │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌──────────────────────────────────────────────────────────┐    │
│ │ 🟢 SSMC Strategic Internal Expansion - B2               │    │
│ │                                                          │    │
│ │ Status: Active | Design Phase | 65% Complete            │    │
│ │                                                          │    │
│ │ ├─ Schedule: ███████████░░░ 72% (7 days ahead)         │    │
│ │ ├─ Cost: ████████████ 98% (Under budget)               │    │
│ │ ├─ Quality: ████████░░ 85% (8 open NCRs)               │    │
│ │ └─ Next Milestone: IFC Submission (Dec 15, 2025)        │    │
│ │                                                          │    │
│ │ 🚨 3 Actions Overdue | 12 RFIs Awaiting Response       │    │
│ │                                                          │    │
│ │ [View Details] [Update Progress] [Generate Report]      │    │
│ └──────────────────────────────────────────────────────────┘    │
│                                                                   │
│ ┌──────────────────────────────────────────────────────────┐    │
│ │ 🟡 Al Barsha Residential Tower                          │    │
│ │                                                          │    │
│ │ Status: At Risk | Design Development | 70% Complete     │    │
│ │                                                          │    │
│ │ ⚠️  7 days behind schedule                              │    │
│ │ ⚠️  Civil Defense NOC pending (30 days overdue)         │    │
│ │                                                          │    │
│ │ [View Details] [Recovery Plan] [Escalate Issue]         │    │
│ └──────────────────────────────────────────────────────────┘    │
│                                                                   │
│ ┌─────────────────────────────────────────────────────────┐     │
│ │  📋 MY ACTION ITEMS (23 Total)              [+ Add]     │     │
│ │                                                          │     │
│ │  ┌────────────────────────────────────────────────┐     │     │
│ │  │ 🔴 OVERDUE (3)                                │     │     │
│ │  │                                                │     │     │
│ │  │ • Chase architect for RFI responses (SSMC B2)  │     │     │
│ │  │   Due: Nov 8 | 2 days overdue                 │     │     │
│ │  │                                                │     │     │
│ │  │ • Submit payment certificate (Al Barsha)      │     │     │
│ │  │   Due: Nov 9 | 1 day overdue                  │     │     │
│ │  │                                                │     │     │
│ │  │ [Complete] [Snooze] [Reassign]                │     │     │
│ │  └────────────────────────────────────────────────┘     │     │
│ │                                                          │     │
│ │  ┌────────────────────────────────────────────────┐     │     │
│ │  │ 🟡 THIS WEEK (12)                              │     │     │
│ │  │ [Show All ▼]                                   │     │     │
│ │  └────────────────────────────────────────────────┘     │     │
│ │                                                          │     │
│ │  ┌────────────────────────────────────────────────┐     │     │
│ │  │ 🟢 UPCOMING (8)                                │     │     │
│ │  │ [Show All ▼]                                   │     │     │
│ │  └────────────────────────────────────────────────┘     │     │
│ └─────────────────────────────────────────────────────────┘     │
│                                                                   │
│ ┌──────────────────┐ ┌──────────────────┐ ┌─────────────────┐  │
│ │ 📧 PENDING       │ │ 📊 THIS WEEK     │ │ 👥 MY TEAM      │  │
│ │ APPROVALS (5)    │ │ MEETINGS (8)     │ │ AVAILABILITY    │  │
│ │                  │ │                  │ │                 │  │
│ │ • Invoice #1234  │ │ Mon: Design Rev. │ │ ███████░░ 75%   │  │
│ │ • Submittal #456 │ │ Wed: Client Call │ │ Available       │  │
│ │ • Change Ord #78 │ │ Fri: Site Visit  │ │                 │  │
│ └──────────────────┘ └──────────────────┘ └─────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

**Key Features:**
1. **Project Health Cards:** Expandable/collapsible cards with traffic light indicators
2. **Action Items with Smart Grouping:** Overdue, This Week, Upcoming
3. **Quick Actions:** One-click task completion, delegation, snooze
4. **Meeting Calendar Integration:** Synced with Outlook/Google Calendar
5. **Team Availability:** Real-time view of resource allocation

**Project Health Card Component:**
```vue
<template>
  <div class="project-card" :class="statusClass">
    <div class="card-header">
      <div class="project-title">
        <span class="status-dot" :class="project.status"></span>
        <h3>{{ project.name }}</h3>
      </div>
      <div class="project-meta">
        <span class="code">{{ project.code }}</span>
        <span class="value">${{ formatCurrency(project.contract_value) }}</span>
      </div>
    </div>
    
    <div class="card-body">
      <div class="progress-bars">
        <ProgressBar 
          label="Schedule" 
          :value="project.schedule_progress" 
          :target="100"
          :status="project.schedule_status"
        />
        <ProgressBar 
          label="Cost" 
          :value="project.cost_progress" 
          :target="100"
          :status="project.cost_status"
        />
        <ProgressBar 
          label="Quality" 
          :value="project.quality_score" 
          :target="100"
          :status="project.quality_status"
        />
      </div>
      
      <div class="milestone-section">
        <span class="label">Next Milestone:</span>
        <span class="milestone">{{ project.next_milestone.name }}</span>
        <span class="date">({{ formatDate(project.next_milestone.due_date) }})</span>
      </div>
      
      <div v-if="project.alerts.length > 0" class="alerts">
        <AlertBadge 
          v-for="alert in project.alerts" 
          :key="alert.id" 
          :alert="alert"
        />
      </div>
    </div>
    
    <div class="card-footer">
      <button @click="viewDetails">View Details</button>
      <button @click="updateProgress">Update Progress</button>
      <button @click="generateReport">Generate Report</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ProjectHealthCard',
  props: {
    project: {
      type: Object,
      required: true
    }
  },
  computed: {
    statusClass() {
      return `status-${this.project.overall_status}`;
    }
  },
  methods: {
    viewDetails() {
      this.$router.push(`/projects/${this.project.id}`);
    },
    updateProgress() {
      this.$emit('update-progress', this.project.id);
    },
    generateReport() {
      this.$emit('generate-report', this.project.id);
    },
    formatCurrency(value) {
      return (value / 1000000).toFixed(1) + 'M';
    },
    formatDate(date) {
      return new Date(date).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    }
  }
};
</script>

<style scoped>
.project-card {
  background: var(--primary-800);
  border-radius: var(--radius-lg);
  padding: var(--space-6);
  margin-bottom: var(--space-4);
  border-left: 4px solid transparent;
  transition: all 0.3s ease;
}

.project-card:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.project-card.status-on-track {
  border-left-color: var(--success-500);
}

.project-card.status-at-risk {
  border-left-color: var(--warning-500);
}

.project-card.status-delayed {
  border-left-color: var(--danger-500);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-4);
}

.project-title {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.status-dot {
  width: 12px;
  height: 12px;
  border-radius: 50%;
}

.status-dot.on-track {
  background: var(--success-500);
}

.status-dot.at-risk {
  background: var(--warning-500);
}

.status-dot.delayed {
  background: var(--danger-500);
}

.progress-bars {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  margin-bottom: var(--space-4);
}

.alerts {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  margin-top: var(--space-4);
}

.card-footer {
  display: flex;
  gap: var(--space-3);
  margin-top: var(--space-4);
  padding-top: var(--space-4);
  border-top: 1px solid var(--primary-600);
}

.card-footer button {
  flex: 1;
  padding: var(--space-2) var(--space-4);
  background: var(--accent-500);
  color: white;
  border: none;
  border-radius: var(--radius-md);
  cursor: pointer;
  font-weight: var(--font-weight-medium);
  transition: background 0.2s ease;
}

.card-footer button:hover {
  background: var(--accent-600);
}
</style>
```

---

### 3. FINANCE DASHBOARD

**Layout Structure:**
```
┌─────────────────────────────────────────────────────────────────┐
│ [MCE] FINANCE CONTROL CENTER          [Search] [🔔] [👤 Sarah]  │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│ ┌───────────────┐ ┌───────────────┐ ┌───────────────┐          │
│ │ 💰 AR AGING   │ │ 💳 AP AGING   │ │ 📊 CASH POS.  │          │
│ │               │ │               │ │               │          │
│ │ $2.3M Total   │ │ $850K Total   │ │ $1.5M Current │          │
│ │               │ │               │ │               │          │
│ │ Current: $1.2M│ │ Current: $600K│ │ +$650K (30d)  │          │
│ │ 30d: $680K    │ │ 30d: $180K    │ │ +$1.2M (60d)  │          │
│ │ 60d: $280K    │ │ 60d: $50K     │ │ +$2.1M (90d)  │          │
│ │ 90d+: $140K🚨 │ │ 90d+: $20K    │ │               │          │
│ └───────────────┘ └───────────────┘ └───────────────┘          │
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  📈 ACCOUNTS RECEIVABLE AGING (Interactive)            │      │
│ │                                                          │      │
│ │  [Stacked Bar Chart by Project]                         │      │
│ │  ┌──────────────────────────────────────────────┐       │      │
│ │  │ SSMC B2       ████████████░░░░                │       │      │
│ │  │ Al Barsha     ██████████████░░                │       │      │
│ │  │ Downtown      ████████████████████ 🚨         │       │      │
│ │  │ Marina Clinic ████████░░░░░░░░░░░░            │       │      │
│ │  │               │    │    │    │    │           │       │      │
│ │  │               0  $500K $1M $1.5M $2M          │       │      │
│ │  │                                                │       │      │
│ │  │ ■ Current  ■ 30d  ■ 60d  ■ 90d+              │       │      │
│ │  └──────────────────────────────────────────────┘       │      │
│ │                                                          │      │
│ │  Click bar to drill down into project invoices          │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  📋 PENDING ACTIONS (8)                    [+ New]      │      │
│ │                                                          │      │
│ │  🔴 CRITICAL (2)                                        │      │
│ │  • Escalate payment for Downtown Hotel ($1.2M, 90d)    │      │
│ │  • Review retention release for DSFH Annex ($180K)     │      │
│ │                                                          │      │
│ │  🟡 HIGH (3)                                            │      │
│ │  • Approve invoice SSMC B2 #0012 ($450K)               │      │
│ │  • Process vendor payment XYZ Contractors ($220K)      │      │
│ │  • Reconcile payment certificate Al Barsha ($310K)     │      │
│ │                                                          │      │
│ │  🟢 MEDIUM (3)                                          │      │
│ │  [Show All ▼]                                           │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌──────────────────────────────────────────────────────────┐    │
│ │  💹 CASH FLOW FORECAST (Next 90 Days)                   │    │
│ │                                                          │    │
│ │  [Line Chart with Confidence Intervals]                 │    │
│ │  ┌──────────────────────────────────────────────┐       │    │
│ │  │   $3M │                                      │       │    │
│ │  │       │        ╱╲                            │       │    │
│ │  │   $2M │    ╱──╱  ╲──╲                        │       │    │
│ │  │       │ ╱──          ──╲──╲                  │       │    │
│ │  │   $1M │╱                   ──╲──             │       │    │
│ │  │       │                         ──╲─         │       │    │
│ │  │    $0 ┼─────────────────────────────────     │       │    │
│ │  │       Nov   Dec   Jan   Feb                   │       │    │
│ │  │                                                │       │    │
│ │  │ ─── Projected Cash In  ─── Projected Cash Out│       │    │
│ │  │ ░░░ Confidence Range (90%)                   │       │    │
│ │  └──────────────────────────────────────────────┘       │    │
│ └──────────────────────────────────────────────────────────┘    │
│                                                                   │
│ ┌──────────────────────┐ ┌──────────────────────────────┐       │
│ │ 🏦 INVOICE PIPELINE  │ │ 📊 PROJECT PROFITABILITY     │       │
│ │                      │ │ (Budget vs Actuals)           │       │
│ │ Draft: 4 ($890K)     │ │                               │       │
│ │ Submitted: 6 ($2.1M) │ │ [Bar Chart - Top 5 Projects]  │       │
│ │ Approved: 3 ($1.3M)  │ │                               │       │
│ │ Paid: 18 ($8.5M YTD) │ │ SSMC B2:    +8.5% ✓           │       │
│ └──────────────────────┘ │ Al Barsha:  +3.2% ✓           │       │
│                           │ Downtown:   -12.1% 🚨         │       │
│                           └──────────────────────────────┘       │
└─────────────────────────────────────────────────────────────────┘
```

**Key Features:**
1. **AR/AP Aging Visualization:** Interactive drill-down by project and invoice
2. **Predictive Cash Flow:** ML-based forecasting with confidence intervals
3. **Payment Alerts:** Automated escalation recommendations
4. **Profitability Analysis:** Real-time budget variance tracking
5. **Quick Payment Processing:** One-click vendor payment approval

---

### 4. TENDERING DASHBOARD

**Layout Structure:**
```
┌─────────────────────────────────────────────────────────────────┐
│ [MCE] TENDER MANAGEMENT CENTER         [Search] [🔔] [👤 Ann]   │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  📊 TENDER PIPELINE OVERVIEW                           │      │
│ │                                                          │      │
│ │  ┌──────────────────────────────────────────────┐       │      │
│ │  │  8 Active  │  12 Submitted  │  68% Win Rate  │       │      │
│ │  │  $18M      │  $32M          │  Last 12 Mo.   │       │      │
│ │  └──────────────────────────────────────────────┘       │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  📅 TENDER CALENDAR (Current + Next 30 Days)           │      │
│ │                                                          │      │
│ │  Week of Nov 10-16:                                     │      │
│ │  ┌─────────────────────────────────────────────┐        │      │
│ │  │ Mon 11: Prebid Meeting - Dubai Clinic Expansion│     │      │
│ │  │ Wed 13: 🚨 SUBMISSION - Al Ain Hospital (EOD)  │     │      │
│ │  │ Fri 15: Tender Briefing - Marina Towers        │     │      │
│ │  └─────────────────────────────────────────────┘        │      │
│ │                                                          │      │
│ │  Week of Nov 17-23:                                     │      │
│ │  [Show Week ▼]                                          │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌──────────────────────────────────────────────────────────┐    │
│ │  🔴 URGENT SUBMISSIONS (Due in 7 Days)                   │    │
│ │                                                          │    │
│ │  ┌────────────────────────────────────────────────┐     │    │
│ │  │ Al Ain Hospital Expansion                      │     │    │
│ │  │ Due: Nov 13, 2025 (3 days) 🚨                  │     │    │
│ │  │                                                │     │    │
│ │  │ Status: ████████████░░░░ 80% Complete         │     │    │
│ │  │ • Technical: ✓ Complete                       │     │    │
│ │  │ • Commercial: ⏳ In Progress (90%)            │     │    │
│ │  │ • Documents: ⚠️ Missing 2 certificates        │     │    │
│ │  │                                                │     │    │
│ │  │ [View Details] [Upload Docs] [Submit]         │     │    │
│ │  └────────────────────────────────────────────────┘     │    │
│ │                                                          │    │
│ │  ┌────────────────────────────────────────────────┐     │    │
│ │  │ Marina Towers Residential Complex              │     │    │
│ │  │ Due: Nov 18, 2025 (8 days)                     │     │    │
│ │  │                                                │     │    │
│ │  │ Status: ███████░░░░░░░░ 55% Complete          │     │    │
│ │  │ • Technical: ⏳ In Progress (60%)              │     │    │
│ │  │ • Commercial: ⏳ Not Started                   │     │    │
│ │  │                                                │     │    │
│ │  │ [View Details] [Assign Resources]              │     │    │
│ │  └────────────────────────────────────────────────┘     │    │
│ └──────────────────────────────────────────────────────────┘    │
│                                                                   │
│ ┌────────────────────────────────────────────────────────┐      │
│ │  📋 ACTIVE TENDERS (8)                     [+ New]      │      │
│ │                                                          │      │
│ │  Filters: [All] [Prequalification] [Preparation] [📊]  │      │
│ │  Sort: [Deadline ▼]                                     │      │
│ │                                                          │      │
│ │  ┌──────────────────────────────────────────────┐       │      │
│ │  │ Dubai Healthcare City - Phase 3              │       │      │
│ │  │ RFQ-2025-DH-003 | $12.5M Est.                │       │      │
│ │  │ Status: Bid/No-Bid Review                    │       │      │
│ │  │ Decision Due: Nov 14 | Submission: Dec 5     │       │      │
│ │  │                                               │       │      │
│ │  │ [Review Brief] [Decision Form]                │       │      │
│ │  └──────────────────────────────────────────────┘       │      │
│ │                                                          │      │
│ │  [Show More ▼]                                          │      │
│ └────────────────────────────────────────────────────────┘      │
│                                                                   │
│ ┌──────────────────────┐ ┌──────────────────────────────┐       │
│ │ 🏆 WIN/LOSS STATS    │ │ 📊 PORTAL STATUS             │       │
│ │ (Last 12 Months)     │ │                               │       │
│ │                      │ │ ✓ DGOV: 24 new tenders        │       │
│ │ Won: 17 (68%)        │ │ ✓ Dubai Tender: 18 new        │       │
│ │ Lost: 8 (32%)        │ │ ✓ RAK Govt: 6 new             │       │
│ │                      │ │ ⚠️ Sharjah: Login expired     │       │
│ │ Total Value: $42M    │ │                               │       │
│ │ Win Value: $32M      │ │ [Refresh All] [Manage]        │       │
│ └──────────────────────┘ └──────────────────────────────┘       │
└─────────────────────────────────────────────────────────────────┘
```

**Key Features:**
1. **Deadline Countdown:** Visual countdown timers for critical submissions
2. **Completion Tracking:** Real-time progress bars for each tender section
3. **Document Checklist:** Automated validation of required documents
4. **Portal Integration:** Live scraping status and new tender alerts
5. **Win/Loss Analytics:** Historical performance with trend analysis

---

## COMPONENT LIBRARY

### Core UI Components

**1. Progress Bar Component**
```vue
<template>
  <div class="progress-container">
    <div class="progress-header">
      <span class="progress-label">{{ label }}</span>
      <span class="progress-value">{{ displayValue }}</span>
    </div>
    <div class="progress-bar">
      <div 
        class="progress-fill" 
        :class="statusClass"
        :style="{ width: percentage + '%' }"
      >
        <span v-if="showPercentage" class="progress-text">{{ percentage }}%</span>
      </div>
      <div v-if="target && target !== 100" class="target-marker" :style="{ left: target + '%' }">
        <div class="target-line"></div>
        <span class="target-label">Target</span>
      </div>
    </div>
    <div v-if="subtitle" class="progress-subtitle">{{ subtitle }}</div>
  </div>
</template>

<script>
export default {
  name: 'ProgressBar',
  props: {
    label: String,
    value: Number,
    target: {
      type: Number,
      default: 100
    },
    status: {
      type: String,
      default: 'default',
      validator: (val) => ['success', 'warning', 'danger', 'default'].includes(val)
    },
    showPercentage: {
      type: Boolean,
      default: true
    },
    subtitle: String,
    format: {
      type: String,
      default: 'percentage'  // 'percentage', 'currency', 'number'
    }
  },
  computed: {
    percentage() {
      return Math.min(Math.max((this.value / this.target) * 100, 0), 100);
    },
    displayValue() {
      if (this.format === 'currency') {
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'AED',
          minimumFractionDigits: 0
        }).format(this.value);
      } else if (this.format === 'number') {
        return this.value.toLocaleString();
      } else {
        return this.percentage.toFixed(0) + '%';
      }
    },
    statusClass() {
      return `status-${this.status}`;
    }
  }
};
</script>

<style scoped>
.progress-container {
  width: 100%;
  margin-bottom: var(--space-3);
}

.progress-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-2);
  font-size: var(--text-sm);
}

.progress-label {
  font-weight: var(--font-weight-medium);
  color: var(--text-primary);
}

.progress-value {
  font-weight: var(--font-weight-semibold);
  color: var(--text-secondary);
}

.progress-bar {
  position: relative;
  height: 8px;
  background: var(--primary-700);
  border-radius: var(--radius-full);
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: var(--radius-full);
  transition: width 0.6s ease, background-color 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: var(--space-2);
}

.progress-fill.status-success {
  background: linear-gradient(90deg, var(--success-500), var(--success-600));
}

.progress-fill.status-warning {
  background: linear-gradient(90deg, var(--warning-500), var(--warning-600));
}

.progress-fill.status-danger {
  background: linear-gradient(90deg, var(--danger-500), var(--danger-600));
}

.progress-fill.status-default {
  background: linear-gradient(90deg, var(--accent-500), var(--accent-600));
}

.progress-text {
  font-size: var(--text-xs);
  font-weight: var(--font-weight-bold);
  color: white;
}

.target-marker {
  position: absolute;
  top: -2px;
  bottom: -2px;
  width: 2px;
  pointer-events: none;
}

.target-line {
  width: 100%;
  height: 100%;
  background: white;
  border-radius: var(--radius-sm);
}

.target-label {
  position: absolute;
  top: -18px;
  left: 50%;
  transform: translateX(-50%);
  font-size: var(--text-xs);
  color: var(--text-tertiary);
  white-space: nowrap;
}

.progress-subtitle {
  margin-top: var(--space-2);
  font-size: var(--text-xs);
  color: var(--text-tertiary);
}
</style>
```

**2. Status Badge Component**
```vue
<template>
  <span class="status-badge" :class="[sizeClass, statusClass]">
    <span v-if="showDot" class="status-dot"></span>
    {{ label || status }}
  </span>
</template>

<script>
export default {
  name: 'StatusBadge',
  props: {
    status: {
      type: String,
      required: true,
      validator: (val) => [
        'success', 'warning', 'danger', 'info',
        'active', 'pending', 'completed', 'cancelled',
        'on-track', 'at-risk', 'delayed'
      ].includes(val)
    },
    label: String,
    size: {
      type: String,
      default: 'md',
      validator: (val) => ['sm', 'md', 'lg'].includes(val)
    },
    showDot: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    sizeClass() {
      return `size-${this.size}`;
    },
    statusClass() {
      return `status-${this.status}`;
    }
  }
};
</script>

<style scoped>
.status-badge {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-1) var(--space-3);
  border-radius: var(--radius-full);
  font-weight: var(--font-weight-medium);
  font-size: var(--text-sm);
  white-space: nowrap;
}

.status-badge.size-sm {
  padding: 2px var(--space-2);
  font-size: var(--text-xs);
}

.status-badge.size-lg {
  padding: var(--space-2) var(--space-4);
  font-size: var(--text-base);
}

.status-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.status-badge.status-success,
.status-badge.status-completed,
.status-badge.status-on-track {
  background: rgba(16, 185, 129, 0.1);
  color: var(--success-500);
}

.status-badge.status-success .status-dot {
  background: var(--success-500);
}

.status-badge.status-warning,
.status-badge.status-pending,
.status-badge.status-at-risk {
  background: rgba(245, 158, 11, 0.1);
  color: var(--warning-500);
}

.status-badge.status-warning .status-dot {
  background: var(--warning-500);
}

.status-badge.status-danger,
.status-badge.status-cancelled,
.status-badge.status-delayed {
  background: rgba(239, 68, 68, 0.1);
  color: var(--danger-500);
}

.status-badge.status-danger .status-dot {
  background: var(--danger-500);
}

.status-badge.status-info,
.status-badge.status-active {
  background: rgba(59, 130, 246, 0.1);
  color: var(--info-500);
}

.status-badge.status-info .status-dot {
  background: var(--info-500);
}
</style>
```

**3. Metric Card Component**
```vue
<template>
  <div class="metric-card" :class="[sizeClass, statusClass]" @click="handleClick">
    <div class="metric-icon" v-if="icon">
      <span>{{ icon }}</span>
    </div>
    <div class="metric-content">
      <div class="metric-label">{{ label }}</div>
      <div class="metric-value">{{ formattedValue }}</div>
      <div v-if="trend" class="metric-trend" :class="trendClass">
        <span class="trend-icon">{{ trendIcon }}</span>
        <span class="trend-value">{{ trend }}</span>
      </div>
      <div v-if="subtitle" class="metric-subtitle">{{ subtitle }}</div>
    </div>
    <div v-if="action" class="metric-action">
      <button @click.stop="action.handler">{{ action.label }}</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MetricCard',
  props: {
    label: String,
    value: [String, Number],
    format: {
      type: String,
      default: 'number'  // 'number', 'currency', 'percentage'
    },
    icon: String,
    trend: String,
    trendDirection: {
      type: String,
      validator: (val) => ['up', 'down', 'neutral'].includes(val)
    },
    subtitle: String,
    status: {
      type: String,
      validator: (val) => ['success', 'warning', 'danger', 'default'].includes(val)
    },
    size: {
      type: String,
      default: 'md',
      validator: (val) => ['sm', 'md', 'lg'].includes(val)
    },
    action: Object,
    clickable: Boolean
  },
  computed: {
    formattedValue() {
      if (this.format === 'currency') {
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'AED',
          minimumFractionDigits: 0
        }).format(this.value);
      } else if (this.format === 'percentage') {
        return this.value + '%';
      } else {
        return this.value.toLocaleString();
      }
    },
    sizeClass() {
      return `size-${this.size}`;
    },
    statusClass() {
      return this.status ? `status-${this.status}` : '';
    },
    trendClass() {
      return this.trendDirection ? `trend-${this.trendDirection}` : '';
    },
    trendIcon() {
      if (this.trendDirection === 'up') return '↑';
      if (this.trendDirection === 'down') return '↓';
      return '→';
    }
  },
  methods: {
    handleClick() {
      if (this.clickable) {
        this.$emit('click');
      }
    }
  }
};
</script>

<style scoped>
.metric-card {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  background: var(--primary-800);
  border-radius: var(--radius-lg);
  padding: var(--space-6);
  transition: all 0.3s ease;
  cursor: default;
}

.metric-card.clickable {
  cursor: pointer;
}

.metric-card.clickable:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.metric-card.size-sm {
  padding: var(--space-4);
}

.metric-card.size-lg {
  padding: var(--space-8);
}

.metric-icon {
  font-size: 2rem;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(13, 148, 136, 0.1);
  border-radius: var(--radius-md);
}

.metric-content {
  flex: 1;
}

.metric-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  margin-bottom: var(--space-1);
}

.metric-value {
  font-size: var(--text-2xl);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.metric-trend {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  font-size: var(--text-sm);
  font-weight: var(--font-weight-medium);
}

.metric-trend.trend-up {
  color: var(--success-500);
}

.metric-trend.trend-down {
  color: var(--danger-500);
}

.metric-trend.trend-neutral {
  color: var(--text-tertiary);
}

.metric-subtitle {
  font-size: var(--text-xs);
  color: var(--text-tertiary);
  margin-top: var(--space-2);
}

.metric-action button {
  padding: var(--space-2) var(--space-4);
  background: var(--accent-500);
  color: white;
  border: none;
  border-radius: var(--radius-md);
  cursor: pointer;
  font-weight: var(--font-weight-medium);
  transition: background 0.2s ease;
}

.metric-action button:hover {
  background: var(--accent-600);
}

/* Status-specific styling */
.metric-card.status-success {
  border-left: 4px solid var(--success-500);
}

.metric-card.status-warning {
  border-left: 4px solid var(--warning-500);
}

.metric-card.status-danger {
  border-left: 4px solid var(--danger-500);
}
</style>
```

---

## DATA VISUALIZATION STANDARDS

### Chart Types & When to Use Them

**1. Progress/Completion:**
- **Use:** Horizontal bars with percentage fill
- **Example:** Stage completion, task progress
- **Color:** Green (on-track), Amber (delayed), Red (critical)

**2. Financial Trends:**
- **Use:** Line charts with forecast shading
- **Example:** Cash flow forecast, revenue trends
- **Features:** Multiple series, confidence intervals, target lines

**3. Aging Analysis:**
- **Use:** Stacked horizontal bars
- **Example:** AR/AP aging by project
- **Colors:** Current (Blue), 30d (Green), 60d (Amber), 90d+ (Red)

**4. Comparisons:**
- **Use:** Grouped vertical bars
- **Example:** Budget vs actuals, plan vs actual hours
- **Features:** Data labels, variance indicators

**5. Distribution:**
- **Use:** Pie/Donut charts (sparingly!)
- **Example:** Resource allocation by department, project status distribution
- **Rule:** Max 5-6 segments, otherwise use bars

**6. Timeline:**
- **Use:** Gantt charts
- **Example:** Project stages, task dependencies
- **Features:** Dependencies, milestones, critical path highlighting

---

## CONCLUSION

This UI/UX specification provides:
- Complete design system (colors, typography, spacing)
- 4 role-specific dashboard layouts
- 3 reusable component templates with Vue code
- Data visualization standards
- Interaction patterns and responsiveness guidelines

**Next Steps:**
1. Design review with stakeholders (Week 5)
2. Create Figma mockups based on these specs (Week 6)
3. Build component library in Storybook (Week 7-8)
4. Implement dashboard prototypes (Week 9-12)

**Document Status:**
- Approval Gate: EG-3 (Design Approved) - PENDING
- Next Review: Week 6 (after Figma mockups)
- Maintained By: UI/UX Design Team + Frontend Team
