project_manifest:
  session_id: "{{SID}}"
  project_name: "{{PROJECT}}"
  user_role: "{{ROLE}}"
  useful_context:
    - "{{CTX1}}"
    - "{{CTX2}}"
    - "{{CTX3}}"
  essential_considerations:
    - "{{CON1}}"
    - "{{CON2}}"
  parameters:
    - "{{PARAM1}}"
    - "{{PARAM2}}"
  metadata:
    version: "1.0"
    last_modified: "{{TS}}"
  seeding_points:
    - "{{SEED1}}"
    - "{{SEED2}}"

execution_settings:
  chunk_size_percent: 10
  blank_cheque_x: 10
  execution_caps:
    per_phase_runs: 6
    stress_test_max_per_scenario: 10
    project_total_max: 30

telemetry:
  run_id: "{{RID}}"
  phase: "{{PHASE}}"
  checkpoint: "{{CP}}"

agents:
  model_semantic_cleaning: "{{MODEL_A}}"
  model_structure_validation: "{{MODEL_B}}"
  model_kg_parsing: "{{MODEL_C}}"
  model_recombination: "{{MODEL_D}}"
  model_devil_advocate: "{{MODEL_E}}"

stress_test_scenarios:
  mce_tendering_1:
    narrative: "{{REALISTIC_DATA}}"
  mce_tendering_2:
    narrative: "{{REALISTIC_DATA}}"
  mce_digital_transformation_1:
    narrative: "{{REALISTIC_DATA}}"
  mce_digital_transformation_2:
    narrative: "{{REALISTIC_DATA}}"
  generic_1:
    narrative: "{{GENERIC_DATA}}"
  generic_2:
    narrative: "{{GENERIC_DATA}}"
  generic_3:
    narrative: "{{GENERIC_DATA}}"
  generic_4:
    narrative: "{{GENERIC_DATA}}"
